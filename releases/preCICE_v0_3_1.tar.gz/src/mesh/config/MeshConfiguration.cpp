// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "MeshConfiguration.hpp"
#include "mesh/config/DataConfiguration.hpp"
#include "mesh/Mesh.hpp"
#include "utils/xml/XMLAttribute.hpp"
#include "utils/Globals.hpp"
#include <sstream>

namespace precice {
namespace mesh {

tarch::logging::Log MeshConfiguration:: _log ( "precice::mesh::MeshConfiguration" );

const std::string& MeshConfiguration:: getTag ()
{
  static std::string tag ( "mesh" );
  return tag;
}

MeshConfiguration:: MeshConfiguration
(
  PtrDataConfiguration config )
:
  ATTR_NAME ( "name" ),
  ATTR_FLIP_NORMALS ( "flip-normals" ),
  TAG_DATA ( "use-data" ),
  TAG_SPACETREE ( "use-spacetree" ),
  TAG_SUB_ID ( "sub-id" ),
  ATTR_SIDE_INDEX ( "side" ),
  _isValid ( false ),
  _dataConfig ( config ),
  _meshes (),
  _setMeshSubIDs (),
  _meshSubIDs (),
  _spacetreeNames ()
{}

bool MeshConfiguration:: parseSubtag
(
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace ( "parseSubtag()" );
  using utils::XMLTag;
  using utils::XMLAttribute;

  assertion ( ! _setMeshSubIDs );

  XMLTag tag ( getTag(), XMLTag::OCCUR_ONCE );
  XMLAttribute<std::string> attrName ( ATTR_NAME );
  tag.addAttribute ( attrName );

  XMLAttribute<bool> attrFlipNormals ( ATTR_FLIP_NORMALS );
  attrFlipNormals.setDefaultValue ( false );
  tag.addAttribute ( attrFlipNormals );

  XMLTag subtagData ( TAG_DATA, XMLTag::OCCUR_ARBITRARY );
  subtagData.addAttribute ( attrName );
  tag.addSubtag ( subtagData );

  utils::XMLTag tagSubID ( TAG_SUB_ID, utils::XMLTag::OCCUR_ARBITRARY );
  utils::XMLAttribute<int> attrSideIndex ( ATTR_SIDE_INDEX );
  tagSubID.addAttribute ( attrSideIndex );
  tag.addSubtag ( tagSubID );

  XMLTag subtagUseSpacetree ( TAG_SPACETREE, XMLTag::OCCUR_NOT_OR_ONCE );
  subtagUseSpacetree.addAttribute ( attrName );
  tag.addSubtag ( subtagUseSpacetree );

  _isValid = tag.parse ( xmlReader, *this );

  return _isValid;
}

bool MeshConfiguration:: xmlTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace1 ( "xmlTagCallback()", callingTag.getName() );
  if ( callingTag.getName() == getTag() ) {
    std::string name = callingTag.getStringAttributeValue(ATTR_NAME);
    bool flipNormals = callingTag.getBooleanAttributeValue(ATTR_FLIP_NORMALS);
    _meshes.push_back (
        PtrMesh(new Mesh(name, _dataConfig->getDimensions(), flipNormals)) );
    _meshSubIDs.push_back ( std::list<std::string>() );
  }
  else if ( callingTag.getName() == TAG_SUB_ID ) {
    int side = callingTag.getIntAttributeValue(ATTR_SIDE_INDEX);
    std::stringstream conv;
    conv << "side-" << side;
    _meshSubIDs.back().push_back ( conv.str() );
  }
  else if ( callingTag.getName() == TAG_DATA ) {
    std::string name = callingTag.getStringAttributeValue(ATTR_NAME);
    bool found = false;
    foreach ( const DataConfiguration::ConfiguredData & data, _dataConfig->data() ) {
      if ( data.name == name ) {
        _meshes.back()->createData ( data.name, data.dimension );
        found = true;
        break;
      }
    }
    preciceCheck ( found, "xmlTagCallback()", "Data with name \"" << name
        << "\" is not available during configuration of mesh \""
        << _meshes.back()->getName() << "\"!" );
  }
  else if ( callingTag.getName() == TAG_SPACETREE ) {
    std::string spacetreeName = callingTag.getStringAttributeValue(ATTR_NAME);
    std::string meshName ( _meshes.back()->getName() );
    preciceCheck ( _spacetreeNames.count(meshName) == 0,
        "xmlTagCallback()", "Mesh \"" << meshName
        << "\" can only use one spacetree!" );
    _spacetreeNames[meshName] = spacetreeName;
  }
  return true;
}

bool MeshConfiguration:: xmlEndTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  return true;
}

const PtrDataConfiguration& MeshConfiguration:: getDataConfiguration () const
{
  return _dataConfig;
}

void MeshConfiguration:: addMesh
(
  mesh::PtrMesh mesh )
{
  foreach ( PtrData dataNewMesh, mesh->data() ){
    bool found = false;
    foreach ( const DataConfiguration::ConfiguredData & data, _dataConfig->data() ){
      if ( (dataNewMesh->getName() == data.name)
           && ( dataNewMesh->getDimensions() == data.dimension) )
      {
        found = true;
        break;
      }
    }
    preciceCheck ( found, "addMesh()", "Data " << dataNewMesh->getName()
                   << " is not available in data configuration!" );
  }
  _meshes.push_back ( mesh );
}

void MeshConfiguration:: setMeshSubIDs ()
{
  assertion ( _isValid );
  assertion ( _meshes.size() == _meshSubIDs.size() );
  assertion ( not _setMeshSubIDs );
  for ( size_t i=0; i < _meshes.size(); i++ ) {
    foreach ( const std::string & subIDName, _meshSubIDs[i] ) {
      _meshes[i]->setSubID ( subIDName );
    }
  }
  _setMeshSubIDs = true;
}

bool MeshConfiguration:: isValid () const
{
  return _isValid;
}

const std::vector<PtrMesh>& MeshConfiguration:: meshes () const
{
  return _meshes;
}

std::vector<PtrMesh>& MeshConfiguration:: meshes ()
{
  return _meshes;
}

mesh::PtrMesh MeshConfiguration:: getMesh
(
  const std::string& meshName ) const
{
  foreach ( const mesh::PtrMesh & mesh, _meshes ) {
    if ( mesh->getName() == meshName ) {
      return mesh;
    }
  }
  return mesh::PtrMesh();
}

bool MeshConfiguration:: doesMeshUseSpacetree
(
  const std::string& meshName ) const
{
  return _spacetreeNames.count(meshName) > 0;
}

const std::string& MeshConfiguration:: getSpacetreeName
(
  const std::string& meshName ) const
{
  assertion ( _spacetreeNames.count(meshName) > 0 );
  return _spacetreeNames.find(meshName)->second;
}


}} // namespace precice, mesh
