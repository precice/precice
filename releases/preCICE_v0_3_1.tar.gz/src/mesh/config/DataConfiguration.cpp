// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "DataConfiguration.hpp"
#include "mesh/Data.hpp"
#include "mesh/PropertyContainer.hpp"
#include "utils/xml/XMLAttribute.hpp"
#include "utils/xml/ValidatorEquals.hpp"
#include "utils/xml/ValidatorOr.hpp"
#include "utils/Globals.hpp"

namespace precice {
namespace mesh {

tarch::logging::Log DataConfiguration:: _log ( "precice::mesh::DataConfiguration" );

const std::string& DataConfiguration:: getTag ()
{
  static std::string tag ( "data" );
  return tag;
}

DataConfiguration:: DataConfiguration
(
  int dimensions )
:
  ATTR_NAME ( "name" ),
  ATTR_TYPE ( "type" ),
  VALUE_VECTOR ( "vector" ),
  VALUE_SCALAR ( "scalar" ),
  _dimensions ( dimensions ),
  _isValid ( false ),
  _data (),
  _indexLastConfigured ( -1 )
{}

bool DataConfiguration:: parseSubtag
(
  tarch::irr::io::IrrXMLReader* xmlReader )
{
  utils::XMLTag tagData ( getTag(), utils::XMLTag::OCCUR_ONCE );

  utils::XMLAttribute<std::string> attrName ( ATTR_NAME );
  tagData.addAttribute ( attrName );

  utils::XMLAttribute<std::string> attrType ( ATTR_TYPE );
  utils::ValidatorEquals<std::string> validVectorType ( VALUE_VECTOR );
  utils::ValidatorEquals<std::string> validFloatingType ( VALUE_SCALAR );
  attrType.setValidator ( validVectorType || validFloatingType );
  tagData.addAttribute ( attrType );

  _isValid = tagData.parse ( xmlReader, *this );
  return _isValid;
}

bool DataConfiguration:: isValid () const
{
   return _isValid;
}

const std::vector<DataConfiguration::ConfiguredData>&
DataConfiguration:: data () const
{
   return _data;
}

DataConfiguration::ConfiguredData DataConfiguration:: getRecentlyConfiguredData () const
{
  assertion ( _data.size() > 0 );
  assertion ( _indexLastConfigured >= 0 );
  assertion ( _indexLastConfigured < (int)_data.size() );
  return _data[_indexLastConfigured];
}

bool DataConfiguration:: xmlTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  if ( callingTag.getName() == getTag() ) {
    std::string name = callingTag.getStringAttributeValue(ATTR_NAME);
    std::string typeName = callingTag.getStringAttributeValue(ATTR_TYPE);
    int dataDimensions = getDataDimensions(typeName);
    addData ( name, dataDimensions );
  }
  return true;
}

bool DataConfiguration:: xmlEndTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  return true;
}

void DataConfiguration:: addData
(
  const std::string& name,
  int                dataDimensions )
{
  ConfiguredData data ( name, dataDimensions );

  // Check, if data with same name has been added already
  for ( size_t i=0; i < _data.size(); i++ ) {
    preciceCheck ( _data[i].name != data.name, "addData()",
                   "Data \"" << data.name << "\" uses non-unique name!" );
  }
  _data.push_back ( data );
}

int DataConfiguration:: getDataDimensions
(
  const std::string& typeName ) const
{
  if (typeName == VALUE_VECTOR) {
    return _dimensions;
  }
  else if (typeName == VALUE_SCALAR) {
    return 1;
  }
  preciceError ( "getDataDimension()", "Unknown data type!" );
}

int DataConfiguration:: getDimensions() const
{
  return _dimensions;
}


}} // namespace precice, mesh
