// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "GroupTest.hpp"
#include "mesh/Group.hpp"
#include "mesh/Vertex.hpp"
#include "mesh/Edge.hpp"
#include "utils/Parallel.hpp"
#include "utils/Dimensions.hpp"
#include "utils/Globals.hpp"

#include "tarch/tests/TestCaseFactory.h"
registerTest(precice::mesh::tests::GroupTest)

namespace precice {
namespace mesh {
namespace tests {

tarch::logging::Log GroupTest:: _log ( "precice::mesh::tests::GroupTest" );

GroupTest:: GroupTest ()
:
   TestCase ("mesh::GroupTest")
{}

void GroupTest:: run()
{
  PRECICE_MASTER_ONLY {
    preciceTrace ( "run()" );
    using utils::Vector3D;
    Group group2;
    Vertex vertex0 ( Vector3D(0.0), 0 );
    Vertex vertex1 ( Vector3D(1.0), 1 );
    Vertex vertex2 ( Vector3D(2.0), 2 );

    group2.add ( vertex0 );
    group2.add ( vertex1 );
    group2.add ( vertex2 );

    Vector3D coords ( 0.0 );
    foreach ( Vertex& v, group2.vertices() ) {
      validate ( tarch::la::equals(v.getCoords(), coords) );
      coords += Vector3D(1.0);
    }

    Edge edge0 ( vertex0, vertex1, 0 );
    Edge edge1 ( vertex1, vertex2, 1 );
    group2.add ( edge0 );
    group2.add ( edge1 );

    coords = Vector3D(0.0);
    foreach ( Vertex& v, group2.vertices() ) {
      validate ( tarch::la::equals(v.getCoords(), coords) );
      coords += Vector3D(1.0);
    }
    coords = Vector3D(0.0);
    foreach  ( Edge& e, group2.edges() ) {
      validate ( tarch::la::equals(e.vertex(0).getCoords(), coords) );
      coords += Vector3D ( 1.0 );
    }
  }
}


}}} // namespace precice, mesh, tests
