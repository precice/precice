// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "MappingConfiguration.hpp"
#include "mapping/NearestNeighborMapping.hpp"
#include "mapping/NearestProjectionMapping.hpp"
#include "mapping/RadialBasisFctMapping.hpp"
#include "mesh/config/MeshConfiguration.hpp"
#include "utils/Globals.hpp"
#include "utils/xml/XMLTag.hpp"
#include "utils/xml/XMLAttribute.hpp"
#include "utils/xml/ValidatorEquals.hpp"
#include "utils/xml/ValidatorOr.hpp"

namespace precice {
namespace mapping {

tarch::logging::Log MappingConfiguration::
    _log ( "precice::config::ParticipantConfiguration" );

const std::string& MappingConfiguration:: getTag ()
{
  static std::string tag("mapping");
  return tag;
}

MappingConfiguration:: MappingConfiguration
(
  const mesh::PtrMeshConfiguration& meshConfiguration )
:
  ATTR_DIRECTION ( "direction" ),
  ATTR_MESH ( "mesh" ),
  ATTR_STATIONARY ( "stationary" ),
  ATTR_INCREMENTAL ( "incremental" ),
  ATTR_TYPE ( "type" ),
  ATTR_CONSTRAINT("constraint"),
  ATTR_SHAPE_PARAM ( "shape-parameter" ),
  ATTR_SUPPORT_RADIUS ( "support-radius" ),
  VALUE_WRITE ( "write" ),
  VALUE_READ ( "read" ),
  VALUE_CONSISTENT("consistent"),
  VALUE_CONSERVATIVE("conservative"),
  VALUE_NEAREST_NEIGHBOR ( "nearest-neighbor" ),
  VALUE_NEAREST_PROJECTION ( "nearest-projection" ),
  VALUE_RBF_TPS ( "rbf-thin-plate-splines" ),
  VALUE_RBF_MULTIQUADRICS ( "rbf-multiquadrics" ),
  VALUE_RBF_INV_MULTIQUADRICS ( "rbf-inverse-multiquadrics" ),
  VALUE_RBF_VOLUME_SPLINES ( "rbf-volume-splines" ),
  VALUE_RBF_GAUSSIAN ( "rbf-gaussian" ),
  VALUE_RBF_CTPS_C2 ( "rbf-compact-tps-c2" ),
  VALUE_RBF_CPOLYNOMIAL_C0 ( "rbf-compact-polynomial-c0" ),
  VALUE_RBF_CPOLYNOMIAL_C6 ( "rbf-compact-polynomial-c6" ),
  _meshConfig ( meshConfiguration ),
  _isValid ( false ),
  _mappings ()
{
  assertion ( _meshConfig.use_count() > 0 );
}


bool MappingConfiguration:: parseSubtag
(
  utils::XMLTag::XMLReader* xmlReader )
{
  using utils::XMLTag;
  using utils::XMLAttribute;
  using utils::ValidatorEquals;

  XMLTag tagMapping ( getTag(), XMLTag::OCCUR_ONCE );

  XMLAttribute<std::string> attrDirection ( ATTR_DIRECTION );
  ValidatorEquals<std::string> validDirectionWrite ( VALUE_WRITE );
  ValidatorEquals<std::string> validDirectionRead ( VALUE_READ );
  attrDirection.setValidator ( validDirectionWrite || validDirectionRead );
  tagMapping.addAttribute ( attrDirection );

  XMLAttribute<std::string> attrMesh ( ATTR_MESH );
  attrMesh.setDefaultValue ( "" );
  tagMapping.addAttribute ( attrMesh );

  XMLAttribute<std::string> attrType ( ATTR_TYPE );
  typedef ValidatorEquals<std::string> ValidString;
  ValidString validNN ( VALUE_NEAREST_NEIGHBOR );
  ValidString validNP ( VALUE_NEAREST_PROJECTION );
  ValidString validRBFTPS ( VALUE_RBF_TPS );
  ValidString validRBFMultiquadrics ( VALUE_RBF_MULTIQUADRICS );
  ValidString validRBFInvMultiquadrics ( VALUE_RBF_INV_MULTIQUADRICS );
  ValidString validRBFVolumeSplines ( VALUE_RBF_VOLUME_SPLINES );
  ValidString validRBFGaussian ( VALUE_RBF_GAUSSIAN );
  ValidString validRBFCTPSC2 ( VALUE_RBF_CTPS_C2 );
  ValidString validRBFCPolynomialC0 ( VALUE_RBF_CPOLYNOMIAL_C0 );
  ValidString validRBFCPolynomialC6 ( VALUE_RBF_CPOLYNOMIAL_C6 );
  attrType.setValidator ( validNN || validNP || validRBFTPS || validRBFMultiquadrics
      || validRBFInvMultiquadrics || validRBFVolumeSplines || validRBFGaussian
      || validRBFCTPSC2 || validRBFCPolynomialC0 || validRBFCPolynomialC6 );
  tagMapping.addAttribute ( attrType );

  XMLAttribute<std::string> attrConstraint(ATTR_CONSTRAINT);
  ValidString validConservative(VALUE_CONSERVATIVE);
  ValidString validConsistent(VALUE_CONSISTENT);
  attrConstraint.setValidator(validConservative || validConsistent);
  tagMapping.addAttribute(attrConstraint);

  XMLAttribute<bool> attrStationary ( ATTR_STATIONARY );
  attrStationary.setDefaultValue ( false );
  tagMapping.addAttribute ( attrStationary );

  XMLAttribute<bool> attrIncremental ( ATTR_INCREMENTAL );
  attrIncremental.setDefaultValue ( false );
  tagMapping.addAttribute ( attrIncremental );

  XMLAttribute<double> attrShapeParam ( ATTR_SHAPE_PARAM );
  attrShapeParam.setDefaultValue ( 0.0 );
  tagMapping.addAttribute ( attrShapeParam );

  XMLAttribute<double> attrSupportRadius ( ATTR_SUPPORT_RADIUS );
  attrSupportRadius.setDefaultValue ( std::numeric_limits<double>::max() );
  tagMapping.addAttribute ( attrSupportRadius );

  _isValid = tagMapping.parse ( xmlReader, *this );
  return _isValid;
}

bool MappingConfiguration:: xmlTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace1 ( "xmlTagCallback()", callingTag.getName() );
  if ( callingTag.getName() == getTag() ){
    std::string dir = callingTag.getStringAttributeValue(ATTR_DIRECTION);
    std::string mesh = callingTag.getStringAttributeValue(ATTR_MESH);
    std::string type = callingTag.getStringAttributeValue(ATTR_TYPE);
    std::string constraint = callingTag.getStringAttributeValue(ATTR_CONSTRAINT);
    bool stationary = callingTag.getBooleanAttributeValue(ATTR_STATIONARY);
    bool incremental = callingTag.getBooleanAttributeValue(ATTR_INCREMENTAL);
    double shapeParameter = callingTag.getDoubleAttributeValue(ATTR_SHAPE_PARAM);
    double supportRadius = callingTag.getDoubleAttributeValue(ATTR_SUPPORT_RADIUS);
    ConfiguredMapping configuredMapping =
        createMapping ( dir, type, constraint, mesh, stationary, incremental,
                        shapeParameter, supportRadius );
    checkDuplicates ( configuredMapping );
    _mappings.push_back ( configuredMapping );
  }
  return true;
}

bool MappingConfiguration:: xmlEndTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  return true;
}


bool MappingConfiguration:: isValid () const
{
  return _isValid;
}

const std::vector<MappingConfiguration::ConfiguredMapping> &
MappingConfiguration:: mappings ()
{
  return _mappings;
}

void MappingConfiguration:: addMapping
(
  const PtrMapping&    mapping,
  const mesh::PtrMesh& mesh,
  Direction            direction,
  bool                 isIncremental,
  bool                 isStationary )
{
  preciceTrace4 ( "addMapping()", mesh, direction, isStationary, isIncremental );
  assertion ( !(isStationary && isIncremental) );
  ConfiguredMapping configuredMapping;
  configuredMapping.mapping = mapping;
  configuredMapping.mesh = mesh;
  configuredMapping.direction = direction;
  configuredMapping.isIncremental = isIncremental;
  configuredMapping.isStationary = isStationary;
  checkDuplicates ( configuredMapping );
  _mappings.push_back ( configuredMapping );
}

MappingConfiguration::ConfiguredMapping MappingConfiguration:: createMapping
(
  const std::string& direction,
  const std::string& type,
  const std::string& constraint,
  const std::string& meshName,
  bool               stationary,
  bool               incremental,
  double             shapeParameter,
  double             supportRadius ) const
{
  preciceTrace6 ( "createMapping()", direction, type, stationary, incremental,
                  shapeParameter, supportRadius );
  using namespace mapping;

  ConfiguredMapping configuredMapping;

  mesh::PtrMesh mesh ( _meshConfig->getMesh(meshName) );
  preciceCheck ( mesh.use_count() > 0, "createMapping()",
                 "Mesh \"" << meshName << "\" not defined at creation of mapping!" );
  configuredMapping.mesh = mesh;

  preciceCheck ( !(stationary && incremental), "xmlTagCallback()",
                 "A mapping cannot be both stationary and incremental!" );
  configuredMapping.isStationary = stationary;
  configuredMapping.isIncremental = incremental;

  if ( direction == VALUE_WRITE ) {
    configuredMapping.direction =  WRITE;
  }
  else if ( direction == VALUE_READ ) {
    configuredMapping.direction = READ;
  }
  else {
    preciceError("createMapping()",
                 "Unknown direction type \"" << direction << "\"!");
  }

  Mapping::Constraint constraintValue;
  if (constraint == VALUE_CONSERVATIVE){
    constraintValue = Mapping::CONSERVATIVE;
  }
  else if (constraint == VALUE_CONSISTENT){
    constraintValue = Mapping::CONSISTENT;
  }
  else {
    preciceError("createMapping()",
                 "Unknown mapping constraint \"" << constraint << "\"!");
  }

  if (type == VALUE_NEAREST_NEIGHBOR){
    configuredMapping.mapping = PtrMapping (
        new NearestNeighborMapping(constraintValue) );
  }
  else if (type == VALUE_NEAREST_PROJECTION){
//    preciceCheck ( direction == VALUE_WRITE, "createMapping()",
//                   "Attribute \"direction\" has to have value \"" << VALUE_WRITE
//                   << "\" for a " << "mapping of type \""
//                   << VALUE_CONSERVATIVE_NEAREST_PROJECTION << "\"!" );
    configuredMapping.mapping = PtrMapping (
        new NearestProjectionMapping(constraintValue) );
  }
//  else if (type == VALUE_CONSISTENT_NEAREST_PROJECTION){
//    preciceCheck ( direction == VALUE_READ, "createMapping()",
//                   "Attribute \"direction\" has to have value \"" << VALUE_READ
//                   << "\" for a " << "mapping of type \""
//                   << VALUE_CONSISTENT_NEAREST_PROJECTION << "\"!" );
//    configuredMapping.mapping = PtrMapping (
//        new MappingConsistentNearestProjection() );
//  }
  else if (type == VALUE_RBF_TPS){
    configuredMapping.mapping = PtrMapping (
      new RadialBasisFctMapping<ThinPlateSplines>(constraintValue, ThinPlateSplines()) );
  }
  else if (type == VALUE_RBF_MULTIQUADRICS){
    configuredMapping.mapping = PtrMapping (
      new RadialBasisFctMapping<Multiquadrics>(
        constraintValue, Multiquadrics(shapeParameter)) );
  }
  else if (type == VALUE_RBF_INV_MULTIQUADRICS){
    configuredMapping.mapping = PtrMapping (
      new RadialBasisFctMapping<InverseMultiquadrics>(
        constraintValue, InverseMultiquadrics(shapeParameter)) );
  }
  else if (type == VALUE_RBF_VOLUME_SPLINES){
    configuredMapping.mapping = PtrMapping (
      new RadialBasisFctMapping<VolumeSplines>(constraintValue, VolumeSplines()) );
  }
  else if (type == VALUE_RBF_GAUSSIAN){
    configuredMapping.mapping = PtrMapping(
        new RadialBasisFctMapping<Gaussian>(
          constraintValue, Gaussian(shapeParameter)));
  }
  else if (type == VALUE_RBF_CTPS_C2){
    configuredMapping.mapping = PtrMapping (
      new RadialBasisFctMapping<CompactThinPlateSplinesC2>(
        constraintValue, CompactThinPlateSplinesC2(supportRadius)) );
  }
  else if (type == VALUE_RBF_CPOLYNOMIAL_C0){
    configuredMapping.mapping = PtrMapping (
      new RadialBasisFctMapping<CompactPolynomialC0>(
        constraintValue, CompactPolynomialC0(supportRadius)) );
  }
  else if (type == VALUE_RBF_CPOLYNOMIAL_C6){
    configuredMapping.mapping = PtrMapping (
      new RadialBasisFctMapping<CompactPolynomialC6>(
        constraintValue, CompactPolynomialC6(supportRadius)) );
  }
  else {
    preciceError ( "getMapping()", "Unknown mapping type!" );
  }
  assertion ( configuredMapping.mapping.use_count() > 0 );
  return configuredMapping;
}

void MappingConfiguration:: checkDuplicates
(
  const ConfiguredMapping & mapping )
{
  foreach ( const ConfiguredMapping & configuredMapping, _mappings ) {
    bool sameMesh = mapping.mesh->getName() == configuredMapping.mesh->getName();
    bool sameDir = mapping.direction == configuredMapping.direction;
    preciceCheck ( !(sameMesh && sameDir), "checkDuplicates()",
                   "There cannot be two mappings for mesh \""
                   << mapping.mesh->getName() << "\" with same direction!" );
  }
}

}} // namespace precice, mapping
