// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "utils/Globals.hpp"
#include "tarch/logging/Log.h"
#include "utils/Parallel.hpp"
#include "boost/foreach.hpp"
#include "tarch/configuration/ConfigurationRegistry.h"
#include "tarch/configuration/TopLevelConfiguration.h"
#include "tarch/logging/CommandLineLogger.h"
#include "precice/impl/SolverInterfaceImpl.hpp"
#include <iostream>

void printUsage()
{
  std::cout << "Usage:" << std::endl << std::endl;
  std::cout << "Run tests:  ./precicerun test configuration.xml path-to-src" << std::endl;
  std::cout << "Run server: ./precicerun server participant-name configuration.xml" << std::endl;
}

int main ( int argc, char** argv )
{
  // By default, debuggin is turned on with a filter list entry. This removes
  // entry and turns off all debug messages until configuration.
  using namespace tarch::logging;
  CommandLineLogger::getInstance().clearFilterList();
  CommandLineLogger::FilterListEntry filter("", true); // All off
  CommandLineLogger::getInstance().addFilterListEntry(filter);

  using namespace tarch::configuration;
  tarch::logging::Log log("");
# ifndef PRECICE_NO_MPI
  MPI_Init(&argc, &argv); // To prevent auto-init/finalization by preCICE
# endif
  precice::utils::Parallel::initialize(&argc, &argv, "");
  bool runTests = false;
  bool runServer = false;

  if ( argc != 4 ){
    printUsage();
    return 0;
  }
  else if ( std::string(argv[1]) == std::string("server") ){
    runServer = true;
  }
  else if ( std::string(argv[1]) == std::string("test") ){
    runTests = true;
  }
  else {
    printUsage();
    return 0;
  }

  if (runTests){
    assertion(not runServer);
    std::cout << "PreCICE running tests..." << std::endl;
    std::string configFile(argv[2]);
    precice::utils::Globals::setPathToSources(argv[3]);
    std::cout << "   Configuration file = " << configFile << std::endl;
    std::cout << "   Path to sources = " << argv[3] << std::endl;
    std::list<TopLevelConfiguration*> configs =
        ConfigurationRegistry::getInstance().readFile( configFile, "configuration" );
    if (configs.empty()) {
      log.error( "main()", "config file " + configFile + " not found or invalid!" );
      return 0;
    }
    foreach ( TopLevelConfiguration* config, configs ){
      config->interpreteConfiguration();
    }
    ConfigurationRegistry::getInstance().freeConfigurations(configs);
  }
  else if ( runServer ){
    assertion ( not runTests );
    std::cout << "PreCICE running server..." << std::endl;
    std::string participantName ( argv[2] );
    std::string configFile ( argv[3] );
    std::cout << "  Participant = " << participantName << std::endl;
    std::cout << "  Configuration = " << configFile << std::endl;
    int size = precice::utils::Parallel::getCommunicatorSize();
    if ( size != 1 ){
      log.error( "main()", "Server can be run with only one process!" );
    }
    precice::impl::SolverInterfaceImpl server ( participantName, 0, 1, true );
    server.configure(configFile);
    server.runServer();
  }
  else {
    assertion ( false );
  }
  precice::utils::Parallel::finalize();
# ifndef PRECICE_NO_MPI
  MPI_Finalize(); // Reason: see MPI_Init() at beginning of main()
# endif
  return 1;
}

