// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "PostProcessingConfiguration.hpp"
#include "../impl/ConstantRelaxationPostProcessing.hpp"
#include "../impl/AitkenPostProcessing.hpp"
#include "../impl/HierarchicalAitkenPostProcessing.hpp"
#include "../impl/IQNILSPostProcessing.hpp"
#include "mesh/config/MeshConfiguration.hpp"
#include "mesh/Data.hpp"
#include "mesh/Mesh.hpp"
#include "utils/xml/XMLTag.hpp"
#include "utils/xml/XMLAttribute.hpp"
#include "utils/xml/ValidatorEquals.hpp"
#include "utils/xml/ValidatorOr.hpp"
#include "utils/Globals.hpp"

namespace precice {
namespace cplscheme {

const std::string PostProcessingConfiguration::
      TAG_RELAX ( "relaxation" );
const std::string PostProcessingConfiguration::
      TAG_INIT_RELAX ( "initial-relaxation" );
const std::string PostProcessingConfiguration::
      TAG_MAX_USED_ITERATIONS ( "max-used-iterations" );
const std::string PostProcessingConfiguration::
      TAG_TIMESTEPS_REUSED ( "timesteps-reused" );
const std::string PostProcessingConfiguration::
      TAG_SINGULARITY_LIMIT ( "singularity-limit" );

const std::string PostProcessingConfiguration::
      ATTR_DATA ( "data" );
const std::string PostProcessingConfiguration::
      ATTR_MESH ( "mesh" );
const std::string PostProcessingConfiguration::
      ATTR_TYPE ( "type" );
const std::string PostProcessingConfiguration::
      ATTR_VALUE ( "value" );

const std::string PostProcessingConfiguration::
      VALUE_CONSTANT ( "constant" );
const std::string PostProcessingConfiguration::
      VALUE_AITKEN  ( "aitken" );
const std::string PostProcessingConfiguration::
    VALUE_HIERARCHICAL_AITKEN ( "hierarchical-aitken" );
const std::string PostProcessingConfiguration::
      VALUE_IQNILS  ( "IQN-ILS" );

tarch::logging::Log PostProcessingConfiguration::
      _log ( "precice::cplscheme::PostProcessingConfiguration" );

const std::string & PostProcessingConfiguration:: getTag ()
{
  static std::string tag ( "post-processing" );
  return tag;
}

PostProcessingConfiguration:: PostProcessingConfiguration
(
   const mesh::PtrMeshConfiguration meshConfig )
:
   _isValid ( false ),
   _meshConfig ( meshConfig ),
   _postProcessing (),
   _config ()
{
   assertion ( meshConfig.get() != NULL );
}

bool PostProcessingConfiguration:: parseSubtag
(
   tarch::irr::io::IrrXMLReader * xmlReader )
{
   preciceTrace ( "parseSubtag()" );
   using namespace utils;

   XMLTag tag ( getTag(), XMLTag::OCCUR_ONCE );

   XMLAttribute<std::string> attrType ( ATTR_TYPE );
   ValidatorEquals<std::string> validConstant ( VALUE_CONSTANT );
   ValidatorEquals<std::string> validAitken ( VALUE_AITKEN );
   ValidatorEquals<std::string> validHierarchAitken ( VALUE_HIERARCHICAL_AITKEN );
   ValidatorEquals<std::string> validIQNILS ( VALUE_IQNILS );
   attrType.setValidator (
       validConstant || validAitken || validHierarchAitken|| validIQNILS );
   tag.addAttribute ( attrType );

   XMLAttribute<std::string> attrData ( ATTR_DATA );
   tag.addAttribute ( attrData );

   XMLAttribute<std::string> attrMesh ( ATTR_MESH );
   tag.addAttribute ( attrMesh );

   _isValid = tag.parse ( xmlReader, *this );
   _config = ConfigurationData ();
   return _isValid;
}

bool PostProcessingConfiguration:: isValid () const
{
   return _isValid;
}

impl::PtrIPostProcessing PostProcessingConfiguration:: getPostProcessing ()
{
   return _postProcessing;
}

bool PostProcessingConfiguration:: xmlTagCallback
(
  utils::XMLTag&           callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace1 ( "xmlTagCallback()", callingTag.getName() );
  if ( callingTag.getName() == getTag() ) {
    std::string dataName = callingTag.getStringAttributeValue(ATTR_DATA);
    std::string meshName = callingTag.getStringAttributeValue(ATTR_MESH);
    foreach ( mesh::PtrMesh mesh, _meshConfig->meshes() ) {
      if ( mesh->getName() == meshName ) {
        foreach ( mesh::PtrData data, mesh->data() ) {
          if ( dataName == data->getName() ) {
            assertion ( _config.dataID == -1 );
            _config.dataID = data->getID();
          }
        }
      }
    }
    preciceCheck ( _config.dataID != -1,
      "xmlTagCallback()", "Data with name \"" << dataName
      << "\" associated to mesh \"" << meshName
      << "\" not found on configuration of post-processing!" );
    _config.type = callingTag.getStringAttributeValue(ATTR_TYPE);
    addTypeSpecificSubtags ( callingTag );
  }
  else if ( callingTag.getName() == TAG_RELAX ) {
    _config.relaxationFactor = callingTag.getDoubleAttributeValue(ATTR_VALUE);
  }
  else if ( callingTag.getName() == TAG_INIT_RELAX ) {
    _config.relaxationFactor = callingTag.getDoubleAttributeValue(ATTR_VALUE);
  }
  else if ( callingTag.getName() == TAG_MAX_USED_ITERATIONS ) {
    _config.maxIterationsUsed = callingTag.getIntAttributeValue(ATTR_VALUE);
  }
  else if ( callingTag.getName() == TAG_TIMESTEPS_REUSED ) {
    _config.timestepsReused = callingTag.getIntAttributeValue(ATTR_VALUE);
  }
  else if ( callingTag.getName() == TAG_SINGULARITY_LIMIT ) {
    _config.singularityLimit = callingTag.getDoubleAttributeValue(ATTR_VALUE);
  }
  return true;
}

bool PostProcessingConfiguration:: xmlEndTagCallback
(
   utils::XMLTag         & callingTag,
   tarch::irr::io::IrrXMLReader * xmlReader )
{
  preciceTrace1 ( "xmlEndTagCallback()", callingTag.getName() );
  if ( callingTag.getName() == getTag() ) {
    if ( _config.type == VALUE_CONSTANT ) {
      _postProcessing = impl::PtrIPostProcessing (
          new impl::ConstantRelaxationPostProcessing (
          _config.relaxationFactor, _config.dataID) );
    }
    else if ( _config.type == VALUE_AITKEN ) {
      _postProcessing = impl::PtrIPostProcessing (
          new impl::AitkenPostProcessing(
          _config.relaxationFactor, _config.dataID) );
    }
    else if ( _config.type == VALUE_HIERARCHICAL_AITKEN ) {
      _postProcessing = impl::PtrIPostProcessing (
          new impl::HierarchicalAitkenPostProcessing (
          _config.relaxationFactor, _config.dataID) );
    }
    else if ( _config.type == VALUE_IQNILS ) {
      _postProcessing = impl::PtrIPostProcessing (
          new impl::IQNILSPostProcessing(
          _config.relaxationFactor, _config.maxIterationsUsed,
          _config.timestepsReused, _config.singularityLimit,
          _config.dataID) );
    }
    else {
      assertion ( false );
    }
  }
  return true;
}

void PostProcessingConfiguration:: addTypeSpecificSubtags
(
   utils::XMLTag & tag )
{
   using namespace utils;
   if ( _config.type == VALUE_CONSTANT ) {
      XMLTag tagRelax ( TAG_RELAX, XMLTag::OCCUR_ONCE );
      XMLAttribute<double> attrValue ( ATTR_VALUE );
      tagRelax.addAttribute ( attrValue );
      tag.addSubtag ( tagRelax );
   }
   else if ( _config.type == VALUE_AITKEN ) {
      XMLTag tagInitRelax ( TAG_INIT_RELAX, XMLTag::OCCUR_ONCE );
      XMLAttribute<double> attrValue ( ATTR_VALUE );
      tagInitRelax.addAttribute ( attrValue );
      tag.addSubtag ( tagInitRelax );
   }
   else if ( _config.type == VALUE_HIERARCHICAL_AITKEN ) {
      XMLTag tagInitRelax ( TAG_INIT_RELAX, XMLTag::OCCUR_ONCE );
      XMLAttribute<double> attrValue ( ATTR_VALUE );
      tagInitRelax.addAttribute ( attrValue );
      tag.addSubtag ( tagInitRelax );
   }
   else if ( _config.type == VALUE_IQNILS ) {
      XMLTag tagInitRelax ( TAG_INIT_RELAX, XMLTag::OCCUR_ONCE );
      XMLAttribute<double> attrDoubleValue ( ATTR_VALUE );
      tagInitRelax.addAttribute ( attrDoubleValue );
      tag.addSubtag ( tagInitRelax );

      XMLTag tagMaxUsedIter ( TAG_MAX_USED_ITERATIONS, XMLTag::OCCUR_ONCE );
      XMLAttribute<int> attrIntValue ( ATTR_VALUE );
      tagMaxUsedIter.addAttribute ( attrIntValue );
      tag.addSubtag ( tagMaxUsedIter );

      XMLTag tagTimestepsReused ( TAG_TIMESTEPS_REUSED, XMLTag::OCCUR_ONCE );
      tagTimestepsReused.addAttribute ( attrIntValue );
      tag.addSubtag ( tagTimestepsReused );

      XMLTag tagSingularityLimit ( TAG_SINGULARITY_LIMIT, XMLTag::OCCUR_ONCE );
      tagSingularityLimit.addAttribute ( attrDoubleValue );
      tag.addSubtag ( tagSingularityLimit );
   }
   else {
      preciceError ( "addTypeSpecificSubtag()", "Post-processing of type \""
                     << _config.type << "\" is unknown!" );
   }
}

}} // namespace precice, cplscheme
