// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "CouplingSchemeConfiguration.hpp"
#include "cplscheme/config/PostProcessingConfiguration.hpp"
#include "cplscheme/ExplicitCouplingScheme.hpp"
#include "cplscheme/ImplicitCouplingScheme.hpp"
#include "cplscheme/impl/IConvergenceMeasure.hpp"
#include "cplscheme/impl/AbsoluteConvergenceMeasure.hpp"
#include "cplscheme/impl/RelativeConvergenceMeasure.hpp"
#include "cplscheme/impl/ResidualRelativeConvergenceMeasure.hpp"
#include "cplscheme/impl/MinIterationConvergenceMeasure.hpp"
#include "cplscheme/impl/IPostProcessing.hpp"
#include "cplscheme/SharedPointer.hpp"
#include "mesh/config/MeshConfiguration.hpp"
#include "mesh/config/DataConfiguration.hpp"
#include "com/Communication.hpp"
#include "com/config/CommunicationConfiguration.hpp"
#include "utils/Globals.hpp"
#include "utils/Dimensions.hpp"
#include "utils/xml/XMLAttribute.hpp"
#include "utils/xml/ValidatorEquals.hpp"
#include "utils/xml/ValidatorOr.hpp"
#include "utils/xml/XMLTag.hpp"
#include "precice/impl/SharedPointer.hpp"
#include "precice/impl/Participant.hpp"



namespace precice {
namespace cplscheme {

using precice::impl::PtrParticipant;

tarch::logging::Log CouplingSchemeConfiguration::
   _log ( "precice::cplscheme::CouplingSchemeConfiguration" );

const std::string CouplingSchemeConfiguration::
   ATTR_TYPE ( "type" );
const std::string CouplingSchemeConfiguration::
   VALUE_EXPLICIT ( "explicit" );
const std::string CouplingSchemeConfiguration::
   VALUE_IMPLICIT ( "implicit" );
const std::string CouplingSchemeConfiguration::
   VALUE_UNCOUPLED ( "uncoupled" );

const std::string CouplingSchemeConfiguration::
   TagParticipants::TAG ( "participants" );
const std::string CouplingSchemeConfiguration::
   TagParticipants::ATTR_FIRST ( "first" );
const std::string CouplingSchemeConfiguration::
   TagParticipants::ATTR_SECOND ( "second" );

const std::string CouplingSchemeConfiguration::
   TagExchange::TAG ( "exchange" );
const std::string CouplingSchemeConfiguration::
   TagExchange::ATTR_DATA ( "data" );
const std::string CouplingSchemeConfiguration::
   TagExchange::ATTR_MESH ( "mesh" );
const std::string CouplingSchemeConfiguration::
   TagExchange::ATTR_PARTICIPANT ( "from" );
const std::string CouplingSchemeConfiguration::
   TagExchange::ATTR_INITIALIZE ( "initialize" );

const std::string CouplingSchemeConfiguration::
   TagMaxTime::TAG ( "max-time" );
const std::string CouplingSchemeConfiguration::
   TagMaxTime::ATTR_VALUE ( "value" );

const std::string CouplingSchemeConfiguration::
   TagMaxTimesteps::TAG ( "max-timesteps" );
const std::string CouplingSchemeConfiguration::
   TagMaxTimesteps::ATTR_VALUE ( "value" );

const std::string CouplingSchemeConfiguration::
   TagTimestepLength::TAG ( "timestep-length" );
const std::string CouplingSchemeConfiguration::
   TagTimestepLength::ATTR_VALUE ( "value" );
const std::string CouplingSchemeConfiguration::
   TagTimestepLength::ATTR_VALID_DIGITS ( "valid-digits" );
const std::string CouplingSchemeConfiguration::
   TagTimestepLength::ATTR_METHOD ( "method" );
const std::string CouplingSchemeConfiguration::
  TagTimestepLength::VALUE_FIXED ( "fixed" );
const std::string CouplingSchemeConfiguration::
  TagTimestepLength::VALUE_FIRST_PARTICIPANT ( "first-participant" );
//const std::string CouplingSchemeConfiguration::
//  TagTimestepLength::VALUE_SECOND_PARTICIPANT ( "second-participant" );

const std::string CouplingSchemeConfiguration::
   TagAbsoluteConvergenceMeasure::TAG ( "absolute-convergence-measure" );
const std::string CouplingSchemeConfiguration::
   TagAbsoluteConvergenceMeasure::ATTR_DATA ( "data" );
const std::string CouplingSchemeConfiguration::
   TagAbsoluteConvergenceMeasure::ATTR_MESH ( "mesh" );
const std::string CouplingSchemeConfiguration::
   TagAbsoluteConvergenceMeasure::ATTR_LIMIT ( "limit" );

const std::string CouplingSchemeConfiguration::
   TagRelativeConvergenceMeasure::TAG ( "relative-convergence-measure" );
const std::string CouplingSchemeConfiguration::
   TagRelativeConvergenceMeasure::ATTR_DATA ( "data" );
const std::string CouplingSchemeConfiguration::
   TagRelativeConvergenceMeasure::ATTR_MESH ( "mesh" );
const std::string CouplingSchemeConfiguration::
   TagRelativeConvergenceMeasure::ATTR_LIMIT ( "limit" );

const std::string CouplingSchemeConfiguration::
   TagResidualRelativeConvergenceMeasure::TAG ( "residual-relative-convergence-measure" );
const std::string CouplingSchemeConfiguration::
   TagResidualRelativeConvergenceMeasure::ATTR_DATA ( "data" );
const std::string CouplingSchemeConfiguration::
   TagResidualRelativeConvergenceMeasure::ATTR_MESH ( "mesh" );
const std::string CouplingSchemeConfiguration::
   TagResidualRelativeConvergenceMeasure::ATTR_LIMIT ( "limit" );

const std::string CouplingSchemeConfiguration::
   TagMinIterationConvergenceMeasure::TAG ( "min-iteration-convergence-measure" );
const std::string CouplingSchemeConfiguration::
   TagMinIterationConvergenceMeasure::ATTR_DATA ( "data" );
const std::string CouplingSchemeConfiguration::
   TagMinIterationConvergenceMeasure::ATTR_MESH ( "mesh" );
const std::string CouplingSchemeConfiguration::
   TagMinIterationConvergenceMeasure::ATTR_MIN_ITERATIONS ( "min-iteration-limit" );

const std::string CouplingSchemeConfiguration::
   TagMaxIterations:: TAG ( "max-iterations" );
const std::string CouplingSchemeConfiguration::
   TagMaxIterations:: ATTR_VALUE ( "value" );

const std::string CouplingSchemeConfiguration::
   TagCheckpoint:: TAG ( "checkpoint" );
const std::string CouplingSchemeConfiguration::
   TagCheckpoint:: ATTR_TIMESTEP_INTERVAL ( "timestep-interval" );

const std::string CouplingSchemeConfiguration::
   TagExtrapolation:: TAG ( "extrapolation-order" );
const std::string CouplingSchemeConfiguration::
   TagExtrapolation:: ATTR_VALUE ( "value" );


const std::string& CouplingSchemeConfiguration:: getTag()
{
  static std::string tag ( "coupling-scheme" );
  return tag;
}

CouplingSchemeConfiguration:: CouplingSchemeConfiguration
(
  const mesh::PtrMeshConfiguration&         meshConfig,
  const com::PtrCommunicationConfiguration& comConfig )
:
  _config (),
  _meshConfig ( meshConfig ),
  _comConfig ( comConfig ),
  _isValid ( false ),
  _couplingSchemes ()
{}

bool CouplingSchemeConfiguration:: parseSubtag
(
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceCheck ( _couplingSchemes.size() == 0, "parseSubtag()",
                 "Only one tag <coupling-scheme> can be defined!" );
  utils::XMLTag tag ( getTag(), utils::XMLTag::OCCUR_ONCE );

  utils::XMLAttribute<std::string> attrType ( ATTR_TYPE );
  utils::ValidatorEquals<std::string> validExplicitScheme ( VALUE_EXPLICIT );
  utils::ValidatorEquals<std::string> validImplicitScheme ( VALUE_IMPLICIT );
  utils::ValidatorEquals<std::string> validUncoupledScheme ( VALUE_UNCOUPLED );
  attrType.setValidator ( validExplicitScheme || validImplicitScheme ||
                          validUncoupledScheme );
  tag.addAttribute ( attrType );

  utils::XMLTag tagPostProcessing ( PostProcessingConfiguration::getTag(),
                                    utils::XMLTag::OCCUR_NOT_OR_ONCE );
  tag.addSubtag ( tagPostProcessing );

  _isValid = tag.parse ( xmlReader, *this );
  return _isValid;
}

bool CouplingSchemeConfiguration:: isValid () const
{
  bool valid = true;
  valid &= _isValid;
  valid &= _couplingSchemes.size() == 2;
  return valid;
}

const PtrCouplingScheme& CouplingSchemeConfiguration:: getCouplingScheme
(
  const std::string & participantName ) const
{
  preciceCheck ( utils::contained(participantName, _couplingSchemes),
                 "getCouplingScheme()", "No coupling scheme defined for "
                 << "participant \"" << participantName << "\"!" );
  return _couplingSchemes.find(participantName)->second;
}

bool CouplingSchemeConfiguration:: xmlTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace1 ( "xmlTagCallback()", callingTag.getName() );
  if ( callingTag.getName() == getTag() ) {
    _config.type = callingTag.getStringAttributeValue(ATTR_TYPE);
    std::string name = xmlReader->getNodeData ();
    addTypespecifcSubtags ( _config.type, name, callingTag );
  }
  else if ( callingTag.getName() == TagCheckpoint::TAG ) {
    _config.checkpointTimestepInterval =
      callingTag.getIntAttributeValue(TagCheckpoint::ATTR_TIMESTEP_INTERVAL);
  }
  else if ( callingTag.getName() == TagParticipants::TAG ) {
    assertion ( _config.type != VALUE_UNCOUPLED );
    std::string first = callingTag.getStringAttributeValue(
        TagParticipants::ATTR_FIRST);
    std::string second = callingTag.getStringAttributeValue(
        TagParticipants::ATTR_SECOND);
    _config.participant = first;
    _config.secondParticipant = second;
  }
  else if ( callingTag.getName() == TagMaxTime::TAG ) {
    double maxTime =
        callingTag.getDoubleAttributeValue(TagMaxTime::ATTR_VALUE);
    _config.maxTime = maxTime;
  }
  else if ( callingTag.getName() == TagMaxTimesteps::TAG ) {
    int maxTimesteps =
        callingTag.getIntAttributeValue(TagMaxTimesteps::ATTR_VALUE);
    _config.maxTimesteps = maxTimesteps;
  }
  else if ( callingTag.getName() == TagTimestepLength::TAG ) {
    _config.timestepLength =
        callingTag.getDoubleAttributeValue(TagTimestepLength::ATTR_VALUE);
    _config.validDigits =
        callingTag.getIntAttributeValue(TagTimestepLength::ATTR_VALID_DIGITS);
    _config.dtMethod = getTimesteppingMethod(
        callingTag.getStringAttributeValue(TagTimestepLength::ATTR_METHOD));
  }
  else if ( callingTag.getName() == TagAbsoluteConvergenceMeasure::TAG ) {
    std::string dataName = callingTag.getStringAttributeValue(
        TagAbsoluteConvergenceMeasure::ATTR_DATA);
    std::string meshName = callingTag.getStringAttributeValue(
        TagAbsoluteConvergenceMeasure::ATTR_MESH);
    double limit = callingTag.getDoubleAttributeValue(
        TagAbsoluteConvergenceMeasure::ATTR_LIMIT);
    assertion ( _config.type == VALUE_IMPLICIT );
    addAbsoluteConvergenceMeasure ( dataName, meshName, limit );
  }
  else if ( callingTag.getName() == TagRelativeConvergenceMeasure::TAG ) {
    std::string dataName = callingTag.getStringAttributeValue (
        TagRelativeConvergenceMeasure::ATTR_DATA);
    std::string meshName = callingTag.getStringAttributeValue(
        TagRelativeConvergenceMeasure::ATTR_MESH);
    double limit = callingTag.getDoubleAttributeValue(
        TagRelativeConvergenceMeasure::ATTR_LIMIT);
    assertion ( _config.type == VALUE_IMPLICIT );
    addRelativeConvergenceMeasure ( dataName, meshName, limit );
  }
  else if ( callingTag.getName() == TagResidualRelativeConvergenceMeasure::TAG ) {
    std::string dataName = callingTag.getStringAttributeValue (
        TagResidualRelativeConvergenceMeasure::ATTR_DATA);
    std::string meshName = callingTag.getStringAttributeValue(
        TagResidualRelativeConvergenceMeasure::ATTR_MESH);
    double limit = callingTag.getDoubleAttributeValue(
        TagResidualRelativeConvergenceMeasure::ATTR_LIMIT);
    assertion ( _config.type == VALUE_IMPLICIT );
    addResidualRelativeConvergenceMeasure ( dataName, meshName, limit );
  }
  else if ( callingTag.getName() == TagMinIterationConvergenceMeasure::TAG ) {
    std::string dataName = callingTag.getStringAttributeValue(
        TagMinIterationConvergenceMeasure::ATTR_DATA);
    std::string meshName = callingTag.getStringAttributeValue(
        TagMinIterationConvergenceMeasure::ATTR_MESH);
    int minIterations = callingTag.getIntAttributeValue(
        TagMinIterationConvergenceMeasure::ATTR_MIN_ITERATIONS);
    assertion ( _config.type == VALUE_IMPLICIT );
    addMinIterationConvergenceMeasure ( dataName, meshName, minIterations );
  }
  else if ( callingTag.getName() == TagExchange::TAG ) {
    assertion ( _config.type != VALUE_UNCOUPLED );
    std::string nameData =
        callingTag.getStringAttributeValue(TagExchange::ATTR_DATA);
    std::string nameMesh =
        callingTag.getStringAttributeValue(TagExchange::ATTR_MESH);
    std::string nameParticipant =
        callingTag.getStringAttributeValue(TagExchange::ATTR_PARTICIPANT);
    bool initialize =
        callingTag.getBooleanAttributeValue(TagExchange::ATTR_INITIALIZE);
    mesh::PtrData exchangeData;
    foreach ( mesh::PtrMesh mesh, _meshConfig->meshes() ) {
      if ( mesh->getName() == nameMesh ) {
        foreach ( mesh::PtrData data, mesh->data() ) {
          if ( data->getName() == nameData ) {
            exchangeData = data;
            break;
          }
        }
      }
    }
    preciceCheck ( exchangeData.get() != NULL, "xmlTagCallback()",
      "Mesh \"" << nameMesh << "\" with data \"" << nameData <<
      "\" not defined at definition of coupling scheme \""
      << _config.name << "\"!" );
    _config.exchanges.push_back ( boost::make_tuple(exchangeData,
      nameParticipant, initialize) );
  }
  else if ( callingTag.getName() == TagMaxIterations::TAG ) {
    assertion ( _config.type == VALUE_IMPLICIT );
    _config.maxIterations =
        callingTag.getIntAttributeValue(TagMaxIterations::ATTR_VALUE);
  }
  else if ( callingTag.getName() == TagExtrapolation::TAG ) {
    assertion ( _config.type == VALUE_IMPLICIT );
    _config.extrapolationOrder =
        callingTag.getIntAttributeValue(TagExtrapolation::ATTR_VALUE);
  }
  else if ( callingTag.getName() == PostProcessingConfiguration::getTag() ) {
    PostProcessingConfiguration config ( _meshConfig );
    if ( config.parseSubtag(xmlReader) ) {
      _config.postProcessing = config.getPostProcessing ();
    }
    else {
      return false;
    }
  }
  return true;
}

bool CouplingSchemeConfiguration:: xmlEndTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace1 ( "xmlEndTagCallback()", callingTag.getName() );
  if ( _config.type == VALUE_EXPLICIT ) {
    std::string accessor ( _config.participant );
    PtrCouplingScheme scheme = createExplicitCouplingScheme ( accessor );
    _couplingSchemes[accessor] = scheme;
    accessor = _config.secondParticipant;
    scheme = createExplicitCouplingScheme ( accessor );
    _couplingSchemes[accessor] = scheme;
    _config = Config();
  }
  else if ( _config.type == VALUE_IMPLICIT ) {
    std::string accessor ( _config.participant );
    PtrCouplingScheme scheme = createImplicitCouplingScheme ( accessor );
    _couplingSchemes[accessor] = scheme;
    accessor = _config.secondParticipant;
    scheme = createImplicitCouplingScheme ( accessor );
    _couplingSchemes[accessor] = scheme;
    _config = Config();
  }
  else if ( _config.type == VALUE_UNCOUPLED ) {
    assertion ( false );
  }
  else {
    assertion ( false );
  }
  return true;
}

void CouplingSchemeConfiguration:: addCouplingScheme
(
  PtrCouplingScheme cplScheme,
  const std::string&        participantName )
{
  preciceTrace1 ( "addCouplingScheme()", participantName );
  assertion1 ( _couplingSchemes.find(participantName) == _couplingSchemes.end(),
               participantName );
  _couplingSchemes[participantName] = cplScheme;
}

void CouplingSchemeConfiguration:: addTypespecifcSubtags
(
  const std::string& type,
  const std::string& name,
  utils::XMLTag&     callingTag  )
{
  addTransientLimitTags ( callingTag );
  _config.type = type;
  _config.name = name;

  addTagCheckpoint ( callingTag );

  if ( type == VALUE_EXPLICIT ) {
    addTagParticipants ( callingTag );
    addTagExchange ( callingTag );
  }
  else if ( type == VALUE_IMPLICIT ) {
    addTagParticipants ( callingTag );
    addTagExchange ( callingTag );
    addTagAbsoluteConvergenceMeasure ( callingTag );
    addTagRelativeConvergenceMeasure ( callingTag );
    addTagResidualRelativeConvergenceMeasure ( callingTag );
    addTagMinIterationConvergenceMeasure ( callingTag );
    addTagMaxIterations ( callingTag );
    addTagExtrapolation ( callingTag );
  }
  else if ( type == VALUE_UNCOUPLED ) {
  }
  else {
    preciceError ( "addTypespecificSubtags(.)", "Unknown coupling scheme type!" );
  }
}

void CouplingSchemeConfiguration:: addTagCheckpoint
(
   utils::XMLTag & tag )
{
   utils::XMLTag tagCheckpoint ( TagCheckpoint::TAG, utils::XMLTag::OCCUR_NOT_OR_ONCE );
   utils::XMLAttribute<int> attrTimestepInterval (
      TagCheckpoint::ATTR_TIMESTEP_INTERVAL );
//   utils::ValidatorGreaterThan<int> validTimestepInterval ( 0 );
//   attrTimestepInterval.setValidator ( validTimestepInterval );
   tagCheckpoint.addAttribute ( attrTimestepInterval );
   tag.addSubtag ( tagCheckpoint );
}

void CouplingSchemeConfiguration:: addTransientLimitTags
(
   utils::XMLTag & tag )
{
  using namespace utils;
  XMLTag tagMaxTime ( TagMaxTime::TAG, XMLTag::OCCUR_NOT_OR_ONCE );
  XMLAttribute<double> attrValueMaxTime ( TagMaxTime::ATTR_VALUE );
  tagMaxTime.addAttribute ( attrValueMaxTime );
  tag.addSubtag ( tagMaxTime );

  XMLTag tagMaxTimesteps ( TagMaxTimesteps::TAG, XMLTag::OCCUR_NOT_OR_ONCE );
  XMLAttribute<int> attrValueMaxTimesteps ( TagMaxTimesteps::ATTR_VALUE );
  tagMaxTimesteps.addAttribute ( attrValueMaxTimesteps );
  tag.addSubtag ( tagMaxTimesteps );

  XMLTag tagTimestepLength ( TagTimestepLength::TAG, XMLTag::OCCUR_ONCE );
  XMLAttribute<double> attrValueTimestepLength ( TagTimestepLength::ATTR_VALUE );
  attrValueTimestepLength.setDefaultValue(CouplingScheme::UNDEFINED_TIMESTEP_LENGTH);
  tagTimestepLength.addAttribute ( attrValueTimestepLength );
  XMLAttribute<int> attrValidDigits ( TagTimestepLength::ATTR_VALID_DIGITS );
  attrValidDigits.setDefaultValue ( 10 );
  tagTimestepLength.addAttribute ( attrValidDigits );
  XMLAttribute<std::string> attrMethod ( TagTimestepLength::ATTR_METHOD );
  attrMethod.setDefaultValue ( TagTimestepLength::VALUE_FIXED );
  ValidatorEquals<std::string> validFixed ( TagTimestepLength::VALUE_FIXED );
  ValidatorEquals<std::string> validFirst ( TagTimestepLength::VALUE_FIRST_PARTICIPANT );
//  ValidatorEquals<std::string> validSec ( TagTimestepLength::VALUE_SECOND_PARTICIPANT );
  attrMethod.setValidator ( validFixed || validFirst );
  tagTimestepLength.addAttribute ( attrMethod );
  tag.addSubtag ( tagTimestepLength );
}

void CouplingSchemeConfiguration:: addTagParticipants
(
  utils::XMLTag & tag )
{
  using namespace utils;
  XMLTag tagParticipants ( TagParticipants::TAG, XMLTag::OCCUR_ONCE );
  XMLAttribute<std::string> attrFirst ( TagParticipants::ATTR_FIRST );
  tagParticipants.addAttribute ( attrFirst );
  XMLAttribute<std::string> attrSecond ( TagParticipants::ATTR_SECOND );
  tagParticipants.addAttribute ( attrSecond );
  tag.addSubtag ( tagParticipants );
}

void CouplingSchemeConfiguration:: addTagExchange
(
  utils::XMLTag & tag )
{
  using namespace utils;
  XMLTag tagExchange ( TagExchange::TAG, XMLTag::OCCUR_ONCE_OR_MORE );
  XMLAttribute<std::string> attrData ( TagExchange::ATTR_DATA );
  tagExchange.addAttribute ( attrData );
  XMLAttribute<std::string> attrMesh ( TagExchange::ATTR_MESH );
  tagExchange.addAttribute ( attrMesh );
  XMLAttribute<std::string> participant ( TagExchange::ATTR_PARTICIPANT );
  tagExchange.addAttribute ( participant );
  XMLAttribute<bool> attrInitialize ( TagExchange::ATTR_INITIALIZE );
  attrInitialize.setDefaultValue ( false );
  tagExchange.addAttribute ( attrInitialize );
  tag.addSubtag ( tagExchange );
}

void CouplingSchemeConfiguration:: addTagAbsoluteConvergenceMeasure
(
  utils::XMLTag & tag )
{
  using namespace utils;
  XMLTag tagConvergenceMeasure ( TagAbsoluteConvergenceMeasure::TAG,
                                 XMLTag::OCCUR_ARBITRARY );
  XMLAttribute<std::string> attrData ( TagAbsoluteConvergenceMeasure::ATTR_DATA );
  tagConvergenceMeasure.addAttribute ( attrData );
  XMLAttribute<std::string> attrMesh ( TagAbsoluteConvergenceMeasure::ATTR_MESH );
  tagConvergenceMeasure.addAttribute ( attrMesh );
  XMLAttribute<double> attrLimit ( TagAbsoluteConvergenceMeasure::ATTR_LIMIT );
  tagConvergenceMeasure.addAttribute ( attrLimit );
  tag.addSubtag ( tagConvergenceMeasure );
}

void CouplingSchemeConfiguration:: addTagRelativeConvergenceMeasure
(
  utils::XMLTag & tag )
{
  using namespace utils;
  XMLTag tagConvergenceMeasure ( TagRelativeConvergenceMeasure::TAG,
                                 XMLTag::OCCUR_ARBITRARY );
  XMLAttribute<std::string> attrData ( TagRelativeConvergenceMeasure::ATTR_DATA );
  tagConvergenceMeasure.addAttribute ( attrData );
  XMLAttribute<std::string> attrMesh ( TagAbsoluteConvergenceMeasure::ATTR_MESH );
  tagConvergenceMeasure.addAttribute ( attrMesh );
  XMLAttribute<double> attrLimit ( TagRelativeConvergenceMeasure::ATTR_LIMIT );
  tagConvergenceMeasure.addAttribute ( attrLimit );
  tag.addSubtag ( tagConvergenceMeasure );
}

void CouplingSchemeConfiguration:: addTagResidualRelativeConvergenceMeasure
(
  utils::XMLTag& tag )
{
  using namespace utils;
  XMLTag tagConvergenceMeasure ( TagResidualRelativeConvergenceMeasure::TAG,
                                 XMLTag::OCCUR_ARBITRARY );
  XMLAttribute<std::string> attrData (
      TagResidualRelativeConvergenceMeasure::ATTR_DATA );
  tagConvergenceMeasure.addAttribute ( attrData );
  XMLAttribute<std::string> attrMesh (
      TagResidualRelativeConvergenceMeasure::ATTR_MESH );
  tagConvergenceMeasure.addAttribute ( attrMesh );
  XMLAttribute<double> attrLimit (
        TagResidualRelativeConvergenceMeasure::ATTR_LIMIT );
  tagConvergenceMeasure.addAttribute ( attrLimit );
  tag.addSubtag ( tagConvergenceMeasure );
}

void CouplingSchemeConfiguration:: addTagMinIterationConvergenceMeasure
(
  utils::XMLTag& tag )
{
  utils::XMLTag tagMinIterationConvMeasure (
    TagMinIterationConvergenceMeasure::TAG, utils::XMLTag::OCCUR_ARBITRARY );
  utils::XMLAttribute<std::string> attrData (
    TagMinIterationConvergenceMeasure::ATTR_DATA );
  tagMinIterationConvMeasure.addAttribute ( attrData );
  utils::XMLAttribute<std::string>
  attrMesh ( TagAbsoluteConvergenceMeasure::ATTR_MESH );
  tagMinIterationConvMeasure.addAttribute ( attrMesh );
  utils::XMLAttribute<int> attrMinIterations (
    TagMinIterationConvergenceMeasure::ATTR_MIN_ITERATIONS );
  tagMinIterationConvMeasure.addAttribute ( attrMinIterations );
  tag.addSubtag ( tagMinIterationConvMeasure );
}

void CouplingSchemeConfiguration:: addTagMaxIterations
(
  utils::XMLTag & tag )
{
  using namespace utils;
  XMLTag tagMaxIterations ( TagMaxIterations::TAG, XMLTag::OCCUR_NOT_OR_ONCE );
  XMLAttribute<int> attrValue ( TagMaxIterations::ATTR_VALUE );
  tagMaxIterations.addAttribute ( attrValue );
  tag.addSubtag ( tagMaxIterations );
}

void CouplingSchemeConfiguration:: addTagExtrapolation
(
  utils::XMLTag& tag )
{
  using namespace utils;
  XMLTag tagExtrapolation ( TagExtrapolation::TAG, XMLTag::OCCUR_NOT_OR_ONCE );
  XMLAttribute<int> attrValue ( TagExtrapolation::ATTR_VALUE );
  tagExtrapolation.addAttribute ( attrValue );
  tag.addSubtag ( tagExtrapolation );
}

void CouplingSchemeConfiguration:: addAbsoluteConvergenceMeasure
(
  const std::string& dataName,
  const std::string& meshName,
  double             limit )
{
  impl::PtrIConvergenceMeasure measure(new impl::AbsoluteConvergenceMeasure(limit));
  int dataID = getData(dataName, meshName)->getID();
  _config.convMeasures.push_back ( boost::make_tuple(dataID, measure) );
}

void CouplingSchemeConfiguration:: addRelativeConvergenceMeasure
(
  const std::string& dataName,
  const std::string& meshName,
  double             limit )
{
  impl::PtrIConvergenceMeasure measure (
      new impl::RelativeConvergenceMeasure(limit) );
  int dataID = getData(dataName, meshName)->getID();
  _config.convMeasures.push_back ( boost::make_tuple(dataID, measure) );
}

void CouplingSchemeConfiguration:: addResidualRelativeConvergenceMeasure
(
  const std::string& dataName,
  const std::string& meshName,
  double             limit )
{
  impl::PtrIConvergenceMeasure measure (
      new impl::ResidualRelativeConvergenceMeasure(limit) );
  int dataID = getData(dataName, meshName)->getID();
  _config.convMeasures.push_back ( boost::make_tuple(dataID, measure) );
}

void CouplingSchemeConfiguration:: addMinIterationConvergenceMeasure
(
  const std::string& dataName,
  const std::string& meshName,
  int                minIterations )
{
  impl::PtrIConvergenceMeasure measure (
      new impl::MinIterationConvergenceMeasure(minIterations) );
  int dataID = getData(dataName, meshName)->getID();
  _config.convMeasures.push_back ( boost::make_tuple(dataID, measure) );

}

mesh::PtrData CouplingSchemeConfiguration:: getData
(
  const std::string& dataName,
  const std::string& meshName ) const
{
  foreach ( mesh::PtrMesh mesh, _meshConfig->meshes() ){
    if ( meshName == mesh->getName() ){
      foreach ( mesh::PtrData data, mesh->data() ){
        if ( dataName == data->getName() ){
          return data;
        }
      }
    }
  }
  preciceError ( "getData()", "Data \"" << dataName << "\" used by mesh \""
                 << meshName << "\" is not configured!" );
}


PtrCouplingScheme CouplingSchemeConfiguration:: createExplicitCouplingScheme
(
  const std::string& accessor ) const
{
  assertion ( not utils::contained(accessor, _couplingSchemes) );
  com::PtrCommunication com = _comConfig->getCommunication (
      _config.participant, _config.secondParticipant );
  ExplicitCouplingScheme* scheme = new ExplicitCouplingScheme (
      _config.maxTime, _config.maxTimesteps, _config.timestepLength,
      _config.validDigits, _config.participant, _config.secondParticipant,
      accessor, com, _config.dtMethod );
  scheme->setCheckointTimestepInterval ( _config.checkpointTimestepInterval );

  // Add data to be sent and received
  using boost::get;
  foreach ( const Config::Exchange& tuple, _config.exchanges ){
    mesh::PtrData data = get<0> ( tuple );
    const std::string & from = get<1> ( tuple );
    bool initialize = get<2> ( tuple );
    if ( from == accessor ){
      scheme->addDataToSend ( data, initialize );
    }
    else {
      scheme->addDataToReceive ( data, initialize );
    }
  }
  return PtrCouplingScheme(scheme);
}

PtrCouplingScheme CouplingSchemeConfiguration:: createImplicitCouplingScheme
(
  const std::string& accessor ) const
{
  assertion1 ( not utils::contained(accessor, _couplingSchemes), accessor );
  com::PtrCommunication com = _comConfig->getCommunication (
      _config.participant, _config.secondParticipant );
  ImplicitCouplingScheme* scheme = new ImplicitCouplingScheme (
      _config.maxTime, _config.maxTimesteps, _config.timestepLength,
      _config.validDigits, _config.participant, _config.secondParticipant,
      accessor, com, _config.maxIterations, _config.dtMethod );
  scheme->setCheckointTimestepInterval(_config.checkpointTimestepInterval);
  scheme->setExtrapolationOrder ( _config.extrapolationOrder );

  // Add data to be sent and received
  using boost::get;
  foreach ( const Config::Exchange & tuple, _config.exchanges ) {
    mesh::PtrData data = get<0> ( tuple );
    const std::string & from = get<1> ( tuple );
    bool initialize = get<2> ( tuple );
    if ( from == accessor ) {
      scheme->addDataToSend ( data, initialize );
    }
    else {
      scheme->addDataToReceive ( data, initialize );
    }
  }

  // Add convergence measures
  using boost::get;
  for ( size_t i=0; i < _config.convMeasures.size(); i++ ) {
    int dataID = get<0> ( _config.convMeasures[i] );
    impl::PtrIConvergenceMeasure measure = get<1> ( _config.convMeasures[i] );
    scheme->addConvergenceMeasure ( dataID, measure );
  }

  // Set relaxation parameters
  if ( _config.postProcessing.get() != NULL ) {
    scheme->setIterationPostProcessing ( _config.postProcessing );
  }
  return PtrCouplingScheme ( scheme );
}

constants::TimesteppingMethod
CouplingSchemeConfiguration:: getTimesteppingMethod
(
  const std::string& method ) const
{
  preciceTrace1 ( "getTimesteppingMethod()", method );
  if ( method == TagTimestepLength::VALUE_FIXED ){
    return constants::FIXED_DT;
  }
  else if ( method == TagTimestepLength::VALUE_FIRST_PARTICIPANT ){
    return constants::FIRST_PARTICIPANT_SETS_DT;
  }
//  else if ( method == TagTimestepLength::VALUE_SECOND_PARTICIPANT ){
//    return constants::SECOND_PARTICIPANT_SETS_DT;
//  }
  preciceError ( "getTimesteppingMethod()", "Unknown timestepping method \""
                 << method << "\"!" );
}

}} // namespace precice, cplscheme
