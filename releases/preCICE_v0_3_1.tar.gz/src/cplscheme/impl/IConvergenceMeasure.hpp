// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_CPLSCHEME_ICONVERGENCEMEASURE_HPP_
#define PRECICE_CPLSCHEME_ICONVERGENCEMEASURE_HPP_

#include "../CouplingData.hpp"
#include "utils/Dimensions.hpp"
#include "utils/Helpers.hpp"

namespace precice {
namespace cplscheme {
namespace impl {

/**
 * @brief Interface for measures checking the convergence of a series of datasets.
 *
 * A measurement involves two states of the data set: an old state and a new
 * state. Typically, the states corresponds to timestep $t$ and $t+1$. The
 * subclasses of IConvergenceMeasure define how exactly convergence is measured.
 *
 * A measure has to be used in the following way:
 * -# create the measure object (a subclass of IConvergenceMeasure)
 * -# call setNewMeasurementSeries() for one set of iterations
 * -# call startMeasurement() before measuring a set of data
 * -# call measure() for every pair of data entries
 * -# call finishMeasurement() when all data entries are measured
 * -# retrieve the convergence status via isConvergence()
 *
 * A new measurement can be done with the same object, starting from point 3.
 * Once convergence is achieved and new iterations are started, startin from
 * point 2.
 */
class IConvergenceMeasure
{
public:

   virtual ~IConvergenceMeasure() {};

   virtual void newMeasurementSeries () =0;

//   virtual void startMeasurement () =0;

   /**
    * @brief Performs convergence measurement.
    */
   virtual void measure (
      const utils::DynVector & oldValues,
      const utils::DynVector & newValues ) =0;

//   virtual void finishMeasurement () =0;

   virtual bool isConvergence () const =0;
};

}}} // namespace precice, cplscheme, impl

#endif /* PRECICE_CPLSCHEME_ICONVERGENCEMEASURE_HPP_ */
