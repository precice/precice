// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_UTILS_VALIDATOROR_HPP_
#define PRECICE_UTILS_VALIDATOROR_HPP_

#include "Validator.hpp"

namespace precice {
namespace utils {

template< typename value_t >
class ValidatorOr;

template< typename value_t >
const Validator<value_t> & operator||
(
   const Validator<value_t> & lhs,
   const Validator<value_t> & rhs );



template< typename value_t >
class ValidatorOr
:
   public Validator<value_t>
{
public:

   ValidatorOr ( const Validator<value_t> & lhs,
                 const Validator<value_t> & rhs );

   virtual ~ValidatorOr() { delete _lhs; delete _rhs; };

   virtual bool validateValue ( value_t value );

   virtual Validator<value_t> & clone () const;

   virtual std::string getErrorMessage () const;

private:

   ValidatorOr ( const ValidatorOr<value_t> & rhs );

   ValidatorOr<value_t> & operator= ( const ValidatorOr<value_t> & rhs );

   Validator<value_t> * _lhs;

   Validator<value_t> * _rhs;
};

#include "ValidatorOr.cpph"

}} // namespace precice, utils

#endif /* PRECICE_UTILS_VALIDATOROR_HPP_ */
