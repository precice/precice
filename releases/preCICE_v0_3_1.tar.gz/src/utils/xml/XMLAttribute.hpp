// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_UTILS_XMLATTRIBUTE_HPP_
#define PRECICE_UTILS_XMLATTRIBUTE_HPP_

#include "Validator.hpp"
#include "tarch/irr/XML.h"
#include "tarch/logging/Log.h"
#include "utils/Dimensions.hpp"
#include "utils/Globals.hpp"
#include <string>

namespace precice {
namespace utils {



template<typename ATTRIBUTE_T>
class XMLAttribute
{
public:

  typedef tarch::irr::io::IrrXMLReader XMLReader;

  XMLAttribute ( const std::string& name );

  XMLAttribute ( const XMLAttribute<ATTRIBUTE_T>& rhs );

  virtual ~XMLAttribute() { delete _validator; };

  void setValidator ( const Validator<ATTRIBUTE_T>& validator );

  void setDefaultValue ( const ATTRIBUTE_T& defaultValue );

  bool readValue (
    XMLReader*         xmlReader,
    const std::string& tagName );

  void readValueSpecific (
    XMLReader* xmlReader,
    double&    value );

  void readValueSpecific (
    XMLReader* xmlReader,
    int&       value );

  void readValueSpecific (
    XMLReader*   xmlReader,
    std::string& value );

  void readValueSpecific (
    XMLReader* xmlReader,
    bool&      value );

  void readValueSpecific (
    XMLReader*       xmlReader,
    utils::Vector2D& value );

  void readValueSpecific (
    XMLReader*       xmlReader,
    utils::Vector3D& value );

  const std::string& getName() const { return _name; };

  const ATTRIBUTE_T& getValue() const { return _value; };

  void setRead ( bool read ) { _read = read; };

  bool isRead () const { return _read; };

private:

  static tarch::logging::Log _log;

  std::string _name;

  bool _read;

  ATTRIBUTE_T _value;

  bool _hasDefaultValue;

  ATTRIBUTE_T _defaultValue;

  bool _hasValidation;

  Validator<ATTRIBUTE_T>* _validator;
};

template<typename ATTRIBUTE_T>
tarch::logging::Log XMLAttribute<ATTRIBUTE_T>:: _log ("precice::utils::XMLAttribute");

template<typename ATTRIBUTE_T>
XMLAttribute<ATTRIBUTE_T>:: XMLAttribute
(
  const std::string& name )
:
  _name (name),
  _read (false),
  _value (),
  _hasDefaultValue (false),
  _defaultValue (),
  _validator (NULL)
{}

template<typename ATTRIBUTE_T>
XMLAttribute<ATTRIBUTE_T>:: XMLAttribute
(
  const XMLAttribute<ATTRIBUTE_T>& rhs )
:
  _name (rhs._name),
  _read (rhs._read),
  _value (rhs._value),
  _hasDefaultValue (rhs._hasDefaultValue),
  _defaultValue (rhs._defaultValue)
{
  if (rhs._validator != NULL) {
    _validator = &((rhs._validator)->clone());
  }
  else {
    _validator = NULL;
  }
}

template<typename ATTRIBUTE_T>
void XMLAttribute<ATTRIBUTE_T>:: setValidator
(
  const Validator<ATTRIBUTE_T>& validator )
{
  if (_validator) {
    delete _validator;
  }
  _validator = &(validator.clone());
}

template<typename ATTRIBUTE_T>
void XMLAttribute<ATTRIBUTE_T>:: setDefaultValue
(
  const ATTRIBUTE_T& defaultValue )
{
  _hasDefaultValue = true;
  _defaultValue = defaultValue;
}

template<typename ATTRIBUTE_T>
bool XMLAttribute<ATTRIBUTE_T>:: readValue
(
  XMLReader*         xmlReader,
  const std::string& tagName )
{
  preciceTrace ( "readValue()" );
  if (xmlReader->getAttributeValue(getName().c_str()) == 0) {
    if (_hasDefaultValue ) {
      _value = _defaultValue;
    }
    else {
      preciceError ( "readValue()", "Attribute " << getName()
                     << " missing in tag <" << tagName << "> !" );
    }
  }
  else {
    readValueSpecific (xmlReader, _value);
    if (_validator) {
      if (! _validator->validateValue(_value)) {
        preciceError ( "readValue()", "Invalid value \"" << _value
                       << "\" of attribute \"" << getName() << "\" in tag <"
                       << tagName << "> : " << _validator->getErrorMessage() );
      }
    }
  }
  preciceDebug ( getName() << "=" << _value );
  _read = true;
  return true;
}

template<typename ATTRIBUTE_T>
void XMLAttribute<ATTRIBUTE_T>:: readValueSpecific
(
  XMLReader* xmlReader,
  double&    value )
{
  value = xmlReader->getAttributeValueAsDouble (_name.c_str());
}

template<typename ATTRIBUTE_T>
void XMLAttribute<ATTRIBUTE_T>:: readValueSpecific
(
  XMLReader* xmlReader,
  int&       value )
{
  value = xmlReader->getAttributeValueAsInt(_name.c_str());
}

template<typename ATTRIBUTE_T>
void XMLAttribute<ATTRIBUTE_T>:: readValueSpecific
(
  XMLReader*   xmlReader,
  std::string& value )
{
  value = std::string(xmlReader->getAttributeValue(_name.c_str()));
}

template<typename ATTRIBUTE_T>
void XMLAttribute<ATTRIBUTE_T>:: readValueSpecific
(
  XMLReader* xmlReader,
  bool&      value )
{
  value = xmlReader->getAttributeValueAsBool ( _name.c_str() );
}

template<typename ATTRIBUTE_T>
void XMLAttribute<ATTRIBUTE_T>:: readValueSpecific
(
  XMLReader*       xmlReader,
  utils::Vector2D& value )
{
  value = xmlReader->getAttributeValueAsDoubleVector<2>( _name.c_str() );
}

template<typename ATTRIBUTE_T>
void XMLAttribute<ATTRIBUTE_T>::  readValueSpecific
(
  XMLReader*       xmlReader,
  utils::Vector3D& value )
{
  value = xmlReader->getAttributeValueAsDoubleVector<3>( _name.c_str() );
}

}} // namespace precice, utils



#endif /* PRECICE_UTILS_XMLATTRIBUTE_HPP_ */
