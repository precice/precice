// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_UTILS_VALIDATOR_HPP_
#define PRECICE_UTILS_VALIDATOR_HPP_

#include <string>

namespace precice {
namespace utils {


template< typename value_t >
class Validator
{
public:

   Validator () {};

   virtual ~Validator() {};

   virtual bool validateValue ( value_t value ) =0;

   virtual Validator<value_t> & clone () const =0;

   virtual std::string getErrorMessage () const =0;

private:

   Validator ( const Validator<value_t> & rhs );

   Validator<value_t> & operator= ( const Validator<value_t> & rhs );
};

}} // namespace precice, utils

#endif /* PRECICE_UTILS_VALIDATOR_HPP_ */
