// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_UTILS_XMLTAG_HPP_
#define PRECICE_UTILS_XMLTAG_HPP_

#include "XMLAttribute.hpp"
#include "utils/Globals.hpp"
#include "tarch/irr/XML.h"
#include <string>
#include <map>
#include <vector>
#include "boost/smart_ptr.hpp"

namespace precice {
namespace utils {


/**
 * @brief Represents an XML tag to be configured automatically
 */
class XMLTag
{
public:

  typedef tarch::irr::io::IrrXMLReader XMLReader;

  enum Occurrence {
    OCCUR_NOT_OR_ONCE,
    OCCUR_ONCE,
    OCCUR_ONCE_OR_MORE,
    OCCUR_ARBITRARY,
    OCCUR_ARBITRARY_NESTED
  };

  /**
   * @brief Standard constructor
   *
   * @param tagName [IN] Name of the XML tag.
   * @param occurrence [IN] Defines the occurrences of the tag.
   */
  XMLTag (
    const std::string& tagName,
    Occurrence         Occurrence );

  /**
   * @brief Adds an XMLTag as subtag
   */
  void addSubtag ( const XMLTag& tag );

  /**
   * @brief Removes the XML subtag with given name
   */
  void removeSubtag ( const std::string& tagName );

  void addAttribute ( const XMLAttribute<double>& attribute );

  void addAttribute ( const XMLAttribute<int>& attribute );

  void addAttribute ( const XMLAttribute<std::string>& attribute );

  void addAttribute ( const XMLAttribute<bool>& attribute );

  void addAttribute ( const XMLAttribute<utils::Vector2D>& attributue );

  void addAttribute ( const XMLAttribute<utils::Vector3D>& attributue );

  void removeAttribute ( const std::string& attributeName );

  const std::string& getName () const { return _name; }

  const XMLTag& getTag ( const std::string& tagName ) const;

  double getDoubleAttributeValue ( const std::string& name );

  int getIntAttributeValue ( const std::string& name );

  const std::string& getStringAttributeValue ( const std::string& name );

  bool getBooleanAttributeValue ( const std::string& name );

  const utils::Vector2D& getVector2DAttributeValue ( const std::string& name );

  const utils::Vector3D& getVector3DAttributeValue ( const std::string& name );

  /**
   * @brief Parses the information from the xmlReader.
   *
   * Required interface of CALLBACK_T:
   *
   * bool xmlTagCallback ( utils::XMLTag         & callingTag,
   *                       tarch::irr::io::IrrXMLReader * xmlReader );
   *
   * bool xmlTagEndCallback ( utils::XMLTag         & callingTag,
   *                          tarch::irr::io::IrrXMLReader * xmlReader );
   *
   */
  template<typename CALLBACK_T>
  bool parse (
    XMLReader*  xmlReader,
    CALLBACK_T& callback );

  bool isConfigured() const { return _configured; };

  Occurrence getOccurrence() const { return _occurrence; };

  /**
   * @brief Removes all attributes and subtags
   */
  void clear();

private:

   static tarch::logging::Log _log;

   std::string _name;

   bool _configured;

   Occurrence _occurrence;

   std::vector<XMLTag*> _subtags;

   std::map<std::string,XMLAttribute<double> > _doubleAttributes;

   std::map<std::string,XMLAttribute<int> > _intAttributes;

   std::map<std::string,XMLAttribute<std::string> > _stringAttributes;

   std::map<std::string,XMLAttribute<bool> > _booleanAttributes;

   std::map<std::string,XMLAttribute<utils::Vector2D> > _vector2DAttributes;

   std::map<std::string,XMLAttribute<utils::Vector3D> > _vector3DAttributes;

   bool readAttributes ( XMLReader* xmlReader );

   template<typename CALLBACK_T>
   bool configureSubtag (
     XMLReader*  xmlReader,
     CALLBACK_T& callback );

   bool areAllSubtagsConfigured() const;

   void resetAttributes();
};

// ------------------------------------------------------ HEADER IMPLEMENTATION

template<typename CALLBACK_T>
bool precice::utils::XMLTag:: parse
(
  XMLReader*  xmlReader,
  CALLBACK_T& callback )
{
  preciceTrace ( "parse()" );
  if (xmlReader->getNodeType() == tarch::irr::io::EXN_ELEMENT) {
    assertion ( xmlReader->getNodeName() != NULL );
    preciceDebug ( "reading attributes of tag " << xmlReader->getNodeName() );
    if (! readAttributes (xmlReader)) {
      return false;
    }
    if (! callback.xmlTagCallback (*this, xmlReader)) {
      return false;
    }
    resetAttributes ();
  }

  if ( (_subtags.size() > 0) ||
      (_occurrence == OCCUR_ARBITRARY_NESTED) )
  {
    while (xmlReader->read()) {
      if (xmlReader->getNodeType() == tarch::irr::io::EXN_ELEMENT) {
        assertion ( xmlReader->getNodeName() != NULL );
        preciceDebug ( "reading subtag " << xmlReader->getNodeName()
                       << " of tag " << getName() );
        if ( (_occurrence == OCCUR_ARBITRARY_NESTED) &&
            (std::string(xmlReader->getNodeName()) == _name) )
        {
          resetAttributes ();
          addSubtag ( *this );
        }
        if (! configureSubtag (xmlReader, callback)) {
          return false;
        }
      }
      else if ( xmlReader->getNodeType() == tarch::irr::io::EXN_ELEMENT_END ) {
        if ( std::string(xmlReader->getNodeName()) == _name ) {
          preciceDebug ( "end of tag " << xmlReader->getNodeName() );
          _configured = true;
          _configured &= areAllSubtagsConfigured ();
          _configured &= callback.xmlEndTagCallback ( *this, xmlReader );
          return _configured;
        }
        else {
          preciceError ( "parse()", "Found closing tag for tag <"
            << xmlReader->getNodeName()
            << ">, but expected it for tag <" << getName() << "> !");
          return false;
        }
      }
    }
  }

  _configured = true;
  return true;
}

template< typename CALLBACK_T >
bool precice::utils::XMLTag:: configureSubtag
(
  XMLReader*  xmlReader,
  CALLBACK_T& callback )
{
  foreach ( XMLTag* tag, _subtags) {
    if (std::string(xmlReader->getNodeName()) == tag->getName()) {
      if ( tag->isConfigured() &&
        (tag->getOccurrence() == OCCUR_ONCE ||
          tag->getOccurrence() == OCCUR_NOT_OR_ONCE) )
      {
        preciceError ( "configureSubtag()", "Tag <" << tag->getName()
                       << "> can be defined only once!" );
        return false;
      }
      //_log.debug ("configureSubtag(.)", "calling autoconfigure for tag " + tagIter->getName());
      if (! tag->parse(xmlReader, callback)) {
        return false;
      }
      break;   // since the xmlReader is not advanced here
    }
  }
  return true;
}

/**
 * @brief Configures the given confugration from file configurationFilename.
 */
template< typename CONFIG_T >
bool configure
(
  CONFIG_T&          configuration,
  const std::string& configurationFilename )
{
  tarch::logging::Log _log ( "precice::utils" );
  bool success = false;
  tarch::irr::io::IrrXMLReader * xmlReader =
    tarch::irr::io::createIrrXMLReader ( configurationFilename.c_str() );
  preciceCheck ( xmlReader != NULL, "configure()",
                 "Could not create XML reader for file \"" << configurationFilename
                 << "\"!" );
  preciceCheck ( xmlReader->read(), "configure()",
                 "XML reader doesn't recognize a valid XML tag in file \""
                 << configurationFilename << "\"!" );
  preciceCheck ( xmlReader->getNodeType() != tarch::irr::io::EXN_NONE, "configure()",
                 "XML reader found only invalid XML tag in file \""
                 << configurationFilename << "\"!" );
  bool foundTag = false;
  while( xmlReader->read() ) {
    if ( xmlReader->getNodeType() == tarch::irr::io::EXN_ELEMENT ) {
      if ( CONFIG_T::getTag() == xmlReader->getNodeName() ) {
        foundTag = true;
        success |= configuration.parseSubtag ( xmlReader );
      }
    }
  }
  preciceCheck ( foundTag, "configure()", "Did not find suitable XML tag!" );
  return success;
};

/**
 * @brief Configures the given confugration from file configurationFilename.
 */
template< typename CONFIG_T >
bool configure
(
  boost::shared_ptr<CONFIG_T> configuration,
  const std::string&          configurationFilename )
{
  assertion ( configuration.get() != NULL );
  return configure ( *configuration, configurationFilename );
}

}}

#endif /* PRECICE_UTILS_XMLTAG_HPP_ */
