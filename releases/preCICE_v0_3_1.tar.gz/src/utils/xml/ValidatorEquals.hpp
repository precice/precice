// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_UTILS_VALIDATOREQUALS_HPP_
#define PRECICE_UTILS_VALIDATOREQUALS_HPP_

#include "Validator.hpp"
#include "tarch/logging/Log.h"

namespace precice {
namespace utils {

template< typename value_t >
class ValidatorEquals;


template< typename value_t >
class ValidatorEquals
:
   public Validator<value_t>
{
public:

   ValidatorEquals ( value_t valueToEqual )
      : Validator<value_t> (),
       _valueToEqual (valueToEqual) {};

   virtual ~ValidatorEquals() {};

   virtual bool validateValue ( value_t value )
   {
      std::ostringstream stream;
      stream << "Validating " << value;
      _log.debug ("validateValue", stream.str());
      return value == _valueToEqual; };

   virtual Validator<value_t> & clone () const
   {
      ValidatorEquals<value_t> * validator =
         new ValidatorEquals<value_t> (_valueToEqual);
      return *validator;
   };

   virtual std::string getErrorMessage () const
   {
      std::ostringstream stream;
      stream << _valueToEqual;
      return std::string("Value must be = " + stream.str() + " !");
   };

private:

   static tarch::logging::Log _log;

   ValidatorEquals ( const ValidatorEquals<value_t> & rhs );

   ValidatorEquals<value_t> & operator= ( const ValidatorEquals<value_t> & rhs );

   value_t _valueToEqual;
};

template< typename value_t >
tarch::logging::Log precice::utils::ValidatorEquals<value_t>::
   _log = tarch::logging::Log ("precice::utils::ValidatorEquals");

}} // namespace precice, utils

#endif /* PRECICE_UTILS_VALIDATOREQUALS_HPP_ */
