// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "utils/xml/XMLTag.hpp"
#include "utils/Globals.hpp"

namespace precice {
namespace utils {

tarch::logging::Log precice::utils::XMLTag:: _log ("precice::utils::XMLTag");

XMLTag:: XMLTag
(
  const std::string& tagName,
  Occurrence         occurrence )
:
  _name (tagName),
  _configured (false),
  _occurrence (occurrence),
  _subtags (),
  _doubleAttributes (),
  _intAttributes (),
  _stringAttributes (),
  _booleanAttributes (),
  _vector2DAttributes (),
  _vector3DAttributes ()
{}

void XMLTag:: addSubtag
(
  const XMLTag& tag )
{
   assertion (tag._name != std::string(""));

   XMLTag* copy = new XMLTag(tag);   // resolves mingw problem
   _subtags.push_back(copy);
}

void XMLTag:: removeSubtag
(
  const std::string& tagName )
{
  std::vector<XMLTag*>::iterator iter;
  for ( iter=_subtags.begin(); iter != _subtags.end(); iter++ ){
    if ((*iter)->getName() == tagName) {
      delete *iter;  // MARK Bernhard, mingw
      _subtags.erase(iter);
      return;
    }
  }
  preciceError ( "removeAttribute()", "Subtag \"" << tagName << "\" does not exist!" );
}

void XMLTag:: addAttribute
(
  const XMLAttribute<double>& attribute )
{
  preciceTrace1 ( "addAttribute(scalar<double>)", attribute.getName() );
  assertion (attribute.getName() != "");
  assertion (_intAttributes.count(attribute.getName()) == 0);
  assertion (_doubleAttributes.count(attribute.getName()) == 0);
  assertion (_stringAttributes.count(attribute.getName()) == 0);
  assertion (_booleanAttributes.count(attribute.getName()) == 0);
  assertion (_vector2DAttributes.count(attribute.getName()) == 0);
  assertion (_vector3DAttributes.count(attribute.getName()) == 0);

  _doubleAttributes.insert ( std::pair<std::string,XMLAttribute<double> >
      (attribute.getName(), attribute));
}

void XMLTag:: addAttribute
(
  const XMLAttribute<int>& attribute )
{
  preciceTrace1 ( "addAttribute(scalar<int>)", attribute.getName() );
  assertion (attribute.getName() != "");
  assertion (_intAttributes.count(attribute.getName()) == 0);
  assertion (_doubleAttributes.count(attribute.getName()) == 0);
  assertion (_stringAttributes.count(attribute.getName()) == 0);
  assertion (_booleanAttributes.count(attribute.getName()) == 0);
  assertion (_vector2DAttributes.count(attribute.getName()) == 0);
  assertion (_vector3DAttributes.count(attribute.getName()) == 0);
  _intAttributes.insert ( std::pair<std::string,
                          XMLAttribute<int> > (attribute.getName(), attribute));
}

void XMLTag:: addAttribute
(
  const XMLAttribute<std::string>& attribute )
{
  preciceTrace1 ( "addAttribute(scalar<string>)", attribute.getName() );
  assertion (attribute.getName() != "");
  assertion (_intAttributes.count(attribute.getName()) == 0);
  assertion (_doubleAttributes.count(attribute.getName()) == 0);
  assertion (_stringAttributes.count(attribute.getName()) == 0);
  assertion (_booleanAttributes.count(attribute.getName()) == 0);
  assertion (_vector2DAttributes.count(attribute.getName()) == 0);
  assertion (_vector3DAttributes.count(attribute.getName()) == 0);
  _stringAttributes.insert ( std::pair<std::string,XMLAttribute<std::string> >
                             (attribute.getName(), attribute));
}

void XMLTag:: addAttribute
(
  const XMLAttribute<bool>& attribute )
{
  preciceTrace1 ( "addAttribute(scalar<bool>)", attribute.getName() );
  assertion (attribute.getName() != "");
  assertion (_intAttributes.count(attribute.getName()) == 0);
  assertion (_doubleAttributes.count(attribute.getName()) == 0);
  assertion (_stringAttributes.count(attribute.getName()) == 0);
  assertion (_booleanAttributes.count(attribute.getName()) == 0);
  assertion (_vector2DAttributes.count(attribute.getName()) == 0);
  assertion (_vector3DAttributes.count(attribute.getName()) == 0);
  _booleanAttributes.insert ( std::pair<std::string,XMLAttribute<bool> >
      (attribute.getName(), attribute));
}

void XMLTag:: addAttribute
(
  const XMLAttribute<utils::Vector2D>& attribute )
{
  preciceTrace1 ( "addAttribute(Vector2D)", attribute.getName() );
  assertion (attribute.getName() != "");
  assertion (_intAttributes.count(attribute.getName()) == 0);
  assertion (_doubleAttributes.count(attribute.getName()) == 0);
  assertion (_stringAttributes.count(attribute.getName()) == 0);
  assertion (_booleanAttributes.count(attribute.getName()) == 0);
  assertion (_vector2DAttributes.count(attribute.getName()) == 0);
  assertion (_vector3DAttributes.count(attribute.getName()) == 0);
  _vector2DAttributes.insert ( std::pair<std::string,XMLAttribute<utils::Vector2D> >
      (attribute.getName(), attribute));
}

void XMLTag:: addAttribute
(
  const XMLAttribute<utils::Vector3D>& attribute )
{
  preciceTrace1 ( "addAttribute(Vector3D)", attribute.getName() );
  assertion (attribute.getName() != "");
  assertion (_intAttributes.count(attribute.getName()) == 0);
  assertion (_doubleAttributes.count(attribute.getName()) == 0);
  assertion (_stringAttributes.count(attribute.getName()) == 0);
  assertion (_booleanAttributes.count(attribute.getName()) == 0);
  assertion (_vector2DAttributes.count(attribute.getName()) == 0);
  assertion (_vector3DAttributes.count(attribute.getName()) == 0);
  _vector3DAttributes.insert ( std::pair<std::string,XMLAttribute<utils::Vector3D> >
      (attribute.getName(), attribute));
}

void XMLTag:: removeAttribute
(
  const std::string& attributeName )
{
  if ( _intAttributes.find(attributeName) != _intAttributes.end() )
    _intAttributes.erase (attributeName);
  else if ( _doubleAttributes.find(attributeName) != _doubleAttributes.end() )
    _doubleAttributes.erase (attributeName);
  else if ( _stringAttributes.find(attributeName) != _stringAttributes.end() )
    _stringAttributes.erase (attributeName);
  else if ( _booleanAttributes.find(attributeName) != _booleanAttributes.end() )
    _booleanAttributes.erase ( attributeName );
  else if ( _vector2DAttributes.find(attributeName) != _vector2DAttributes.end() )
    _vector2DAttributes.erase (attributeName);
  else if ( _vector3DAttributes.find(attributeName) != _vector3DAttributes.end() )
    _vector3DAttributes.erase (attributeName);
  else {
    preciceError ( "removeAttribute(.)",
                   "Attribute \"" << attributeName << "\" does not exist!" );
  }
}

const XMLTag& XMLTag:: getTag
(
  const std::string& tagName ) const
{
  for (size_t i=0; i < _subtags.size(); i++) {
    if (_subtags.at(i)->getName() == tagName)
      return *_subtags.at(i);
  }
  preciceError ( "getTag(.)", "Tag with name " << tagName
      << " does not exist for tag " << _name );
}

double XMLTag:: getDoubleAttributeValue
(
  const std::string& name )
{
  std::map<std::string,XMLAttribute<double> >::iterator iter;
  iter = _doubleAttributes.find(name);
  assertion ( iter != _doubleAttributes.end() );
  return iter->second.getValue();
}

int XMLTag:: getIntAttributeValue
(
  const std::string& name )
{
  std::map<std::string,XMLAttribute<int> >::iterator iter;
  iter = _intAttributes.find(name);
  assertion (iter  != _intAttributes.end());
  return iter->second.getValue();
}

const std::string& XMLTag:: getStringAttributeValue
(
  const std::string& name )
{
  std::map<std::string,XMLAttribute<std::string> >::iterator iter;
  iter = _stringAttributes.find(name);
  assertion1 (iter != _stringAttributes.end(), name);
  return iter->second.getValue();
}

bool XMLTag:: getBooleanAttributeValue
(
  const std::string& name )
{
  std::map<std::string,XMLAttribute<bool> >::iterator iter;
  iter = _booleanAttributes.find(name);
  assertion (iter  != _booleanAttributes.end());
  return iter->second.getValue();
}

const utils::Vector2D& XMLTag:: getVector2DAttributeValue
(
  const std::string& name )
{
  std::map<std::string,XMLAttribute<utils::Vector2D> >::iterator iter;
  iter = _vector2DAttributes.find(name);
  assertion (iter  != _vector2DAttributes.end());
  return iter->second.getValue();
}

const utils::Vector3D& XMLTag:: getVector3DAttributeValue
(
  const std::string& name )
{
  std::map<std::string,XMLAttribute<utils::Vector3D> >::iterator iter;
  iter = _vector3DAttributes.find(name);
  assertion (iter  != _vector3DAttributes.end());
  return iter->second.getValue();
}

bool XMLTag:: readAttributes
(
  XMLReader* xmlReader )
{
  typedef std::map<std::string,XMLAttribute<double> >::value_type DoublePair;
  foreach ( DoublePair & pair, _doubleAttributes){
    if (! pair.second.isRead() ) {
      if (not pair.second.readValue(xmlReader, _name))
        return false;
    }
  }

  typedef std::map<std::string,XMLAttribute<int> >::value_type IntPair;
  foreach ( IntPair & pair, _intAttributes){
    if (! pair.second.isRead() ) {
      if (! pair.second.readValue (xmlReader, _name))
        return false;
    }
  }

  typedef std::map<std::string,XMLAttribute<std::string> >::value_type StringPair;
  foreach ( StringPair & pair, _stringAttributes ){
    if (! pair.second.isRead() ) {
      if (! pair.second.readValue (xmlReader, _name))
        return false;
    }
  }

  typedef std::map<std::string,XMLAttribute<bool> >::value_type BoolPair;
  foreach ( BoolPair & pair, _booleanAttributes ){
    if (! pair.second.isRead() ) {
      if (! pair.second.readValue (xmlReader, _name))
        return false;
    }
  }

  typedef std::map<std::string,XMLAttribute<utils::Vector2D> >::value_type Vec2DPair;
  foreach ( Vec2DPair& pair, _vector2DAttributes ){
    if (! pair.second.isRead() ) {
      if (! pair.second.readValue(xmlReader, _name)) {
        return false;
      }
    }
  }

  typedef std::map<std::string,XMLAttribute<utils::Vector3D> >::value_type Vec3DPair;
  foreach ( Vec3DPair& pair, _vector3DAttributes ){
    if (! pair.second.isRead() ) {
      if (! pair.second.readValue(xmlReader, _name)) {
        return false;
      }
    }
  }
  return true;
}

bool XMLTag:: areAllSubtagsConfigured () const
{
  foreach ( XMLTag * tag, _subtags ){
    bool notConfigured = ! tag->isConfigured();
    bool occurOnce = tag->getOccurrence() == OCCUR_ONCE;
    bool occurOnceOrMore = tag->getOccurrence() == OCCUR_ONCE_OR_MORE;
    if ( notConfigured && (occurOnce || occurOnceOrMore) ) {
      preciceError ( "areAllSubtagsConfigured()", "Tag <" << tag->getName()
                    << "> is missing in tag <" << _name << "> !" );
    }
  }
  return true;
}

void XMLTag:: resetAttributes ()
{
  _configured = false;

  typedef std::map<std::string,XMLAttribute<double> >::value_type DoublePair;
  foreach ( DoublePair & pair, _doubleAttributes){
    pair.second.setRead (false);
  }

  typedef std::map<std::string,XMLAttribute<int> >::value_type IntPair;
  foreach ( IntPair & pair, _intAttributes){
    pair.second.setRead (false);
  }

  typedef std::map<std::string,XMLAttribute<std::string> >::value_type StringPair;
  foreach ( StringPair & pair, _stringAttributes ){
    pair.second.setRead (false);
  }

  typedef std::map<std::string,XMLAttribute<bool> >::value_type BoolPair;
  foreach ( BoolPair & pair, _booleanAttributes ){
    pair.second.setRead (false);
  }

  typedef std::map<std::string,XMLAttribute<utils::Vector2D> >::value_type Vec2DPair;
  foreach ( Vec2DPair & pair, _vector2DAttributes ){
    pair.second.setRead (false);
  }

  typedef std::map<std::string,XMLAttribute<utils::Vector3D> >::value_type Vec3DPair;
  foreach ( Vec3DPair & pair, _vector3DAttributes ){
    pair.second.setRead (false);
  }

  std::vector<XMLTag*>::iterator subtagIter;
  foreach ( XMLTag * tag, _subtags ){
    tag->_configured = false;
    tag->resetAttributes ();
  }
}

void XMLTag:: clear ()
{
   _doubleAttributes.clear ();
   _intAttributes.clear ();
   _stringAttributes.clear ();
   _booleanAttributes.clear ();
   _vector2DAttributes.clear ();
   _vector3DAttributes.clear ();
   _subtags.clear ();
}

}}
