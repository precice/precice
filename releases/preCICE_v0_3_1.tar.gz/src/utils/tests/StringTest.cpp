// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "StringTest.hpp"
#include "../String.hpp"
#include "utils/Globals.hpp"
#include "utils/Parallel.hpp"
#include <string>

#include "tarch/tests/TestCaseFactory.h"
registerTest(precice::utils::tests::StringTest)

namespace precice {
namespace utils {
namespace tests {

tarch::logging::Log StringTest:: _log ( "precice::utils::StringTest" );

StringTest:: StringTest()
:
   TestCase ( "utils::StringTest" )
{}

void StringTest:: run ()
{
   PRECICE_MASTER_ONLY {
      testMethod ( testTokenize );
   }
}

void StringTest:: testTokenize ()
{
   preciceTrace ( "tokenize()" );

   std::vector<std::string> tokens;

   std::string stringA ("This-is-a-test");
   std::string delimiterA ("-");
   tokens = String::tokenize ( stringA, delimiterA );
   validateEquals ( tokens.size(), 4 );
   validateEquals ( tokens[0], std::string("This") );
   validateEquals ( tokens[1], std::string("is") );
   validateEquals ( tokens[2], std::string("a") );
   validateEquals ( tokens[3], std::string("test") );

   std::string stringB ("This::is::another::test");
   std::string delimiterB ("::");
   tokens = String::tokenize ( stringB, delimiterB );
   validateEquals ( tokens.size(), 4 );
   validateEquals ( tokens[0], std::string("This") );
   validateEquals ( tokens[1], std::string("is") );
   validateEquals ( tokens[2], std::string("another") );
   validateEquals ( tokens[3], std::string("test") );

   std::string stringC ("::Test");
   std::string delimiterC ("::");
   tokens = String::tokenize ( stringC, delimiterC );
   validateEquals ( tokens.size(), 1 );
   validateEquals ( tokens[0], std::string("Test") );

   std::string stringD ("Test::");
   std::string delimiterD ("::");
   tokens = String::tokenize ( stringD, delimiterD );
   validateEquals ( tokens.size(), 1 );
   validateEquals ( tokens[0], std::string("Test") );

   std::string stringE ("::This::is:another::test::");
   std::string delimiterE ("::");
   tokens = String::tokenize ( stringE, delimiterE );
   validateEquals ( tokens.size(), 3 );
   validateEquals ( tokens[0], std::string("This") );
   validateEquals ( tokens[1], std::string("is:another") );
   validateEquals ( tokens[2], std::string("test") );
}


}}} // namespace precice, utils, tests

