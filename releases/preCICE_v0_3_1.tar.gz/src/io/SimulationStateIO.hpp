// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_IO_SIMULATIONSTATEIO_HPP_
#define PRECICE_IO_SIMULATIONSTATEIO_HPP_

#include "tarch/logging/Log.h"
#include <string>

namespace precice {
namespace io {

/**
 *
 */
class SimulationStateIO
{
public:

  static const std::string STANDARD_FILENAME;

  SimulationStateIO ( const std::string& file );

  void writeState (
    double time,
    int    timestep );

  void readState (
    double& time,
    int&    timestep );

private:

  static tarch::logging::Log _log;

  std::string _file;
};

}} // namespace precice, io

#endif /* PRECICE_IO_SIMULATIONSTATEIO_HPP_ */
