// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_IO_TXTWRITER_HPP_
#define PRECICE_IO_TXTWRITER_HPP_

#include "tarch/logging/Log.h"
#include <string>

namespace tarch {
  namespace la {
    template<typename Scalar> class DynamicMatrix;
    template<typename Scalar> class DynamicVector;
  }
}

// ----------------------------------------------------------- CLASS DEFINITION

namespace precice {
namespace io {

/**
 * @brief File writer for matrix in Matlab V7 ASCII format.
 */
class TXTWriter
{
public:

  /**
   * @brief Writes the matrix to the file.
   */
  static void write (
    const tarch::la::DynamicMatrix<double>& matrix,
    const std::string&                      filename );

  /**
   * @brief Writes the vector to the file.
   */
  static void write (
    const tarch::la::DynamicVector<double>& vector,
    const std::string&                      filename );

private:

  // @brief Logging device.
  static tarch::logging::Log _log;
};

}} // namespace precice, io

#endif /* PRECICE_IO_TXTWRITER_HPP_ */
