// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "ExportConfiguration.hpp"
#include "io/ExportVTK.hpp"
#include "io/ExportVRML.hpp"
#include "io/Export.hpp"
#include "utils/Globals.hpp"
#include "utils/Helpers.hpp"
#include "utils/xml/XMLTag.hpp"
#include "utils/xml/XMLAttribute.hpp"
#include "utils/xml/ValidatorEquals.hpp"
#include "utils/xml/ValidatorOr.hpp"

namespace precice {
namespace io {

tarch::logging::Log ExportConfiguration:: _log ( "precice::io::ExportConfiguration" );

const std::string& ExportConfiguration:: getTag()
{
  static std::string tag ( "export" );
  return tag;
}

ExportConfiguration:: ExportConfiguration()
:
  ATTR_LOCATION ( "location" ),
  ATTR_TYPE ( "type" ),
  ATTR_AUTO ( "auto" ),
  VALUE_VTK ( "vtk" ),
  VALUE_VRML ( "vrml" ),
  ATTR_TIMESTEP_INTERVAL ( "timestep-interval" ),
  ATTR_NEIGHBORS ( "neighbors" ),
  ATTR_TRIGGER_SOLVER ( "trigger-solver" ),
  ATTR_NORMALS ( "normals" ),
  ATTR_SPACETREE ( "spacetree" ),
  _isValid ( false ),
  _context()
{}

bool ExportConfiguration:: parseSubtag
(
  utils::XMLTag::XMLReader* xmlReader )
{
  using utils::XMLTag;
  using utils::XMLAttribute;
  using utils::ValidatorEquals;
  XMLTag tag ( getTag(), XMLTag::OCCUR_ARBITRARY );

  XMLAttribute<std::string> attrLocation ( ATTR_LOCATION );
  attrLocation.setDefaultValue ("");
  tag.addAttribute ( attrLocation );

  XMLAttribute<std::string> attrType ( ATTR_TYPE );
  ValidatorEquals<std::string> validTypeVTK ( VALUE_VTK );
  ValidatorEquals<std::string> validTypeSocket ( VALUE_VRML );
  attrType.setValidator ( validTypeVTK || validTypeSocket );
  attrType.setDefaultValue ( VALUE_VTK );
  tag.addAttribute ( attrType );

  XMLAttribute<int> attrTimestepInterval ( ATTR_TIMESTEP_INTERVAL );
  attrTimestepInterval.setDefaultValue ( -1 );
  tag.addAttribute ( attrTimestepInterval );

  XMLAttribute<bool> attrNeighbors ( ATTR_NEIGHBORS );
  attrNeighbors.setDefaultValue ( false );
  tag.addAttribute ( attrNeighbors );

  XMLAttribute<bool> attrTriggerSolver ( ATTR_TRIGGER_SOLVER );
  attrTriggerSolver.setDefaultValue ( false );
  tag.addAttribute ( attrTriggerSolver );

  XMLAttribute<bool> attrNormals ( ATTR_NORMALS );
  attrNormals.setDefaultValue ( false );
  tag.addAttribute ( attrNormals );

  XMLAttribute<bool> attrSpacetree ( ATTR_SPACETREE );
  attrSpacetree.setDefaultValue(true);
  tag.addAttribute(attrSpacetree);

  //utils::XMLAttribute<bool> attrAuto ( ATTR_AUTO );
  //attrAuto.setDefaultValue ( true );
  //tagExport.addAttribute ( attrAuto );

  _context = ExportContext();
  _isValid = tag.parse ( xmlReader, *this );

  return _isValid;
}

bool ExportConfiguration:: xmlTagCallback
(
  utils::XMLTag&            tag,
  utils::XMLTag::XMLReader* xmlReader )
{
  if ( tag.getName() == getTag() ){
    _context.location = tag.getStringAttributeValue(ATTR_LOCATION);
    _context.plotNeighbors = tag.getBooleanAttributeValue(ATTR_NEIGHBORS);
    _context.triggerSolverPlot =  tag.getBooleanAttributeValue(ATTR_TRIGGER_SOLVER);
    _context.timestepInterval = tag.getIntAttributeValue(ATTR_TIMESTEP_INTERVAL);
    bool plotNormals = tag.getBooleanAttributeValue(ATTR_NORMALS);
    _context.exportSpacetree = tag.getBooleanAttributeValue(ATTR_SPACETREE);
    std::string type = tag.getStringAttributeValue(ATTR_TYPE);
    preciceCheck (
        not ((_context.timestepInterval == -1) &&  _context.triggerSolverPlot),
        "xmlTagCallback()", "In tag <export> a timestep interval has to be "
        << "given when trigger-solver is activated!" );
    PtrExport exporter;
    if ( type == VALUE_VTK ){
      exporter = PtrExport ( new ExportVTK(plotNormals) );
    }
    else if ( type == VALUE_VRML ){
      exporter = PtrExport ( new ExportVRML(plotNormals) );
    }
    else {
      preciceError ( "xmlTagCallback()", "Unknown export type!" );
    }
    _context.exporter = exporter;
  }
  return true;
}

}} // namespace precice, io
