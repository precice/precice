// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_IO_EXPORTCONFIGURATION_HPP_
#define PRECICE_IO_EXPORTCONFIGURATION_HPP_

#include "io/ExportContext.hpp"
#include "io/Constants.hpp"
#include "io/SharedPointer.hpp"
#include "utils/xml/XMLTag.hpp"
#include "tarch/logging/Log.h"
#include "precice/Constants.hpp"
#include <string>
#include <vector>

namespace precice {
namespace io {

/**
 * @brief Configuration class for exports.
 */
class ExportConfiguration
{
public:

  /**
   * @brief Name of the xml-tag corresponding to the ExportConfiguration.
   */
  static const std::string& getTag();

  /**
   * @brief Constructor.
   */
  ExportConfiguration();

  /**
   * @brief Parses the export configuration xml-tag.
   *
   * Requirements:
   * - xmlReader has to point to the tag corresponding to ExportConfiguration
   */
  bool parseSubtag ( utils::XMLTag::XMLReader* xmlReader );

  /**
   * @brief Returns true, if xml-tag has been parsed successfully.
   */
  bool isValid() const { return _isValid; }

  /**
   * @brief Returns the configured export context, valid if isValid() is true.
   */
  const ExportContext& getExportContext() const { return _context; }

  /**
   * @brief Callback function required for use of automatic configuration.
   *
   * Is called by utils::XMLTag on automatic configuration every time an xml
   * tag and its attributes have been read.
   * @param callingTag [IN] XML tag currently read.
   * @param xmlReader  [IN] XML Reader responsible for reading the tag.
   * @return True, if the corresponding actions could be successfully performed.
   */
  bool xmlTagCallback (
    utils::XMLTag&            callingTag,
    utils::XMLTag::XMLReader* xmlReader );

  /**
   * @brief Callback from automatic configuration. Not utilitzed here.
   */
  bool xmlEndTagCallback (
    utils::XMLTag&            callingTag,
    utils::XMLTag::XMLReader* xmlReader )
  {
    return true;
  }

private:

  // @brief Logging device.
  static tarch::logging::Log _log;

  // Configuration strings
  const std::string ATTR_LOCATION;
  const std::string ATTR_TYPE;
  const std::string ATTR_AUTO;
  const std::string VALUE_VTK;
  const std::string VALUE_VRML;

  const std::string ATTR_TIMESTEP_INTERVAL;
  const std::string ATTR_NEIGHBORS;
  const std::string ATTR_TRIGGER_SOLVER;
  const std::string ATTR_NORMALS;
  const std::string ATTR_SPACETREE;

  // @brief Flag indicating success of configuration.
  bool _isValid;

  ExportContext _context;
};

}} // namespace precice, io

#endif /* PRECICE_IO_EXPORTCONFIGURATION_HPP_ */
