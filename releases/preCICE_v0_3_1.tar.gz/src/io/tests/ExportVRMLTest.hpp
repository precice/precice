// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_IO_TESTS_EXPORTVRMLTEST_HPP_
#define PRECICE_IO_TESTS_EXPORTVRMLTEST_HPP_

#include "tarch/tests/TestCase.h"
#include "tarch/logging/Log.h"
#include <string>

namespace precice {
namespace io {
namespace tests {


class ExportVRMLTest : public tarch::tests::TestCase
{
public:

   ExportVRMLTest ();

   virtual ~ExportVRMLTest() {};

   /**
    * @brief Empty.
    */
   virtual void setUp () {}

   virtual void run ();

private:

   static tarch::logging::Log _log;

   void testExportDriftRatchet ();

   void testExportCuboid ();
};

}}} // namespace precice, io, tests

#endif // PRECICE_IO_TESTS_EXPORTVRMLTEST_HPP_
