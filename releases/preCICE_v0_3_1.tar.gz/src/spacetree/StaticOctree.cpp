// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "StaticOctree.hpp"
#include "spacetree/impl/StaticTraversal.hpp"
#include "spacetree/impl/Environment.hpp"
#include "query/FindVoxelContent.hpp"
#include "query/FindClosest.hpp"

namespace precice {
namespace spacetree {

tarch::logging::Log StaticOctree:: _log("precice::spacetree::StaticOctree");

StaticOctree:: StaticOctree
(
  const utils::DynVector& center,
  double halflength,
  double refinementLimit )
:
  _center(center),
  _halflength(halflength),
  _refinementLimit(refinementLimit)
{}

void StaticOctree:: initialize
(
  mesh::Mesh& mesh )
{
  preciceTrace1 ( "initialize()", mesh.getName() );
  preciceCheck ( _rootCell.content().empty(), "initialize()",
                 "Initialize can be called only once (or after clearing)!" );
  int dim = _center.size();
  assertion2 ( mesh.getDimensions() == dim, mesh.getDimensions(), dim );
  query::FindVoxelContent findVoxel ( _center, utils::DynVector(dim,_halflength),
      query::FindVoxelContent::INCLUDE_BOUNDARY );
  findVoxel ( mesh );
  int verticesSize = _rootCell.content().vertices().size();
  int edgesSize = _rootCell.content().edges().size();
  int trianglesSize = _rootCell.content().triangles().size();
  _rootCell.content().add ( findVoxel.content() );
  _rootCell.setPosition(positionOnGeometry());
  preciceCheck (
      _rootCell.content().vertices().size() == verticesSize + mesh.vertices().size(),
      "initialize()", "Not all vertices are contained int he spacetree!" );
  preciceCheck (
      _rootCell.content().edges().size() == edgesSize + mesh.edges().size(),
      "initialize()", "Not all edges are contained int he spacetree!" );
  preciceCheck (
      _rootCell.content().triangles().size() == trianglesSize + mesh.triangles().size(),
      "initialize()", "Not all triangles are contained int he spacetree!" );
  mesh.addListener ( *this );
  impl::StaticTraversal<impl::OctreeCell> traversal;
  utils::DynVector halflengths(dim, _halflength);
  int twoPowerDim = std::pow(2.0, dim);
  int sides = (dim == 2) ? 4 : 6;
  impl::Environment env(twoPowerDim, sides);
  if ( dim == 2 ){
    preciceDebug( "Setting 2D environment cell neighbor indices" );
    tarch::la::DynamicVector<int> indices(2);
    indices[0] = 1; indices[1] = 2; // Neighbors cell 0
    env.setNeighborCellIndices(0, indices);
    indices[0] = 0; indices[1] = 3; // Neighbors cell 1
    env.setNeighborCellIndices(1, indices);
    indices[0] = 3; indices[1] = 0; // Neighbors cell 2
    env.setNeighborCellIndices(2, indices);
    indices[0] = 2; indices[1] = 1; // Neighbors cell 3
    env.setNeighborCellIndices(3, indices);

    assignList(indices) = 1, 3; // Sides cell 0
    env.setNeighborSideIndices(0, indices);
    assignList(indices) = 0, 3; // Sides cell 1
    env.setNeighborSideIndices(1, indices);
    assignList(indices) = 1, 2; // Sides cell 2
    env.setNeighborSideIndices(2, indices);
    assignList(indices) = 0, 2; // Sides cell 3
    env.setNeighborSideIndices(3, indices);
  }
  else {
    preciceDebug( "Setting 3D environment cell neighbor indices" );
    assertion1 ( dim == 3, dim );
    tarch::la::DynamicVector<int> indices(3);
    assignList(indices) = 1, 2, 4; // Cell 0
    env.setNeighborCellIndices(0, indices);
    assignList(indices) = 0, 3, 5; // Cell 1
    env.setNeighborCellIndices(1, indices);
    assignList(indices) = 3, 0, 6; // Cell 2
    env.setNeighborCellIndices(2, indices);
    assignList(indices) = 2, 1, 7; // Cell 3
    env.setNeighborCellIndices(3, indices);
    assignList(indices) = 5, 6, 0; // Cell 4
    env.setNeighborCellIndices(4, indices);
    assignList(indices) = 4, 7, 1; // Cell 5
    env.setNeighborCellIndices(5, indices);
    assignList(indices) = 7, 4, 2; // Cell 6
    env.setNeighborCellIndices(6, indices);
    assignList(indices) = 6, 5, 3; // Cell 7
    env.setNeighborCellIndices(7, indices);

    assignList(indices) = 1, 3, 5; // Side 0
    env.setNeighborSideIndices(0, indices);
    assignList(indices) = 0, 3, 5; // Side 1
    env.setNeighborSideIndices(1, indices);
    assignList(indices) = 1, 2, 5; // Side 2
    env.setNeighborSideIndices(2, indices);
    assignList(indices) = 0, 2, 5; // Side 3
    env.setNeighborSideIndices(3, indices);
    assignList(indices) = 1, 3, 4; // Side 4
    env.setNeighborSideIndices(4, indices);
    assignList(indices) = 0, 3, 4; // Side 5
    env.setNeighborSideIndices(5, indices);
    assignList(indices) = 1, 2, 4; // Side 6
    env.setNeighborSideIndices(6, indices);
    assignList(indices) = 0, 2, 4; // Side 7
    env.setNeighborSideIndices(7, indices);
  }
  traversal.refineAll ( _rootCell, _center, halflengths, _refinementLimit, env );
}

void StaticOctree:: meshChanged ( mesh::Mesh& mesh )
{
  preciceTrace1 ( "meshChanged()", mesh.getName() );
  clear();
  initialize(mesh);
}

int StaticOctree:: searchPosition
(
  const utils::DynVector& point )
{
  preciceTrace1 ( "searchPosition()", point );
  impl::StaticTraversal<impl::OctreeCell> traversal;
  utils::DynVector halflengths(point.size(), _halflength);
  return traversal.searchPosition ( _rootCell, point, _center, halflengths );
}

void StaticOctree:: searchDistance
(
  query::FindClosest& findClosest )
{
  preciceTrace1 ( "searchDistance()", findClosest.getSearchPoint() );
  impl::StaticTraversal<impl::OctreeCell> traversal;
  utils::DynVector halflengths(findClosest.getSearchPoint().size(), _halflength);
  traversal.searchDistance ( _rootCell, findClosest, _center, halflengths );
}

int StaticOctree:: searchContent
(
  query::FindVoxelContent& findContent )
{
  preciceTrace2 ( "searchContent()", findContent.getVoxelCenter(),
                  findContent.getVoxelHalflengths() );
  impl::StaticTraversal<impl::OctreeCell> traversal;
  utils::DynVector halflengths(findContent.getVoxelCenter().size(), _halflength);
  return traversal.searchContent ( _rootCell, findContent, _center, halflengths );
}

void StaticOctree:: accept ( Visitor& visitor )
{
  utils::DynVector halflengths(_center.size(), _halflength);
  _rootCell.accept(visitor, _center, halflengths);
}

void StaticOctree:: clear()
{
  _rootCell.clear();
  assertion(_rootCell.content().empty());
}

}} // namespace precice, spacetree
