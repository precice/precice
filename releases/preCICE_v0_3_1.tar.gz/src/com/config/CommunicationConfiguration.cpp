// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "CommunicationConfiguration.hpp"
#include "com/MPIDirectCommunication.hpp"
#include "com/MPIPortsCommunication.hpp"
#include "com/FileCommunication.hpp"
#include "com/SocketCommunication.hpp"
#include "utils/Globals.hpp"
#include "utils/xml/XMLAttribute.hpp"
#include "utils/xml/ValidatorEquals.hpp"
#include "utils/xml/ValidatorOr.hpp"

namespace precice {
namespace com {

tarch::logging::Log CommunicationConfiguration::
   _log("precice::com::CommunicationConfiguration");

const std::string & CommunicationConfiguration:: getTag()
{
  static std::string tag("communication");
  return tag;
}

CommunicationConfiguration:: CommunicationConfiguration()
:
  ATTR_TYPE("type"),
  ATTR_FROM("from"),
  ATTR_TO("to"),
  ATTR_CONTEXT("context"),
  VALUE_MPI("mpi"),
  VALUE_MPI_SINGLE("mpi-single"),
  VALUE_FILES("files"),
  VALUE_SOCKETS("sockets"),
  _communications(),
  _isValid(false)
{}

bool CommunicationConfiguration:: parseSubtag
(
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace ( "parseSubtag()" );
  using namespace utils;
  XMLTag tag ( getTag(), XMLTag::OCCUR_ONCE );

  XMLAttribute<std::string> attrType ( ATTR_TYPE );
  ValidatorEquals<std::string> validMPI ( VALUE_MPI );
  ValidatorEquals<std::string> validMPISingle ( VALUE_MPI_SINGLE );
  ValidatorEquals<std::string> validFiles ( VALUE_FILES );
  ValidatorEquals<std::string> validSockets ( VALUE_SOCKETS );
  attrType.setValidator ( validMPI || validMPISingle || validFiles || validSockets );
  tag.addAttribute(attrType);

  XMLAttribute<std::string> attrFrom ( ATTR_FROM );
  tag.addAttribute(attrFrom);

  XMLAttribute<std::string> attrTo ( ATTR_TO );
  tag.addAttribute(attrTo);

  XMLAttribute<std::string> attrContext(ATTR_CONTEXT);
  attrContext.setDefaultValue("");
  tag.addAttribute(attrContext);

  _isValid = tag.parse(xmlReader, *this);
  return _isValid;
}

PtrCommunication CommunicationConfiguration:: getCommunication
(
  const std::string& from,
  const std::string& to )
{
  using boost::get;
  foreach (ComTuple & tuple, _communications){
    if (get<1>(tuple) == from){
      return get<0>(tuple);
    }
    else if (get<2>(tuple) == from){
      return get<0>(tuple);
    }
  }
  preciceError("getCommunication()", "No communication configured between user \""
               << from << "\" and \"" << to << "\"!");
}

void CommunicationConfiguration:: addCommunication
(
  const std::string& type,
  const std::string& from,
  const std::string& to,
  const std::string& context )
{
  using boost::get;
  bool alreadyAdded = false;
  foreach (ComTuple& tuple, _communications){
    alreadyAdded |= (get<1>(tuple) == from) && (get<2>(tuple) == to);
    alreadyAdded |= (get<2>(tuple) == from) && (get<1>(tuple) == to);
  }
  preciceCheck(not alreadyAdded, "addCommunication()",
      "Multiple communication between between user \"" << from
      << "\" and \"" << to << "\" is invalid!");
  _communications.push_back (
      boost::make_tuple(createCommunication(type, context), from, to) );
}

bool CommunicationConfiguration:: xmlTagCallback
(
   utils::XMLTag&            callingTag,
   utils::XMLTag::XMLReader* xmlReader )
{
  if (callingTag.getName() == getTag()){
    std::string type = callingTag.getStringAttributeValue(ATTR_TYPE);
    std::string from = callingTag.getStringAttributeValue(ATTR_FROM);
    std::string to = callingTag.getStringAttributeValue(ATTR_TO);
    std::string context = callingTag.getStringAttributeValue(ATTR_CONTEXT);
    addCommunication(type, from, to, context);
  }
  return true;
}

PtrCommunication CommunicationConfiguration:: createCommunication
(
  const std::string& communicationName,
  const std::string& context )
{
  if (communicationName == VALUE_MPI){
#   ifdef PRECICE_NO_MPI
    preciceWarning ( "createCommunication()",
                    "Communication type \"" << VALUE_MPI
                    << "\" can only be used when compiling with arguments "
                    << "\"mpi=on\"!" );
    return com::PtrCommunication();
#   else

    return com::PtrCommunication ( new com::MPIPortsCommunication(context) );
#   endif
  }
  else if (communicationName == VALUE_MPI_SINGLE){
#   ifdef PRECICE_NO_MPI
    preciceWarning ( "createCommunication()",
                   "Communication type \"" << VALUE_MPI_SINGLE
                   << "\" can only be used when compiling with arguments "
                   << "\"mpi=on\"!" );
    return com::PtrCommunication();
#   else
    return com::PtrCommunication(new com::MPIDirectCommunication());
#   endif
  }
  else if (communicationName == VALUE_FILES){
    return com::PtrCommunication(new com::FileCommunication(true, context));
  }
  else if (communicationName == VALUE_SOCKETS){
    int port;
    if (context == std::string("")){
      port = 51235;
    }
    else {
      try {
        std::stringstream stream(context);
        stream >> port;
      }
      catch (std::exception& e){
        preciceError("createCommunication()", "Could not convert attribute \"context\""
                     << " value " << context << " to port number for socket communication!");
      }
    }
    return com::PtrCommunication(new com::SocketCommunication(port));
  }
  preciceError ( "createCommunication()", "Unknown communication type \""
                 << communicationName << "\"!" );
}

}} // namespace precice, com
