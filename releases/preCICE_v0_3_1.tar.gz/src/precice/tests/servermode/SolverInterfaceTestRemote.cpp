// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "SolverInterfaceTestRemote.hpp"
#include "precice/SolverInterface.hpp"
#include "precice/impl/SolverInterfaceImpl.hpp"
#include "precice/impl/Participant.hpp"
#include "precice/config/Configuration.hpp"
#include "utils/Globals.hpp"
#include "com/MPIDirectCommunication.hpp"
#include "query/tests/GeometryTestScenarios.hpp"

#include "tarch/tests/TestCaseFactory.h"
registerIntegrationTest(precice::tests::SolverInterfaceTestRemote)

namespace precice {
namespace tests {

tarch::logging::Log SolverInterfaceTestRemote::
   _log ( "precice::tests::SolverInterfaceTestRemote" );

SolverInterfaceTestRemote:: SolverInterfaceTestRemote()
:
  tarch::tests::TestCase ( "tests::SolverInterfaceTestRemote" ),
  _pathToTests()
{}

SolverInterfaceTestRemote:: ~SolverInterfaceTestRemote()
{}

void SolverInterfaceTestRemote:: setUp()
{
  _pathToTests = utils::Globals::getPathToSources() + "/precice/tests/servermode/";
}

void SolverInterfaceTestRemote:: run()
{
# ifndef PRECICE_NO_MPI
  preciceTrace( "run()" );
  typedef utils::Parallel Par;
  if ( Par::getCommunicatorSize() >= 2 ){
    std::vector<int> ranksWanted;
    ranksWanted += 0, 1;
    Par::Communicator comm = Par::getRestrictedCommunicator(ranksWanted);
    if ( Par::getProcessRank() <= 1 ){
      Par::setGlobalCommunicator(comm);
      testMethod ( testGeometryMode );
      Par::setGlobalCommunicator(Par::getCommunicatorWorld());
    }
  }
  if ( Par::getCommunicatorSize() >= 3 ){
    std::vector<int> ranksWanted;
    ranksWanted += 0, 1, 2;
    Par::Communicator comm = Par::getRestrictedCommunicator(ranksWanted);
    if ( Par::getProcessRank() <= 2 ){
      Par::setGlobalCommunicator(comm);
      testMethod ( testCouplingModeWithOneServer );
      testMethod ( testGeometryModeParallel );
      Par::setGlobalCommunicator(Par::getCommunicatorWorld());
    }
  }
  if ( Par::getCommunicatorSize() >= 4 ){
    std::vector<int> ranksWanted;
    ranksWanted += 0, 1, 2, 3;
    Par::Communicator comm = Par::getRestrictedCommunicator(ranksWanted);
    if ( Par::getProcessRank() <= 3 ){
      Par::setGlobalCommunicator(comm);
      testMethod ( testCouplingModeParallelWithOneServer );
      Par::setGlobalCommunicator(Par::getCommunicatorWorld());
    }
  }
# endif // not PRECICE_NO_MPI
}

void SolverInterfaceTestRemote:: configureSolverInterface
(
  const std::string& configFilename,
  SolverInterface&   interface )
{
  preciceTrace1 ( "configureSolverInterface()", configFilename );
  mesh::Mesh::resetGeometryIDsGlobally();
  mesh::Data::resetDataCount();
  impl::Participant::resetParticipantCount();
  config::Configuration config;
  utils::configure ( config, configFilename );
  validate ( config.isValid() );
  interface._impl->configure ( config.getSolverInterfaceConfiguration() );
}

void SolverInterfaceTestRemote:: testGeometryMode()
{
  preciceTrace ( "testGeometryMode()" );
  using namespace tarch::la;
  using utils::DynVector;
  for ( int dim=2; dim <= 3; dim++ ){
    std::string configFilename;
    if (dim == 2){
      configFilename = _pathToTests + "SolverInterfaceTestRemote-geomode-2D.xml";
    }
    else {
      configFilename = _pathToTests + "SolverInterfaceTestRemote-geomode-3D.xml";
    }
    int rank = utils::Parallel::getProcessRank();
    if ( rank == 0 ){
      SolverInterface interface ( "TestAccessor", rank, 2 );
      configureSolverInterface ( configFilename, interface );
      validateEquals ( interface.getDimensions(), dim );
      interface.initialize();
      interface.initializeData(); // is skipped due to geometry mode

      std::set<int> ids = interface.getMeshIDs();
      typedef query::tests::GeometryTestScenarios GeoTests;
      GeoTests geoTests;

      // Test inquireClosestMesh()
      const GeoTests::PointQueryScenario& pointScen = geoTests.pointQueryScenario(dim);
      std::list<DynVector>::const_iterator coordIter = pointScen.queryCoords.begin();
      std::list<double>::const_iterator distIter = pointScen.validDistances.begin();
      std::list<DynVector>::const_iterator distVectorIter = pointScen.validDistanceVectors.begin();
      DynVector distanceVec(dim);
      while ( coordIter != pointScen.queryCoords.end() ){
        ClosestMesh closest = interface.inquireClosestMesh ( raw(*coordIter), ids );
        for(int i=0; i<dim; i++) distanceVec[i] = closest.distanceVector()[i];
        validate ( equals(*distVectorIter, distanceVec) );
        validate ( equals(*distIter, closest.distance()) );
        coordIter ++;
        distIter ++;
        distVectorIter ++;
      }

      // Test inquirePosition()
      const GeoTests::PositionQueryScenario& posScen = geoTests.positionQueryScenario(dim);
      coordIter = posScen.queryCoords.begin();
      std::list<int>::const_iterator posIter = posScen.validPositions.begin();
      while ( coordIter != posScen.queryCoords.end() ){
        int position = interface.inquirePosition ( raw(*coordIter), ids );
        validateEquals ( position, *posIter );
        coordIter ++;
        posIter ++;
      }

      // Test inquireVoxelPosition()
      const GeoTests::VoxelQueryScenario& voxelScen = geoTests.voxelQueryScenario(dim);
      std::list<DynVector>::const_iterator centerIter = voxelScen.queryCenters.begin();
      std::list<DynVector>::const_iterator hIter = voxelScen.queryHalflengths.begin();
      std::list<bool>::const_iterator includeBoundsIter = voxelScen.includeBoundaries.begin();
      posIter = voxelScen.validPositions.begin();
      while ( centerIter != voxelScen.queryCenters.end() ){
        VoxelPosition pos = interface.inquireVoxelPosition ( raw(*centerIter),
                            raw(*hIter), *includeBoundsIter, ids );
        validateEquals ( pos.position(), *posIter );
        centerIter ++;
        hIter ++;
        includeBoundsIter ++;
        posIter ++;
      }

      // Test write data
      DynVector pos(dim, 0.0);
      int meshID = interface.getMeshID ( "Mesh" );
      int posIndex = interface.setWritePosition ( meshID, raw(pos) );
      int dataID = interface.getDataID ( "ScalarData" );
      double value = 1.0;
      interface.writeScalarData ( dataID, posIndex, value );

      assign(pos) = 1.0;
      posIndex = interface.setWritePosition ( meshID, raw(pos) );
      value = 2.0;
      interface.writeScalarData ( dataID, posIndex, value );

      // Test integrate data
      interface.integrateScalarData ( dataID, value );
      validate ( equals(value, 3.0) );

      // Test read data (not really good test...)
      assign(pos) = 0.0;
      posIndex = interface.setReadPosition ( meshID, raw(pos) );
      dataID = interface.getDataID ( "VectorData" );
      DynVector readValue(dim, 2.0);
      interface.readVectorData ( dataID, posIndex, raw(readValue) );
      validate ( equals(readValue, DynVector(dim,0.0)) );

      // Test exporting mesh
      interface.exportMesh ( "remote" );

      interface.advance(1.0);

      // Test integrate data
      interface.integrateScalarData ( dataID, value );
      validate ( equals(value, 0.0) );

      interface.finalize();
    }
    else {
      assertion1 ( rank == 1, rank );
      bool isServer = true;
      impl::SolverInterfaceImpl server ( "TestAccessor", rank, 2, isServer );
      // Perform manual configuration without overwritting logging config
      mesh::Mesh::resetGeometryIDsGlobally();
      mesh::Data::resetDataCount();
      impl::Participant::resetParticipantCount();
      config::Configuration config;
      utils::configure ( config, configFilename );
      validate ( config.isValid() );
      server.configure ( config.getSolverInterfaceConfiguration() );

      validateEquals ( server.getDimensions(), dim );
      server.runServer();
    }
  }
}

void SolverInterfaceTestRemote:: testGeometryModeParallel()
{
  preciceTrace ( "testGeometryModeParalell()" );
  using namespace tarch::la;
  using utils::DynVector;
  for ( int dim=2; dim <= 3; dim++ ){
    std::string configFilename;
    if (dim == 2){
      configFilename = _pathToTests + "SolverInterfaceTestRemote-geomode-2D.xml";
    }
    else {
      configFilename = _pathToTests + "SolverInterfaceTestRemote-geomode-3D.xml";
    }
    int rank = utils::Parallel::getProcessRank();
    if ( (rank == 0) || (rank == 1) ){
      SolverInterface interface ( "TestAccessor", rank, 2 );
      configureSolverInterface ( configFilename, interface );
      validateEquals ( interface.getDimensions(), dim );
      interface.initialize();
      interface.initializeData(); // is skipped due to geometry mode

      std::set<int> ids = interface.getMeshIDs();
      typedef query::tests::GeometryTestScenarios GeoTests;
      GeoTests geoTests;

      // Test inquireClosestMesh()
      const GeoTests::PointQueryScenario& pointScen = geoTests.pointQueryScenario(dim);
      std::list<DynVector>::const_iterator coordIter = pointScen.queryCoords.begin();
      std::list<double>::const_iterator distIter = pointScen.validDistances.begin();
      std::list<DynVector>::const_iterator distVectorIter = pointScen.validDistanceVectors.begin();
      DynVector distanceVec(dim);
      while ( coordIter != pointScen.queryCoords.end() ){
        ClosestMesh closest = interface.inquireClosestMesh ( raw(*coordIter), ids );
        for(int i=0; i<dim; i++) distanceVec[i] = closest.distanceVector()[i];
        validate ( equals(*distVectorIter, distanceVec) );
        validate ( equals(*distIter, closest.distance()) );
        coordIter ++;
        distIter ++;
        distVectorIter ++;
      }

      // Test inquirePosition()
      const GeoTests::PositionQueryScenario & posScen = geoTests.positionQueryScenario(dim);
      coordIter = posScen.queryCoords.begin();
      std::list<int>::const_iterator posIter = posScen.validPositions.begin();
      while ( coordIter != posScen.queryCoords.end() ){
        int position = interface.inquirePosition ( raw(*coordIter), ids );
        validateEquals ( position, *posIter );
        coordIter ++;
        posIter ++;
      }

      // Test inquireVoxelPosition()
      const GeoTests::VoxelQueryScenario& voxelScen = geoTests.voxelQueryScenario(dim);
      std::list<DynVector>::const_iterator centerIter = voxelScen.queryCenters.begin();
      std::list<DynVector>::const_iterator hIter = voxelScen.queryHalflengths.begin();
      std::list<bool>::const_iterator includeBoundsIter = voxelScen.includeBoundaries.begin();
      posIter = voxelScen.validPositions.begin();
      while ( centerIter != voxelScen.queryCenters.end() ){
        VoxelPosition pos = interface.inquireVoxelPosition ( raw(*centerIter),
                            raw(*hIter), *includeBoundsIter, ids );
        validateEquals ( pos.position(), *posIter );
        centerIter ++;
        hIter ++;
        includeBoundsIter ++;
        posIter ++;
      }

      // Test write data
      DynVector pos(dim, 0.0);
      int meshID = interface.getMeshID ( "Mesh" );
      int posIndex = interface.setWritePosition ( meshID, raw(pos) );
      int dataID = interface.getDataID ( "ScalarData" );
      double value = 1.0;
      interface.writeScalarData ( dataID, posIndex, value );

      assign(pos) = 1.0;
      posIndex = interface.setWritePosition ( meshID, raw(pos) );
      value = 2.0;
      interface.writeScalarData ( dataID, posIndex, value );

      // Let the written data of both processes be accumulated
      interface._impl->_accessor->getClientServerCommunication()->send (
          impl::SolverInterfaceImpl::REQUEST_PING, 0 );
      bool ping = false;
      interface._impl->_accessor->getClientServerCommunication()->receive(
          ping, 0 );
      utils::Parallel::synchronizeLocalProcesses();

      // Test integrate data
      interface.integrateScalarData ( dataID, value );
      validate ( equals(value, 6.0) );

      // Test read data (not really good test...)
      assign(pos) = 0.0;
      posIndex = interface.setReadPosition ( meshID, raw(pos) );
      dataID = interface.getDataID ( "VectorData" );
      DynVector readValue(dim, 4.0);
      interface.readVectorData ( dataID, posIndex, raw(readValue) );
      validate ( equals(readValue, DynVector(dim,0.0)) );

      // Test exporting mesh
      std::ostringstream filename;
      filename << "remote-parallel-rank" << rank;
      interface.exportMesh ( filename.str() );

      interface.advance(1.0);

      // Test integrate data
      interface.integrateScalarData ( dataID, value );
      validate ( equals(value, 0.0) );

      interface.finalize();
    }
    else {
      assertion1 ( rank == 2, rank );
      bool isServer = true;
      impl::SolverInterfaceImpl server ( "TestAccessor", 0, 1, isServer );
      // Perform manual configuration without overwritting logging config
      mesh::Mesh::resetGeometryIDsGlobally();
      mesh::Data::resetDataCount();
      impl::Participant::resetParticipantCount();
      config::Configuration config;
      utils::configure ( config, configFilename );
      validate ( config.isValid() );
      server.configure ( config.getSolverInterfaceConfiguration() );

      validateEquals ( server.getDimensions(), dim );
      server.runServer();
    }
  }
}

void SolverInterfaceTestRemote:: testCouplingModeWithOneServer()
{
  preciceTrace( "testCouplingModeWithOneServer()" );
  int rank = utils::Parallel::getProcessRank();
  std::string configFile = _pathToTests + "SolverInterfaceTestRemote-cplmode-1.xml";
  if ( rank == 0 ){
    SolverInterface interface("ParticipantA", 0, 1);
    configureSolverInterface ( configFile, interface );
    double time = 0.0;
    int timesteps = 0;
    double dt = interface.initialize();
    while ( interface.isCouplingOngoing() ){
      time += dt;
      timesteps++;
      dt = interface.advance(dt);
    }
    interface.finalize();
    validateNumericalEquals ( time, 5.0 );
    validateEquals ( timesteps, 5 );
  }
  else if ( rank == 1 ){
    SolverInterface interface("ParticipantB", 0, 1);
    configureSolverInterface ( configFile, interface );
    double time = 0.0;
    int timesteps = 0;
    double dt = interface.initialize();
    while ( interface.isCouplingOngoing() ){
      time += dt;
      timesteps++;
      dt = interface.advance(dt);
    }
    interface.finalize();
    validateNumericalEquals ( time, 5.0 );
    validateEquals ( timesteps, 5 );
  }
  else {
    assertion1 (rank == 2, rank);
    bool isServer = true;
    impl::SolverInterfaceImpl server("ParticipantB", 0, 1, isServer);

    // Perform manual configuration without overwritting logging config
    mesh::Mesh::resetGeometryIDsGlobally();
    mesh::Data::resetDataCount();
    impl::Participant::resetParticipantCount();
    config::Configuration config;
    utils::configure ( config, configFile );
    validate ( config.isValid() );
    server.configure ( config.getSolverInterfaceConfiguration() );

    server.runServer();
  }
}

void SolverInterfaceTestRemote:: testCouplingModeParallelWithOneServer()
{
  preciceTrace( "testCouplingModeParallelWithOneServer()" );
  int rank = utils::Parallel::getProcessRank();
  std::string configFile = _pathToTests + "SolverInterfaceTestRemote-cplmode-1.xml";
  if ( rank == 0 ){
    SolverInterface interface("ParticipantA", 0, 1);
    configureSolverInterface ( configFile, interface );
    double time = 0.0;
    int timesteps = 0;
    double dt = interface.initialize();
    MeshHandle handle = interface.getMeshHandle("Mesh");
    VertexHandle vertices = handle.vertices();
    int scalarDataID = interface.getDataID("ScalarData");
    while ( interface.isCouplingOngoing() ){
      time += dt;
      timesteps++;
      foriter ( VertexIterator, vertex, vertices ){
        interface.writeScalarData(scalarDataID, vertex.vertexID(), 1.0);
      }
      dt = interface.advance(dt);
    }
    interface.finalize();
    validateNumericalEquals ( time, 5.0 );
    validateEquals ( timesteps, 5 );
  }
  else if ( (rank == 1) || (rank == 2) ){
    SolverInterface interface("ParticipantB", rank-1, 2);
    configureSolverInterface ( configFile, interface );
    double time = 0.0;
    int timesteps = 0;
    double dt = interface.initialize();
    int scalarDataID = interface.getDataID("ScalarData");
    while ( interface.isCouplingOngoing() ){
      double value = 0.0;
      interface.readScalarData ( scalarDataID, 0, value );
      validateWithParams1 ( tarch::la::equals(value, 1.0), value );
      time += dt;
      timesteps++;
      dt = interface.advance(dt);
    }
    interface.finalize();
    validateNumericalEquals ( time, 5.0 );
    validateEquals ( timesteps, 5 );
  }
  else {
    assertion1 (rank == 3, rank);
    bool isServer = true;
    impl::SolverInterfaceImpl server("ParticipantB", 0, 1, isServer);

    // Perform manual configuration without overwritting logging config
    mesh::Mesh::resetGeometryIDsGlobally();
    mesh::Data::resetDataCount();
    impl::Participant::resetParticipantCount();
    config::Configuration config;
    utils::configure ( config, configFile );
    validate ( config.isValid() );
    server.configure ( config.getSolverInterfaceConfiguration() );
    server.runServer();
  }
}

}} // namespace precice, tests
