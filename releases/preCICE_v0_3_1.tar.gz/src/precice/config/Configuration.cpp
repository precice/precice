// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "Configuration.hpp"
#include "utils/Globals.hpp"

namespace precice {
namespace config {

tarch::logging::Log Configuration:: _log ( "precice::config::Configuration" );

const std::string & Configuration:: getTag ()
{
  static std::string tag ( "precice-configuration" );
  return tag;
}

Configuration:: Configuration ()
:
  _isValid ( false ),
  _logFilterConfig (),
  _logFormatConfig (),
  _solverInterfaceConfig ()
{}

bool Configuration:: parseSubtag
(
  utils::XMLTag::XMLReader* xmlReader )
{
  using namespace utils;
  XMLTag tag ( getTag(), XMLTag::OCCUR_ONCE );
  XMLTag tagLogFilter ( _logFilterConfig.getTag(), XMLTag::OCCUR_ARBITRARY );
  XMLTag tagLogFormat ( _logFormatConfig.getTag(), XMLTag::OCCUR_NOT_OR_ONCE );
  XMLTag tagSolverInterface ( _solverInterfaceConfig.getTag(), XMLTag::OCCUR_ONCE );
  tag.addSubtag ( tagLogFilter );
  tag.addSubtag ( tagLogFormat );
  tag.addSubtag ( tagSolverInterface );

  _isValid = tag.parse ( xmlReader, *this );
  return _isValid;
}

bool Configuration:: xmlTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace1 ( "xmlTagCallback()", callingTag.getName() );
  if ( callingTag.getName() == _logFilterConfig.getTag() ) {
    _logFilterConfig.parseSubtag ( xmlReader );
    return _logFilterConfig.isValid ();
  }
  else if ( callingTag.getName() == _logFormatConfig.getTag() ) {
    _logFormatConfig.parseSubtag ( xmlReader );
    return _logFormatConfig.isValid ();
  }
  else if ( callingTag.getName() == _solverInterfaceConfig.getTag() ) {
    return _solverInterfaceConfig.parseSubtag ( xmlReader );
  }
  return true;
}

bool Configuration:: xmlEndTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  return true;
}

bool Configuration:: isValid () const
{
  return _isValid;
}

const tarch::logging::configurations::LogFilterConfiguration &
Configuration:: getLogFilterConfiguration () const
{
  return _logFilterConfig;
}

const tarch::logging::configurations::LogOutputFormatConfiguration &
Configuration:: getLogFormatConfiguration () const
{
  return _logFormatConfig;
}

const SolverInterfaceConfiguration &
Configuration:: getSolverInterfaceConfiguration () const
{
  return _solverInterfaceConfig;
}

}} // namespace precice, config
