// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "SolverInterfaceConfiguration.hpp"
#include "ParticipantConfiguration.hpp"
#include "precice/impl/Participant.hpp"
#include "mesh/config/DataConfiguration.hpp"
#include "mesh/config/MeshConfiguration.hpp"
#include "com/config/CommunicationConfiguration.hpp"
#include "geometry/config/GeometryConfiguration.hpp"
#include "spacetree/config/SpacetreeConfiguration.hpp"
#include "cplscheme/config/CouplingSchemeConfiguration.hpp"
#include "mapping/SharedPointer.hpp"
#include "utils/xml/ValidatorEquals.hpp"
#include "utils/xml/ValidatorOr.hpp"
#include "geometry/Geometry.hpp"
#include "cplscheme/config/CouplingSchemeConfiguration.hpp"
#include "cplscheme/UncoupledCouplingScheme.hpp"
#include <limits>

namespace precice {
namespace config {

tarch::logging::Log SolverInterfaceConfiguration:: _log ( "precice::config::SolverInterfaceConfiguration" );


const std::string & SolverInterfaceConfiguration:: getTag ()
{
  static std::string tag ( "solver-interface" );
  return tag;
}

SolverInterfaceConfiguration:: SolverInterfaceConfiguration ()
:
  ATTR_DIMENSIONS ("dimensions"),
  ATTR_GEOMETRY_MODE ("geometry-mode"),
  ATTR_RESTART_MODE ( "restart-mode" ),
  ATTR_SPACETREE_NAME ( "name" ),
  _isValid ( false ),
  _geometryMode ( false ),
  _restartMode ( false ),
  _participants (),
  _dataConfiguration (),
  _meshConfiguration (),
  _comConfiguration (),
  _geometryConfiguration (),
  _spacetreeConfiguration (),
  _participantConfiguration (),
  _couplingSchemeConfiguration (),
  _indexAccessor ( -1 )
{}

bool SolverInterfaceConfiguration:: parseSubtag
(
  utils::XMLTag::XMLReader* xmlReader )
{
  _dimensions = readDimensions ( xmlReader );
  _geometryMode = readGeometryMode ( xmlReader );
  _restartMode = readRestartMode ( xmlReader );

  _dataConfiguration = mesh::PtrDataConfiguration (
      new mesh::DataConfiguration(_dimensions) );
  _meshConfiguration = mesh::PtrMeshConfiguration (
      new mesh::MeshConfiguration(_dataConfiguration) );
  _comConfiguration = com::PtrCommunicationConfiguration (
      new com::CommunicationConfiguration() );
  _geometryConfiguration = geometry::PtrGeometryConfiguration (
      new geometry::GeometryConfiguration(_meshConfiguration, _dimensions) );
  _spacetreeConfiguration = spacetree::PtrSpacetreeConfiguration (
      new spacetree::SpacetreeConfiguration(_dimensions) );
  _participantConfiguration = config::PtrParticipantConfiguration (
      new ParticipantConfiguration(_dimensions, _meshConfiguration,
      _geometryConfiguration, _spacetreeConfiguration) );
  _couplingSchemeConfiguration = cplscheme::PtrCouplingSchemeConfiguration (
    new cplscheme::CouplingSchemeConfiguration(_meshConfiguration,
    _comConfiguration) );

  using namespace utils;

  XMLTag tagSolverInterfaceImpl ( getTag(), XMLTag::OCCUR_ONCE );

  XMLTag subtagData ( mesh::DataConfiguration::getTag(), XMLTag::OCCUR_ARBITRARY );
  tagSolverInterfaceImpl.addSubtag ( subtagData );

  XMLTag subtagCom (
      com::CommunicationConfiguration::getTag(), XMLTag::OCCUR_ARBITRARY );
  tagSolverInterfaceImpl.addSubtag ( subtagCom );

  XMLTag::Occurrence occurrence = XMLTag::OCCUR_ARBITRARY;
  if ( _geometryMode ){
    occurrence = XMLTag::OCCUR_NOT_OR_ONCE;
  }
  XMLTag subtagParticipant ( ParticipantConfiguration::getTag(), occurrence );
  tagSolverInterfaceImpl.addSubtag ( subtagParticipant );

  XMLTag subtagMesh ( mesh::MeshConfiguration::getTag(), XMLTag::OCCUR_ARBITRARY );
  tagSolverInterfaceImpl.addSubtag ( subtagMesh );

  XMLTag subtagGeometry (
      geometry::GeometryConfiguration::getTag(), XMLTag::OCCUR_ARBITRARY );
  tagSolverInterfaceImpl.addSubtag ( subtagGeometry );

  XMLTag subtagSpacetree (
      spacetree::SpacetreeConfiguration::getTag(), XMLTag::OCCUR_ARBITRARY );
  XMLAttribute<std::string> name ( ATTR_SPACETREE_NAME );
  subtagSpacetree.addAttribute ( name );
  tagSolverInterfaceImpl.addSubtag ( subtagSpacetree );

  if ( not _geometryMode ) {
    XMLTag subtagCouplingScheme (
        cplscheme::CouplingSchemeConfiguration::getTag(), XMLTag::OCCUR_ONCE );
    tagSolverInterfaceImpl.addSubtag ( subtagCouplingScheme );
  }
  _isValid = tagSolverInterfaceImpl.parse ( xmlReader, *this );

  if ( _isValid ) {
    _meshConfiguration->setMeshSubIDs ();
  }
  return _isValid;
}

bool SolverInterfaceConfiguration:: xmlTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace1 ( "xmlTagCallback()", callingTag.getName() );
  if ( callingTag.getName() == mesh::DataConfiguration::getTag() ) {
    return _dataConfiguration->parseSubtag ( xmlReader );
  }
  else if ( callingTag.getName() == mesh::MeshConfiguration::getTag() ) {
    return _meshConfiguration->parseSubtag ( xmlReader );
  }
  else if ( callingTag.getName() == com::CommunicationConfiguration::getTag() ) {
    return _comConfiguration->parseSubtag ( xmlReader );
  }
  else if ( callingTag.getName() == geometry::GeometryConfiguration::getTag() ) {
    return _geometryConfiguration->parseSubtag ( xmlReader );
  }
  else if ( callingTag.getName() == spacetree::SpacetreeConfiguration::getTag() ) {
    return  _spacetreeConfiguration->parseSubtag ( xmlReader );
  }
  else if ( callingTag.getName() == ParticipantConfiguration::getTag() ) {
    return _participantConfiguration->parseSubtag ( xmlReader );
  }
  else if ( callingTag.getName() == cplscheme::CouplingSchemeConfiguration::getTag() ) {
    return _couplingSchemeConfiguration->parseSubtag ( xmlReader );
  }
  return true;
}

bool SolverInterfaceConfiguration:: xmlEndTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  if ( (callingTag.getName() == getTag()) and _geometryMode ){
    if ( not _couplingSchemeConfiguration->isValid() ){
      assertion ( _participantConfiguration->getParticipants().size() == 1 );
      std::string name = _participantConfiguration->getParticipants()[0]->getName();
      double maxTime = cplscheme::CouplingScheme::UNDEFINED_TIME;
      int maxTimesteps = cplscheme::CouplingScheme::UNDEFINED_TIMESTEPS;
      int validDigits = 10;
      cplscheme::PtrCouplingScheme cplScheme (
          new cplscheme::UncoupledCouplingScheme(maxTime, maxTimesteps,
          validDigits, name) );
      _couplingSchemeConfiguration->addCouplingScheme ( cplScheme, name );
    }
  }
  return true;
}

int SolverInterfaceConfiguration:: getDimensions() const
{
  assertion ( _isValid );
  return _dimensions;
}

const spacetree::PtrSpacetreeConfiguration &
SolverInterfaceConfiguration:: getSpacetreeConfiguration () const
{
  return _spacetreeConfiguration;
}

const PtrParticipantConfiguration &
SolverInterfaceConfiguration:: getParticipantConfiguration () const
{
  return _participantConfiguration;
}

int SolverInterfaceConfiguration:: readDimensions
(
  tarch::irr::io::IrrXMLReader* xmlReader )
{
  int attributeCount = xmlReader->getAttributeCount();
  for ( int i=0; i < attributeCount; i++ ) {
    if ( xmlReader->getAttributeName(i) == ATTR_DIMENSIONS ) {
      int dimensions = xmlReader->getAttributeValueAsInt(i);
      preciceCheck ( (dimensions == 2) || (dimensions == 3), "readDimensions()",
          "Attribute \"dimensions\" of tag <" << getTag() << "> has to be either"
          << " 2 or 3!");
      return dimensions;
    }
  }
  preciceError ( "readDimensions()", "Attribute \"dimensions\" of tag <"
      << getTag() << "> is missing!" );
}

bool SolverInterfaceConfiguration:: readGeometryMode
(
   tarch::irr::io::IrrXMLReader * xmlReader )
{
  int attributeCount = xmlReader->getAttributeCount();
  for ( int i=0; i < attributeCount; i++ ) {
    if ( xmlReader->getAttributeName(i) == ATTR_GEOMETRY_MODE ) {
      return xmlReader->getAttributeValueAsBool ( i );
    }
  }
  return false;
}

bool SolverInterfaceConfiguration:: readRestartMode
(
  tarch::irr::io::IrrXMLReader * xmlReader )
{
  int attributeCount = xmlReader->getAttributeCount();
  for ( int i=0; i < attributeCount; i++ ) {
    if ( xmlReader->getAttributeName(i) == ATTR_RESTART_MODE ) {
      return xmlReader->getAttributeValueAsBool ( i );
    }
  }
  return false;
}

}} // close namespaces
