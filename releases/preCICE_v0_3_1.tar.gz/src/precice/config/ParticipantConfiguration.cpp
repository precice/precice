// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "ParticipantConfiguration.hpp"
#include "precice/impl/MeshContext.hpp"
#include "precice/impl/DataContext.hpp"
#include "precice/impl/WatchPoint.hpp"
#include "com/config/CommunicationConfiguration.hpp"
#include "action/config/ActionConfiguration.hpp"
#include "mesh/config/MeshConfiguration.hpp"
#include "geometry/config/GeometryConfiguration.hpp"
#include "spacetree/config/SpacetreeConfiguration.hpp"
#include "mapping/Mapping.hpp"
#include "mapping/config/MappingConfiguration.hpp"
#include "utils/Globals.hpp"
#include "utils/xml/XMLAttribute.hpp"
#include "utils/xml/ValidatorEquals.hpp"
#include "utils/xml/ValidatorOr.hpp"
#include "utils/Dimensions.hpp"

namespace precice {
namespace config {

tarch::logging::Log ParticipantConfiguration::
    _log ( "precice::config::ParticipantConfiguration" );

const std::string& ParticipantConfiguration:: getTag()
{
  static std::string tag ( "participant" );
  return tag;
}

ParticipantConfiguration:: ParticipantConfiguration
(
  int dimensions,
  const mesh::PtrMeshConfiguration&           meshConfiguration,
  const geometry::PtrGeometryConfiguration&   geometryConfiguration,
  const spacetree::PtrSpacetreeConfiguration& spacetreeConfiguration )
:
  TAG_WRITE ( "write-data" ),
  TAG_READ ( "read-data" ),
  TAG_DATA_ACTION ( "data-action" ),
  TAG_USE_MESH ( "use-mesh" ),
  TAG_WATCH_POINT ( "watch-point" ),
  TAG_SERVER ( "server" ),
  ATTR_NAME ( "name" ),
  ATTR_SOURCE_DATA ( "source-data" ),
  ATTR_TARGET_DATA ( "target-data" ),
  ATTR_TIMING ( "timing" ),
  ATTR_LOCAL_OFFSET ( "offset" ),
  ATTR_ACTION_TYPE ( "type" ),
  ATTR_FROM ( "from" ),
  ATTR_PROVIDE ( "provide" ),
  ATTR_MESH ( "mesh" ),
  ATTR_COORDINATE ( "coordinate" ),
  ATTR_COMMUNICATION ( "communication" ),
  ATTR_CONTEXT("context"),
  _dimensions ( dimensions ),
  _meshConfig ( meshConfiguration ),
  _geometryConfig ( geometryConfiguration ),
  _spacetreeConfig ( spacetreeConfiguration ),
  _mappingConfig ( new mapping::MappingConfiguration(meshConfiguration) ),
  _isValid ( false ),
  _participants (),
  _watchPointConfigs ()
{
  assertion1 ( (_dimensions == 2) || (_dimensions == 3), _dimensions );
  assertion ( _meshConfig.use_count() > 0 );
}

bool ParticipantConfiguration:: parseSubtag
(
  utils::XMLTag::XMLReader* xmlReader )
{
  using utils::XMLTag;
  using utils::XMLAttribute;
  using utils::ValidatorEquals;
  XMLTag tagParticipant ( getTag(), XMLTag::OCCUR_ONCE );

  XMLAttribute<std::string> attrName ( ATTR_NAME );
  tagParticipant.addAttribute ( attrName );

  XMLTag tagWriteData ( TAG_WRITE, XMLTag::OCCUR_ARBITRARY);
  XMLTag tagReadData  ( TAG_READ, XMLTag::OCCUR_ARBITRARY);
  XMLAttribute<std::string> attrDataName ( ATTR_NAME );
  tagWriteData.addAttribute ( attrDataName );
  tagReadData.addAttribute ( attrDataName );
  XMLAttribute<std::string> attrMesh ( ATTR_MESH );
  tagWriteData.addAttribute ( attrMesh );
  tagReadData.addAttribute ( attrMesh );
  tagParticipant.addSubtag ( tagWriteData );
  tagParticipant.addSubtag ( tagReadData );

  XMLTag tagMapping ( mapping::MappingConfiguration::getTag(), XMLTag::OCCUR_ARBITRARY );
  tagParticipant.addSubtag ( tagMapping );

  XMLTag tagAction ( action::ActionConfiguration::getTag(), XMLTag::OCCUR_ARBITRARY );
  tagParticipant.addSubtag ( tagAction );

  XMLTag tagExport ( io::ExportConfiguration::getTag(), XMLTag::OCCUR_ARBITRARY );
  tagParticipant.addSubtag ( tagExport );

  XMLTag tagWatchPoint ( TAG_WATCH_POINT, XMLTag::OCCUR_ARBITRARY );
  tagWatchPoint.addAttribute ( attrName );
  XMLAttribute<std::string> attrGeometry ( ATTR_MESH );
  tagWatchPoint.addAttribute ( attrGeometry );
  if (_dimensions == 2){
    XMLAttribute<utils::Vector2D> attrCoordinate ( ATTR_COORDINATE );
    tagWatchPoint.addAttribute ( attrCoordinate );
  }
  else {
    XMLAttribute<utils::Vector3D> attrCoordinate ( ATTR_COORDINATE );
    tagWatchPoint.addAttribute ( attrCoordinate );
  }
  tagParticipant.addSubtag ( tagWatchPoint );

  XMLTag tagUseMesh ( TAG_USE_MESH, XMLTag::OCCUR_ARBITRARY );
  tagUseMesh.addAttribute ( attrName );
  if ( _dimensions == 2 ){
    XMLAttribute<utils::Vector2D> attrLocalOffset ( ATTR_LOCAL_OFFSET );
    attrLocalOffset.setDefaultValue ( utils::Vector2D(0.0) );
    tagUseMesh.addAttribute ( attrLocalOffset );
  }
  else {
    XMLAttribute<utils::Vector3D> attrLocalOffset ( ATTR_LOCAL_OFFSET );
    attrLocalOffset.setDefaultValue ( utils::Vector3D(0.0) );
    tagUseMesh.addAttribute ( attrLocalOffset );
  }
  XMLAttribute<std::string> attrFrom ( ATTR_FROM );
  attrFrom.setDefaultValue ( "" );
  tagUseMesh.addAttribute ( attrFrom );
  XMLAttribute<bool> attrProvide ( ATTR_PROVIDE );
  attrProvide.setDefaultValue ( false );
  tagUseMesh.addAttribute ( attrProvide );
  tagParticipant.addSubtag ( tagUseMesh );

  XMLTag tagServer ( TAG_SERVER, XMLTag::OCCUR_NOT_OR_ONCE );
  XMLAttribute<std::string> attrCom ( ATTR_COMMUNICATION );
  tagServer.addAttribute ( attrCom );
  XMLAttribute<std::string> attrContext(ATTR_CONTEXT);
  attrContext.setDefaultValue("");
  tagServer.addAttribute(attrContext);
  tagParticipant.addSubtag ( tagServer );

  _isValid = tagParticipant.parse ( xmlReader, *this );
  return _isValid;
}

bool ParticipantConfiguration:: xmlTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  preciceTrace1 ( "xmlTagCallback()", callingTag.getName() );
  if ( callingTag.getName() == getTag() ) {
    std::string name = callingTag.getStringAttributeValue(ATTR_NAME);
    impl::PtrParticipant p ( new impl::Participant(name, _meshConfig) );
    _participants.push_back ( p );
  }
  else if ( callingTag.getName() == TAG_USE_MESH ) {
    std::string name = callingTag.getStringAttributeValue(ATTR_NAME);
    utils::DynVector offset(_dimensions);
    if ( _dimensions == 2 ){
      offset = callingTag.getVector2DAttributeValue(ATTR_LOCAL_OFFSET);
    }
    else {
      offset = callingTag.getVector3DAttributeValue(ATTR_LOCAL_OFFSET);
    }
    std::string from = callingTag.getStringAttributeValue(ATTR_FROM);
    bool provide = callingTag.getBooleanAttributeValue(ATTR_PROVIDE);
    mesh::PtrMesh mesh = _meshConfig->getMesh ( name );
    preciceCheck ( mesh.use_count() > 0, "xmlTagCallback()", "Participant \""
                   << _participants.back()->getName() << "\" uses mesh \""
                   << name << "\" which is not defined in configuration!" );
    geometry::PtrGeometry geo ( _geometryConfig->getGeometry(name) );
    spacetree::PtrSpacetree spacetree;
    if ( _meshConfig->doesMeshUseSpacetree(name) ) {
      std::string spacetreeName = _meshConfig->getSpacetreeName(name);
      spacetree = _spacetreeConfig->getSpacetree ( spacetreeName );
    }
    _participants.back()->useMesh ( mesh, geo, spacetree, offset, false, from, provide );
  }
  else if ( callingTag.getName() == mapping::MappingConfiguration::getTag() ) {
    return _mappingConfig->parseSubtag ( xmlReader );
  }
  else if ( callingTag.getName() == TAG_WRITE ) {
    std::string dataName = callingTag.getStringAttributeValue(ATTR_NAME);
    std::string meshName = callingTag.getStringAttributeValue(ATTR_MESH);
    mesh::PtrMesh mesh = _meshConfig->getMesh ( meshName );
    preciceCheck ( mesh.use_count() > 0, "xmlTagCallback()", "Participant "
                   << "\"" << _participants.back()->getName() << "\" has to use "
                   << "mesh \"" << meshName << "\" in order to write data to it!" );
    mesh::PtrData data = getData ( mesh, dataName );
    _participants.back()->addWriteData ( data, mesh );
  }
  else if ( callingTag.getName() == TAG_READ ) {
    std::string dataName = callingTag.getStringAttributeValue(ATTR_NAME);
    std::string meshName = callingTag.getStringAttributeValue(ATTR_MESH);
    mesh::PtrMesh mesh = _meshConfig->getMesh ( meshName );
    preciceCheck ( mesh.use_count() > 0, "xmlTagCallback()", "Participant "
                   << "\"" << _participants.back()->getName() << "\" has to use "
                   << "mesh \"" << meshName << "\" in order to read data from it!" );
    mesh::PtrData data = getData ( mesh, dataName );
    _participants.back()->addReadData ( data, mesh );
  }
  else if ( callingTag.getName() == action::ActionConfiguration::getTag() ){
    action::ActionConfiguration config ( _meshConfig );
    bool success = config.parseSubtag ( xmlReader );
    if ( success ){
      bool used = _participants.back()->isMeshUsed( config.getUsedMeshID() );
      preciceCheck ( used, "xmlTagCallback()", "Data action of participant "
                     << _participants.back()->getName()
                     << "\" uses mesh which is not used by the participant!" );
      _participants.back()->addAction ( config.getAction() );
    }
    return success;
  }
  else if ( callingTag.getName() == io::ExportConfiguration::getTag() ){
    io::ExportConfiguration config;
    if ( config.parseSubtag(xmlReader) ){
      //preciceDebug ( "Setting export context with "
      //               << config.exports().size() << " exports" );
      _participants.back()->addExportContext ( config.getExportContext() );
      return true;
    }
    return false;
  }
  else if ( callingTag.getName() == TAG_WATCH_POINT ){
    WatchPointConfig config;
    config.name = callingTag.getStringAttributeValue(ATTR_NAME);
    config.nameMesh = callingTag.getStringAttributeValue(ATTR_MESH);
    if (_dimensions == 2){
      config.coordinates.append(callingTag.getVector2DAttributeValue(ATTR_COORDINATE));
    }
    else {
      config.coordinates.append(callingTag.getVector3DAttributeValue(ATTR_COORDINATE));
    }
    _watchPointConfigs.push_back ( config );
  }
  else if ( callingTag.getName() == TAG_SERVER ){
    std::string comType = callingTag.getStringAttributeValue(ATTR_COMMUNICATION);
    std::string comContext = callingTag.getStringAttributeValue(ATTR_CONTEXT);
    com::CommunicationConfiguration comConfig;
    com::PtrCommunication com = comConfig.createCommunication(comType, comContext);
    _participants.back()->setClientServerCommunication(com);
  }
  return true;
}

bool ParticipantConfiguration:: xmlEndTagCallback
(
  utils::XMLTag&            callingTag,
  utils::XMLTag::XMLReader* xmlReader )
{
  if ( callingTag.getName() == getTag() ) {
    finishParticipantConfiguration ( _participants.back() );
  }
  return true;
}


bool ParticipantConfiguration:: isValid() const
{
  return _isValid;
}

void ParticipantConfiguration:: addParticipant
(
  const impl::PtrParticipant&             participant,
  const mapping::PtrMappingConfiguration& mappingConfig )
{
  _participants.push_back ( participant );
  _mappingConfig = mappingConfig;
  finishParticipantConfiguration ( participant );
}

const std::vector<impl::PtrParticipant>&
ParticipantConfiguration:: getParticipants() const
{
  return _participants;
}

mesh::PtrMesh ParticipantConfiguration:: copy
(
  const mesh::PtrMesh& mesh ) const
{
  int dim = mesh->getDimensions();
  std::string name ( mesh->getName() );
  bool flipNormals = mesh->isFlipNormals ();
  mesh::Mesh* meshCopy = new mesh::Mesh ( name, dim, flipNormals );
  foreach ( const mesh::PtrData& data, mesh->data() ) {
    meshCopy->createData ( data->getName(), data->getDimensions() );
  }
  return mesh::PtrMesh ( meshCopy );
}

const mesh::PtrData & ParticipantConfiguration:: getData
(
  const mesh::PtrMesh& mesh,
  const std::string&   nameData ) const
{
  foreach ( const mesh::PtrData & data, mesh->data() ){
    if ( data->getName() == nameData ) {
      return data;
    }
  }
  preciceError ( "getData()", "Participant \"" << _participants.back()->getName()
                 << "\" assignes data \"" << nameData << "\" wrongly to mesh \""
                 << mesh->getName() << "\"!" );
}

void ParticipantConfiguration:: finishParticipantConfiguration
(
  const impl::PtrParticipant& participant )
{
  preciceTrace1 ( "finishParticipantConfiguration()", participant->getName() );

  // Set input/output meshes for data mappings and mesh requirements
  typedef mapping::MappingConfiguration::ConfiguredMapping ConfMapping;
  foreach ( const ConfMapping& confMapping, _mappingConfig->mappings() ){
    int meshID = confMapping.mesh->getID();
    preciceCheck ( participant->isMeshUsed(meshID), "finishParticipantConfiguration()",
        "Participant \"" << participant->getName() << "\" has mapping"
        << " to/from mesh \"" << confMapping.mesh->getName() << "\" which he does not use!" );
    impl::MeshContext& meshContext = participant->meshContext ( meshID );

    if ( confMapping.direction == mapping::MappingConfiguration::WRITE ){
      mapping::PtrMapping& map = meshContext.writeMappingContext.mapping;
      assertion ( map.use_count() == 0 );
      map = confMapping.mapping;
      if ( map->getInputRequirement() > meshContext.meshRequirement ){
        meshContext.meshRequirement = map->getInputRequirement();
      }
      if ( meshContext.writeMappingContext.localMesh.use_count() == 0 ){
        meshContext.writeMappingContext.localMesh = copy(meshContext.mesh);
      }
      const mesh::PtrMesh& input = meshContext.writeMappingContext.localMesh;
      const mesh::PtrMesh& output = meshContext.mesh;
      map->setMeshes ( input, output );
      meshContext.writeMappingContext.isStationary = confMapping.isStationary;
      meshContext.writeMappingContext.isIncremental = confMapping.isIncremental;
    }
    else {
      assertion ( confMapping.direction == mapping::MappingConfiguration::READ );
      mapping::PtrMapping& map = meshContext.readMappingContext.mapping;
      assertion ( map.use_count() == 0 );
      map = confMapping.mapping;
      if ( map->getOutputRequirement() > meshContext.meshRequirement ){
        meshContext.meshRequirement = map->getOutputRequirement();
      }
      if ( meshContext.readMappingContext.localMesh.use_count() == 0 ){
        meshContext.readMappingContext.localMesh = copy ( meshContext.mesh );
      }
      const mesh::PtrMesh & input = meshContext.mesh;
      const mesh::PtrMesh & output = meshContext.readMappingContext.localMesh;
      map->setMeshes ( input, output );
      meshContext.readMappingContext.isStationary = confMapping.isStationary;
      meshContext.readMappingContext.isIncremental = confMapping.isIncremental;
    }
    if ( confMapping.isStationary || (not confMapping.isIncremental) ){
      if ( meshContext.meshRequirement == mapping::Mapping::TEMPORARY ){
        meshContext.meshRequirement = mapping::Mapping::VERTEX;
      }
    }
  }
  _mappingConfig = mapping::PtrMappingConfiguration (
      new mapping::MappingConfiguration(_meshConfig) ); // Reset

  // Set participant data for data contexts
  foreach ( impl::DataContext & dataContext, participant->writeDataContexts() ){
    int meshID = dataContext.mesh->getID ();
    preciceCheck ( participant->isMeshUsed(meshID), "finishParticipant()",
        "Participant \"" << participant->getName() << "\" has to use mesh \""
        << dataContext.mesh->getName() << "\" when writing data to it!" );
    impl::MeshContext & meshContext = participant->meshContext(meshID);
    if ( meshContext.writeMappingContext.mapping.use_count() > 0 ){
      dataContext.mappingContext = meshContext.writeMappingContext;
      setLocalData ( dataContext, meshContext.mesh );
    }
  }
  foreach ( impl::DataContext & dataContext, participant->readDataContexts() ){
    int meshID = dataContext.mesh->getID ();
    preciceCheck ( participant->isMeshUsed(meshID), "finishParticipant()",
                   "Participant \"" << participant->getName()
                   << "\" has to use mesh \"" << dataContext.mesh->getName()
                   << "\" when reading data from it!" );
    impl::MeshContext & meshContext = participant->meshContext ( meshID );
    if ( meshContext.readMappingContext.mapping.use_count() > 0 ) {
      dataContext.mappingContext = meshContext.readMappingContext;
      setLocalData ( dataContext, meshContext.mesh );
    }
  }

  // Create watch points
  foreach ( const WatchPointConfig & config, _watchPointConfigs ){
    mesh::PtrMesh mesh;
    foreach ( const impl::MeshContext & context, participant->usedMeshContexts() ){
      if ( context.mesh->getName() == config.nameMesh ){
        mesh = context.mesh;
      }
    }
    preciceCheck ( mesh.use_count() > 0, "xmlEndTagCallback()",
                   "Participant \"" << participant->getName()
                   << "\" defines watchpoint \"" << config.name
                   << "\" for mesh \"" << config.nameMesh
                   << "\" which is not used by him!" );
    std::string filename = config.name + ".watchpoint.txt";
    impl::PtrWatchPoint watchPoint (
        new impl::WatchPoint(config.coordinates, mesh, filename) );
    participant->addWatchPoint ( watchPoint );
  }
  _watchPointConfigs.clear ();
}

void ParticipantConfiguration:: setLocalData
(
  impl::DataContext&   dataContext,
  const mesh::PtrMesh& mesh )
{
  int dataID = dataContext.data->getID ();
  std::string dataName = mesh->data(dataID)->getName();
  const mesh::PtrMesh & localMesh = dataContext.mappingContext.localMesh;
  foreach ( const mesh::PtrData & data, localMesh->data() ) {
    if ( data->getName() == dataName ) {
      dataContext.localData = data;
      break;
    }
  }
}

}} // namespace precice, config
