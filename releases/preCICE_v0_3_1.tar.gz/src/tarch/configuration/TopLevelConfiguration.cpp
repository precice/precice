#include "tarch/configuration/TopLevelConfiguration.h"
#include "tarch/configuration/ConfigurationRegistry.h"


tarch::configuration::TopLevelConfiguration::~TopLevelConfiguration() {
}
