// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www5.in.tum.de/peano
#ifndef _LA_DYNAMIC_VECTOR_H_
#define _LA_DYNAMIC_VECTOR_H_

#include "tarch/la/Vector.h"
#include "tarch/la/iterators/DynamicAssignmentIterator.h"
#include "tarch/la/Utilities.h"
#include <sstream>


namespace tarch {
  namespace la {
    template<class Type>
    class DynamicVector;

    template<class Type>
    class VectorView;
  }
}

/**
 * This is a vector where the vector's size is not to be known a priori.
 * Due to this flexibility, it is not as fast as the Vector class. If you need
 * any vector operations, you should convert the dynamic vector into a vector
 * (or implement the stuff yourself ;-)).
 *
 * The notion of a dynamic vector is the one of a column vector, so rows() will
 * return the size whereas cols() always is equal to one.
 *
 * @author Tobias Weinzierl, Tobias Neckel
 */
template <class Type>
class tarch::la::DynamicVector {
  private:
    /**
     * Size of the vector.
     */
    int     _size;
    /**
     * Pointer to array of data.
     */
    Type*   _data;

  public:
    /**
     * Create vector with no entries. Entries have to be appended later.
     */
    DynamicVector();

    /**
     * Create vector. Entries hold garbage.
     */
    DynamicVector(int size);

    /**
     * Create vector and initialise all entries with the given parameter.
     */
    DynamicVector(int size, const Type& initialValue);

    /**
     * Copy constructor.
     */
    DynamicVector(const DynamicVector<Type>& copy);

    /**
     * Copy constructor from a standard Peano vector into the dynamic vector.
     */
    template <int N>
    DynamicVector(const Vector<N,Type>& copy);

    /**
     * Destructor.
     */
    ~DynamicVector();

    /**
     * @return Size of vector
     */
    int size() const;
    /**
     * This method is identical to size, but often used. Therefore, we support
     * it, too.
     *
     * @return Size of vector.
     */
    int rows() const;
    /**
     * This method always returns one.
     *
     * @return One.
     */
    int cols() const;
    /**
     * Append one or several values to the vector.
     *
     * @param newValue Value to append.
     * @param count    How often shall newValue be appended.
     */
    void append(const Type& newValue, int count=1);

    /**
     * Append a whole vector to this vector.
     */
    void append(const DynamicVector<Type>& copy);

    /**
     * Numerical equality. Compares tow vectors and returns the index of the row
     *  with the first inequality or -1 is the vectors are numerically equal.
     */
    int equalsReturnIndex(
      const tarch::la::DynamicVector<Type > & cmp,
			const Type& epsilon
	  ) const;

    /**
     * Numerical equality with default eps (NUMERICAL_ZERO_DIFFERENCE).
     * Compares two vectors and returns the index of the row
     * with the first inequality or -1 if the vectors are numerically equal.
     */
    int defaultNumericalEqualsReturnIndex(
      const tarch::la::DynamicVector<Type > & cmp
    ) const;

    /**
     * Binary equality. Compares two vectors and returns the index of the row
     * with the first inequality or -1 if the vectors are equal.
     */
    int exactEqualsReturnIndex( const tarch::la::DynamicVector<Type > & cmp) const;

    /**
     * Deliver string representation.
     */
    std::string toString() const;

    /**
     * Get a Peano vector with fixed size from the dynamic vector.
     * The result vector may be smaller than the current vector, but
     * its size may not exceed the dynamic vector's size. The operation is to
     * be used with template arguments, i.e.
     * \code
         Vector<3,int> myCopy = myDynamicVector.convert<3>();
       \endcode
     * is a valid code.
     */
    template <int N>
    Vector<N,Type> convert() const;

    /**
     * Method to compute the sqrt of the current vector and return it in a new
     * one. Assertion is set if negative entries are met.
     */
    DynamicVector<Type> sqrt() const;

    /**
     * @return L2 norm of the vector
     */
    Type norm() const;

    /**
     * Method that exports a new vector containing the entries of the current
     * instance in a given range.
     *
     * @param start Start index for range selection.
     * @param stop  Stop  index for range selection.
     */
    DynamicVector<Type> range(
      const int start,
      const int stop
    ) const;
    /**
     * Method that assigns a vector to a given range of the current instance.
     *
     * @param start Start index for range selection.
     * @param stop  Stop  index for range selection.
     */
    void assignRange(
      const int start,
      const int stop,
      const DynamicVector<Type>& vector
    );

    /**
     * Switching the sign.
     */
    void switchSign();
    /**
     * Switching the sign of a vector and add a scalar (i.e. compute scalar -
     * vector).
     *
     * @param scalar Scalar to be added.
     */
    void switchSignAndAddScalar(const Type& scalar);
    /**
     * Computes the dot-product with the given vector.
     */
    Type dot(const DynamicVector<Type>& vector) const;

    /**
     * Element access (read-only)
     */
    const Type& operator()(int i) const;
    /**
     * Element access (write)
     */
    Type& operator()(int i);

    /**
     * Element access (read-only). Please use operator() if possible to keep it
     * consistent with the matrices and Vector.
     */
    const Type& operator[](int i) const;
    /**
     * Element access (write). Please use operator() if possible to keep it
     * consistent with the matrices and Vector.
     */
    Type& operator[](int i);

    /**
     * Assignment operator.
     */
    DynamicVector<Type>& operator=(const DynamicVector<Type>& argument);

    /**
     * Assignment operator.
     */
    DynamicVector<Type>& operator= (const VectorView<Type>& view);

    /**
     * Enables to assign comma separated list, setting more than one component.
     *
     * Examples:
     * vector = 1.0;       // Assigns 1.0 to every component of vector
     * vector = 1.0, 2.0;  // If vector has dimension 2: assigns 1.0 to first
     *                     // component and 2.0 to second component. If the
     *                     // dimension is smaller than 2: compile time error.
     *                     // If the dimensions is larger than 2: runtime
     *                     // assertion.
     */
    iterators::DynamicAssignmentIterator<Type> operator=(const Type& value);

    /**
     * Add a vector argument to the current instance.
     */
    DynamicVector<Type>& operator+=(const DynamicVector<Type>& argument);
    /**
     * Add a scalar to the current instance.
     */
    DynamicVector<Type>& operator+=(const Type& argument);
    /**
     * Element-wise decrement.
     */
    DynamicVector<Type>& operator-=(const Type& argument);
    /**
     * Reduce vector by given vector.
     */
    DynamicVector<Type>& operator-=(const DynamicVector<Type>& argument);
    /**
     * Element-wise multiplication.
     *
     * @param scaling Scaling factor (matrix is multiplied with this scalar).
     */
    DynamicVector<Type>& operator*=(const Type& scaling);
    /**
     * Element-wise division of the current instance.
     *
     * @param scaling Scaling factor (matrix is divided by this scalar).
     */
    DynamicVector<Type>& operator/=(const Type& scaling);
};


/**
 * Add two dynamic vectors.
 */
template <class Type>
tarch::la::DynamicVector<Type> operator+(const tarch::la::DynamicVector<Type>& left, const tarch::la::DynamicVector<Type>& right);

/**
 * Add a dynamic vector and a scalar.
 */
template <class Type>
tarch::la::DynamicVector<Type> operator+(const tarch::la::DynamicVector<Type>& left, const Type& right);



/**
 * Substract two vectors.
 */
template <class Type>
tarch::la::DynamicVector<Type> operator-(const tarch::la::DynamicVector<Type>& left, const tarch::la::DynamicVector<Type>& right);

/**
 * Substract a scalar from a dynamic vector.
 */
template <class Type>
tarch::la::DynamicVector<Type> operator-(const tarch::la::DynamicVector<Type>& left, const Type& right);

/**
 * Substract a dynamic vector from a scalar.
 */
template <class Type>
tarch::la::DynamicVector<Type> operator-(const Type& left, const tarch::la::DynamicVector<Type>& right);


/**
 * Switching the sign of a dynamic vector.
 */
template <class Type>
tarch::la::DynamicVector<Type> operator-(const tarch::la::DynamicVector<Type>& right);


/**
 * Multiply a dynamic vector with a scalar.
 */
template <class Type>
tarch::la::DynamicVector<Type> operator*(const tarch::la::DynamicVector<Type>& matrix, const Type& scaling);


/**
 * Divide a dynamic vector by a scalar.
 *
 * @param vector Vector to be scaled.
 * @param scaling Scaling factor (vector is divided by this scalar).
 *
 * @return New instance of the scaled matrix.
 */
template <class Type>
tarch::la::DynamicVector<Type> operator/(const tarch::la::DynamicVector<Type>& vector, const Type& scaling);

/**
 * Proxy for toString()
 */
template <class Type>
std::ostream& operator<<(std::ostream& out, const tarch::la::DynamicVector<Type>& param);

#include "tarch/la/DynamicVector.cpph"


#endif
