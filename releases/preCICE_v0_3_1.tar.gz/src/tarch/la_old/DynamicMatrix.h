// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www5.in.tum.de/peano
#ifndef _LA_DYNAMIC_MATRIX_H_
#define _LA_DYNAMIC_MATRIX_H_

#include "tarch/la/Matrix.h"
#include "tarch/la/DynamicVector.h"
#include "tarch/la/iterators/DynamicAssignmentIterator.h"


namespace tarch {
  namespace la {
    template <class Type>
    class DynamicMatrix;
  }
}

/**
 * This is a matrix where the matrix' size is not known a priori.
 *
 * The storage is a row-wise one.
 *
 * The main application is more a matrix with a given size at runtime (not
 * a matrix where the number of rows or columns frequently change).
 * If you need such stuff you have to implement it yourself ;-).
 *
 * @author Tobias Neckel
 */
template <class Type>
class tarch::la::DynamicMatrix {
  private:
    /**
     * Number of rows.
     */
    int _rows;
    /**
     * Number of columns.
     */
    int _cols;
    /**
     * Number of entries.
     */
    int _size;
    /**
     * Data array.
     */
    Type* _data;

    /**
     * Allocates data memory.
     */
    void allocateMemory();
    /**
     * Frees data memory.
     */
    void freeMemory();

  public:
    /**
     * Create matrix with given number of rows and cols. Entries hold garbage.
     */
    DynamicMatrix(int rows, int cols);

    /**
     * Create matrix and initialise all entries with the given parameter.
     */
    DynamicMatrix(int rows, int cols, const Type& initialValue);

    /**
     * Copy constructor.
     */
    DynamicMatrix(const DynamicMatrix<Type>& copy);

    /**
     * Copy constructor from a standard Peano vector into the dynamic vector.
     */
//    template <int M, int N>
//    DynamicMatrix(const Matrix<M,N,Type>& copy);

    /**
     * Destructor.
     */
    ~DynamicMatrix();

    /**
     * @return Number of rows.
     */
    int rows() const;

    /**
     * @return Entire row.
     */
    tarch::la::DynamicVector<Type> getRow(const int rowIndex) const;
    /**
     * Set entire row to a specific value.
     */
    void setRow(const int rowIndex, const Type& newValue);
    /**
     * @return Entire column.
     */
    tarch::la::DynamicVector<Type> getColumn(const int colIndex) const;
    /**
     * Set entire column to a specific value.
     */
    void setColumn(const int colIndex, const Type& newValue);

    /**
     * @return Number of columns.
     */
    int cols() const;
    /**
     * @return Total number of entries.
     */
    int size() const;

    /**
     * Deliver string representation.
     */
     std::string toString() const;

    /**
     * Compares tow matrix and returns the index of the row with the first
     * inequality or -1 is the matrices are numerically equal.
     */
    int equalsReturnIndex(
      const tarch::la::DynamicMatrix<Type > & cmp,
			const Type& epsilon
	  ) const;

    /**
     * Numerical equality with default eps (NUMERICAL_ZERO_DIFFERENCE).
     * Compares two matrices and returns the index of the row
     * with the first inequality or -1 if the matrices are numerically equal.
     */
    int defaultNumericalEqualsReturnIndex(
      const tarch::la::DynamicMatrix<Type > & cmp
    ) const;

    /**
     * Binary equality. Compares two matrices and returns the index of the row
     * with the first inequality or -1 if the matrices are equal.
     */
    int exactEqualsReturnIndex(
		  const tarch::la::DynamicMatrix<Type > & cmp
		) const;

    /**
     * Append one or several values to the vector.
     *
     * @param newValue Value to append.
     * @param count    How often shall newValue be appended.
     */
//    void append(const Type& newValue, int count=1);

    /**
     * Append a whole vector to this vector.
     */
//    void append(const DynamicMatrix<Type>& copy);

    /**
     * Get a Peano vector with fixed size from the dynamic vector.
     * The result vector may be smaller than the current vector, but
     * its size may not exceed the dynamic vector's size. The operation is to
     * be used with template arguments, i.e.
     * \code
         Vector<3,int> myCopy = myDynamicMatrix.convert<3>();
       \endcode
     * is a valid code.
     */
//    template <int N>
//    Vector<N,Type> convert() const;

    /**
     * Method to compute the sqrt of the current vector and return it in a new
     * one. Assertion is set if negative entries are met.
     */
    DynamicMatrix<Type> sqrt() const;

    /**
     * Element access (read-only).
     *
     * @param i Row index.
     * @param j Column index.
     */
    const Type& operator()(int i, int j) const;

    /**
     * Element access (write).
     *
     * @param i Row index.
     * @param j Column index.
     */
    Type& operator()(int i, int j);

    /**
     * Assignment operator.
     */
    DynamicMatrix<Type>& operator=(const DynamicMatrix<Type>& argument);
    /**
     * Assignment operator.
     *
     * @param newValue New value to be set for all entries.
     */
//    DynamicMatrix<Type>& operator=(const Type& newValue);
    /**
     * Enables to assign comma separated list, setting more than one component.
     *
     * Examples:
     * vector = 1.0;       // Assigns 1.0 to every component of vector
     * vector = 1.0, 2.0;  // If vector has dimension 2: assigns 1.0 to first
     *                     // component and 2.0 to second component. If the
     *                     // dimension is smaller than 2: compile time error.
     *                     // If the dimensions is larger than 2: runtime
     *                     // assertion.
     */
    iterators::DynamicAssignmentIterator<Type> operator=(const Type& value);

    /**
     * Add a matrix argument to the current instance.
     */
    DynamicMatrix<Type>& operator+=(const DynamicMatrix<Type>& argument);

    /**
     * Element-wise multiplication.
     */
    DynamicMatrix<Type>& operator*=(const Type& scaling);

    /**
     * Element-wise division.
     */
    DynamicMatrix<Type>& operator/=(const Type& scaling);
};


/**
 * Stream operator.
 *
 * @param the matrix to stream.
 */
template <class Type>
std::ostream& operator<<(std::ostream& out, const tarch::la::DynamicMatrix<Type>& param);


/**
 * Add two dynamic matrices.
 */
template <class Type>
tarch::la::DynamicMatrix<Type> operator+(const tarch::la::DynamicMatrix<Type>& left, const tarch::la::DynamicMatrix<Type>& right);



/**
 * Multiply a dynamic matrix with a scalar.
 */
template <class Type>
tarch::la::DynamicMatrix<Type> operator*(const tarch::la::DynamicMatrix<Type>& matrix, const Type& scaling);


/**
 * Divide a dynamic matrix by a scalar.
 *
 * @param matrix Matrix to be scaled.
 * @param scaling Scaling factor (matrix is divided by this scalar).
 *
 * @return New instance of the scaled matrix.
 */
template <class Type>
tarch::la::DynamicMatrix<Type> operator/(const tarch::la::DynamicMatrix<Type>& matrix, const Type& scaling);

/**
 * Proxy for toString()
 */
template <class Type>
std::ostream& operator<<(std::ostream& out, const tarch::la::DynamicMatrix<Type>& param);

#include "tarch/la/DynamicMatrix.cpph"


#endif //_LA_DYNAMIC_MATRIX_H_
