// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www5.in.tum.de/peano
#ifndef _TARCH_LA_DYNAMICCOLUMNMATRIX_H_
#define _TARCH_LA_DYNAMICCOLUMNMATRIX_H_

#include "tarch/la/DynamicVector.h"
#include "tarch/la/iterators/DynamicColAssignmentIterator.h"


#include <vector>
#include <sstream>


namespace tarch {
  namespace la {

    template <class Type>
    class DynamicColumnMatrix;

  }
}

/**
 * Matrix with runtime adaptive size and column-based data layout utilizing the
 * DynamicVector class.
 *
 * This class has been written to support an efficient insertion of new matrix
 * columns at the back and to support the shifted insertion of new columns at
 * the front, i.e. a new column gets inserted at the front while all others are
 * shifted one column back and the last column is deleted. In this operation, the
 * overall matrix size stays the same.
 *
 * @author Bernhard Gatzhammer
 */
template <class Type>
class tarch::la::DynamicColumnMatrix {
  private:

    /**
     * Number of rows.
     */
    int _rows;

    /**
     * Total number of entries.
     */
    int _size;

    /**
     * Matrix column vectors.
     */
    std::vector<DynamicVector<Type>*> _columnVectors;

  public:

    /**
     * Creates an empty matrix.
     */
    DynamicColumnMatrix();

    /**
     * Create matrix with given number of rows and cols. Entries are
     * initialized to a "zero" value corresponding to their type.
     */
    DynamicColumnMatrix(
      int rows,
      int cols
    );

    /**
     * Copy constructor.
     */
    DynamicColumnMatrix(
      const DynamicColumnMatrix<Type>& copy
    );

    /**
     * Destructor, frees memory.
     */
    ~DynamicColumnMatrix();

    /**
     * Returns number of rows in the matrix.
     */
    int rows() const;

    /**
     * Returns number of columns in the matrix.
     */
    int cols() const;

    /**
     * Returns total number of matrix entries.
     */
    int size() const;

    /**
     * Returns a column of the matrix. Efficient, due to column based layout.
     */
    const DynamicVector<Type>& getColumn(
      int colIndex
    ) const;

    /**
     * Returns a column of the matrix. Efficient, due to column based layout.
     */
    DynamicVector<Type>& getColumn(
      int colIndex
    );

    /**
     * Appends a column to front of matrix.
     *
     * Efficient due to column based storage layout.
     */
    void appendFront(
      const DynamicVector<Type>& columnVector
    );

    /**
     * Appends a column to back of matrix.
     *
     * Efficient due to column based storage layout.
     */
    void append(
       const DynamicVector<Type>& columnVector
    );

    /**
     * Appends a matrix column-wise to back of matrix.
     *
     * Efficient due to column based storage layout.
     */
    void append(
      const DynamicColumnMatrix<Type>& matrix
    );

    /**
     * Shifts all entries one to the right, last column entries are lost. Sets
     * entries of given columnVector at first column of matrix.
     *
     * Efficient due to column based storage layout.
     */
    void shiftSetFirst(
      const DynamicVector<Type>& columnVector
    );

    /**
     * Removes a column from the matrix. This operation involves reordering of
     * a std::Vector, which is not very efficient.
     */
    void remove(
      int colIndex
    );

    /**
     * Element access.
     *
     * @param i Row index.
     * @param j Column index.
     */
    const Type& operator()(
      int i,
      int j
    ) const;

    /**
     * Element access.
     *
     * @param i Row index.
     * @param j Column index.
     */
    Type& operator()(
      int i,
      int j
    );

    /**
     * Assignment operator.
     */
    DynamicColumnMatrix<Type>& operator=(
      const DynamicColumnMatrix<Type>& argument
    );

    iterators::DynamicColAssignmentIterator<Type> operator=(
      const Type& argument
    );

    /**
     * Removes all data from the matrix and sets its extents to zero.
     */
    void clear ();
};


/**
 * Streams the given matrix into the given output stream.
 *
 * @param the matrix to stream.
 */
template<typename Type>
std::ostream& operator<<(
  std::ostream&                               out,
  const tarch::la::DynamicColumnMatrix<Type>& param
);

template<typename Type>
tarch::la::DynamicColumnMatrix<Type> operator+(
  const tarch::la::DynamicColumnMatrix<Type>& matrixLeft,
  const tarch::la::DynamicColumnMatrix<Type>& matrixRight
);

template<typename Type>
tarch::la::DynamicColumnMatrix<Type> operator-(
  const tarch::la::DynamicColumnMatrix<Type>& matrixLeft,
  const tarch::la::DynamicColumnMatrix<Type>& matrixRight
);

#include "tarch/la/DynamicColumnMatrix.cpph"

#endif /* _TARCH_LA_DYNAMICCOLUMNMATRIX_H_ */
