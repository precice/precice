// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "ExportVTKTest.hpp"
#include "io/ExportVTK.hpp"
#include "mesh/Triangle.hpp"
#include "mesh/Edge.hpp"
#include "mesh/Vertex.hpp"
#include "mesh/Mesh.hpp"
#include "utils/Parallel.hpp"
#include "utils/Dimensions.hpp"
#include "utils/Globals.hpp"
#include <sstream>

#include "tarch/tests/TestCaseFactory.h"
registerTest(precice::io::tests::ExportVTKTest)

namespace precice {
namespace io {
namespace tests {

tarch::logging::Log ExportVTKTest:: _log ("precice::io::ExportVTKTest");

ExportVTKTest:: ExportVTKTest()
:
  TestCase ("io::ExportVTKTest")
{}

void ExportVTKTest:: run()
{
  PRECICE_MASTER_ONLY {
    testMethod ( testExportTriangulatedMesh );
  }
}

void ExportVTKTest:: testExportTriangulatedMesh()
{
  preciceTrace ( "testExportTriangulatedMesh" );

  for ( int dim=2; dim <= 3; dim++ ){
    mesh::Mesh mesh ("MyMesh", dim, false);
    mesh::Vertex&  v1 = mesh.createVertex ( utils::DynVector(dim, 0.0) );
    mesh::Vertex& v2 = mesh.createVertex ( utils::DynVector(dim, 1.0) );
    utils::DynVector coords3(dim, 0.0);
    coords3[0] = 1.0;
    mesh::Vertex& v3 = mesh.createVertex(coords3);

    if ( dim == 2 ){
      mesh.createEdge (v1, v2);
      mesh.createEdge (v2, v3);
      mesh.createEdge (v3, v1);
    }
    else {
      mesh::Edge& e1 = mesh.createEdge (v1, v2);
      mesh::Edge& e2 = mesh.createEdge (v2, v3);
      mesh::Edge& e3 = mesh.createEdge (v3, v1);
      mesh.createTriangle (e1, e2, e3);
    }
    mesh.computeState();

    int propertyId = mesh::PropertyContainer::getFreePropertyID();
    utils::DynVector propertyValue(dim, 1.0);
    v1.setProperty (propertyId, propertyValue);
    v2.setProperty (propertyId, propertyValue);
    v3.setProperty (propertyId, propertyValue);

    ExportVTK exportVTK(true);
    std::ostringstream filename;
    filename << "io-ExportVTKTest-testExportTriangulatedMesh-" << dim << "d";
    exportVTK.doExport ( filename.str(), mesh );
  }
}

}}} // namespace precice, io, tests
