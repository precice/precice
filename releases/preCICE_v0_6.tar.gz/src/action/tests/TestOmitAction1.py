
def performAction(time):
    pass
    
#def vertexCallback(id, coords, normal):
#    print "vertex callback ..."
    
#def postAction():
#    print "postAction ..."