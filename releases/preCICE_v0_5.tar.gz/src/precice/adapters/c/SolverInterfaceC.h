/* Copyright (C) 2011 Technische Universitaet Muenchen
 * This file is part of the preCICE project. For conditions of distribution and
 * use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License */
#ifndef PRECICE_ADAPTERS_SOLVERINTERFACEC_H_
#define PRECICE_ADAPTERS_SOLVERINTERFACEC_H_

/**
 * @brief Creates the coupling interface and confiures it.
 *
 * Has to be called before any other method of this interface.
 *
 * @param accessorName [IN] Name of the solver accessing the interface. Has to
 *                          match one of the names specified in the
 *                          configuration xml file.
 * @param configFileName [IN] (Path and) name of the xml configuration file
 *                            containing the precice configuration.
 */
void precice_createSolverInterface (
  const char* accessorName,
  const char* configFileName,
  int         solverProcessIndex,
  int         solverProcessSize );

/**
 * @brief Initiates the coupling to the coupling supervisor.
 *
 * @return Maximal length of first timestep to be computed by solver.
 */
double precice_initialize();

/**
 * @brief Exchanges data between solver and coupling supervisor.
 *
 * @param computedTimestepLength [IN] Length of timestep computed by solver.
 * @return Maximal length of next timestep to be computed by solver.
 */
double precice_advance ( double computedTimestepLength );

/**
 * @brief Finalizes the coupling to the coupling supervisor.
 */
void precice_finalize();

/**
 * @brief Returns the number of spatial configurations for the coupling.
 */
int precice_getDimensions();

/**
 * @brief Returns true (->1), if the coupled simulation is ongoing
 */
int precice_isCouplingOngoing();

/**
 * @brief Returns true (->1), if the coupling timestep is completed.
 */
int precice_isCouplingTimestepComplete();

int precice_isWriteDataRequired ( double computedTimestepLength );

/**
 * @brief Returns true (->1), if new data to read is available.
 */
int precice_isReadDataAvailable();


int precice_isActionRequired ( const char* action );

void precice_fulfilledAction ( const char* action );

/**
 * @brief Returns geometry id belonging to the given geometry name
 */
int precice_getMeshID ( const char* geometryName );

/**
 * @brief Returns true (!=0), if data with given name is available.
 */
int precice_hasData ( const char* dataName );

/**
 * @brief Returns the data id belonging to the given name.
 *
 * The given name (dataName) has to be one of the names specified in the
 * configuration file. The data id obtained can be used to read and write
 * data to and from the coupling mesh.
 */
int precice_getDataID ( const char* dataName );

int precice_setMeshVertex (
  int           meshID,
  const double* position );

int precice_setReadPosition (
  int           meshID,
  const double* position );

int precice_setWritePosition (
  int           meshID,
  const double* position );

int precice_setMeshEdge (
  int meshID,
  int firstVertexID,
  int secondVertexID );

void precice_setMeshTriangle (
  int meshID,
  int firstEdgeID,
  int secondEdgeID,
  int thirdEdgeID );

/**
 * @brief Sets a triangle from vertex IDs. Creates missing edges.
 */
void precice_setMeshTriangleWithEdges (
  int meshID,
  int firstVertexID,
  int secondVertexID,
  int thirdVertexID );

/**
 * @brief Writes vector data values given as block.
 *
 * The block must contain the vector values in the following form:
 * values = (d0x, d0y, d0z, d1x, d1y, d1z, ...., dnx, dny, dnz), where n is
 * the number of vector values. In 2D, the z-components are removed.
 *
 * @param dataID [IN] ID of the data to be written.
 * @param size [IN] Number of indices, and number of values * dimensions.
 * @param values [IN] Values of the data to be written.
 */
void precice_writeBlockVectorData (
  int     dataID,
  int     size,
  int*    valueIndices,
  double* values );

/**
 * @brief Writes vectorial foating point data to the coupling mesh.
 *
 * @param dataID [IN] ID of the data to be written. Obtained by getDataID().
 * @param dataPosition [IN] Spatial position of the data to be written.
 * @param dataValue [IN] Vectorial data value to be written.
 */
void precice_writeVectorData (
  int           dataID,
  int           valueIndex,
  const double* dataValue );

/**
 * @brief Writes scalar floating point data to the coupling mesh.
 *
 * @param dataID [IN] ID of the data to be written. Obtained by getDataID().
 * @param dataPosition [IN] Spatial position of the data to be written.
 * @param dataValue [IN] Scalar data value to be written.
 */
void precice_writeScalarData (
  int    dataID,
  int    valueIndex,
  double dataValue );

/**
 * @brief Reads vector data values given as block.
 *
 * The block contains the vector values in the following form:
 * values = (d0x, d0y, d0z, d1x, d1y, d1z, ...., dnx, dny, dnz), where n is
 * the number of vector values. In 2D, the z-components are removed.
 *
 * @param dataID [IN] ID of the data to be read.
 * @param size [IN] Number of indices, and number of values * dimensions.
 * @param valueIndices [IN] Indices (from setReadPosition()) of data values.
 * @param values [IN] Values of the data to be read.
 */
void precice_readBlockVectorData (
  int     dataID,
  int     size,
  int*    valueIndices,
  double* values );

/**
 * @brief Reads vectorial foating point data from the coupling mesh.
 *
 * @param dataID [IN] ID of the data to be read. Obtained by getDataID().
 * @param dataPosition [IN] Position where the read data should be mapped to.
 * @param dataValue [OUT] Vectorial data value read.
 */
void precice_readVectorData (
  int     dataID,
  int     valueIndex,
  double* dataValue );

/**
 * @brief Reads scalar foating point data from the coupling mesh.
 *
 * @param dataID [IN] ID of the data to be read. Obtained by getDataID().
 * @param dataPosition [IN] Position where the read data should be mapped to.
 * @param dataValue [OUT] Scalar data value read.
 */
void precice_readScalarData (
  int     dataID,
  int     valueIndex,
  double* dataValue );

/**
 * @brief Computes and maps all data written to mesh with given ID.
 *
 * Is automatically called in advance, if not called manually before.
 */
void precice_mapWrittenData ( int meshID );

/**
 * @brief Computes and maps all data to be read from mesh with given ID.
 */
void precice_mapReadData ( int meshID );

/**
 * @brief Exports the coupling mesh to a vtk file
 *
 * @param filenameSuffix [IN] Suffix added to the vtk filename.
 */
void precice_exportMesh ( const char* filenameSuffix );

#endif /* PRECICE_ADAPTERS_SOLVERINTERFACEC_H_ */
