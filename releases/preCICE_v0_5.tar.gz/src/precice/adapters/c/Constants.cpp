// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
extern "C" {
#include "Constants.h"
}

#include "precice/Constants.hpp"

const char* precice_nameConfiguration()
{
  return precice::constants::nameConfiguration().c_str();
}

//int precice_dimensions = precice::constants::dimensions();
