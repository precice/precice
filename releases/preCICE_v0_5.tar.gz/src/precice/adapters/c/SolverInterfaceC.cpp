// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
extern "C" {
#include "SolverInterfaceC.h"
}
#include "precice/impl/SolverInterfaceImpl.hpp"
#include "utils/Globals.hpp"
#include "utils/Dimensions.hpp"
#include <string>
#include "boost/smart_ptr.hpp"
#include <vector>

precice::impl::SolverInterfaceImpl* impl = NULL;

void precice_createSolverInterface
(
  const char* accessorName,
  const char* configFileName,
  int         solverProcessIndex,
  int         solverProcessSize )
{
  std::string stringAccessorName ( accessorName );
  impl = new precice::impl::SolverInterfaceImpl ( stringAccessorName,
      solverProcessIndex, solverProcessSize, false );
  std::string stringConfigFileName ( configFileName );
  impl->configure ( stringConfigFileName );
}

double precice_initialize()
{
  assertion ( impl != NULL );
  return impl->initialize ();
}

double precice_advance( double computedTimestepLength )
{
  assertion ( impl != NULL );
  return impl->advance ( computedTimestepLength );
}

void precice_finalize()
{
  assertion ( impl != NULL );
  impl->finalize ();
}

int precice_getDimensions()
{
  assertion ( impl != NULL );
  return impl->getDimensions();
}

int precice_isCouplingOngoing()
{
  assertion ( impl != NULL );
  if ( impl->isCouplingOngoing() ) {
    return 1;
  }
  return 0;
}

int precice_isCouplingTimestepComplete()
{
  assertion ( impl != NULL );
  if ( impl->isTimestepComplete() ){
    return 1;
  }
  return 0;
}

int precice_isReadDataAvailable()
{
  assertion ( impl != NULL );
  if ( impl->isReadDataAvailable() ){
     return 1;
  }
  return 0;
}

int precice_isWriteDataRequired ( double computedTimestepLength )
{
  assertion ( impl != NULL );
  if ( impl->isWriteDataRequired(computedTimestepLength) ){
     return 1;
  }
  return 0;
}

int precice_isActionRequired ( const char* action )
{
  assertion ( impl != NULL );
  assertion ( action != NULL );
  if ( impl->isActionRequired(std::string(action)) ){
    return 1;
  }
  return 0;
}

void precice_fulfilledAction ( const char* action )
{
  assertion ( impl != NULL );
  assertion ( action != NULL );
  impl->fulfilledAction ( std::string(action) );
}

int precice_getMeshID ( const char* geometryName )
{
  assertion ( impl != NULL );
  std::string stringGeometryName (geometryName);
  return impl->getMeshID (stringGeometryName);
}

int precice_hasData ( const char* dataName )
{
  assertion ( impl != NULL );
  std::string stringDataName (dataName);
  return impl->hasData (stringDataName);
}

int precice_getDataID ( const char* dataName )
{
  assertion ( impl != NULL );
  std::string stringDataName (dataName);
  return impl->getDataID (stringDataName);
}

int precice_setMeshVertex
(
  int           meshID,
  const double* position )
{
  assertion ( impl != NULL );
  return impl->setMeshVertex ( meshID, position );
}

int precice_setReadPosition
(
  int           meshID,
  const double* position )
{
  assertion ( impl != NULL );
  return impl->setReadPosition ( meshID, position );
}

int precice_setWritePosition
(
  int           meshID,
  const double* position )
{
  assertion ( impl != NULL );
  return impl->setWritePosition ( meshID, position );
}

int precice_setMeshEdge
(
  int meshID,
  int firstVertexID,
  int secondVertexID )
{
  assertion ( impl != NULL );
  return impl->setMeshEdge ( meshID, firstVertexID, secondVertexID );
}

void precice_setMeshTriangle
(
  int meshID,
  int firstEdgeID,
  int secondEdgeID,
  int thirdEdgeID )
{
  assertion ( impl != NULL );
  impl->setMeshTriangle ( meshID, firstEdgeID, secondEdgeID, thirdEdgeID );
}

void precice_setMeshTriangleWithEdges
(
  int meshID,
  int firstVertexID,
  int secondVertexID,
  int thirdVertexID )
{
  assertion ( impl != NULL );
  impl->setMeshTriangleWithEdges ( meshID, firstVertexID, secondVertexID, thirdVertexID );
}

void precice_writeBlockVectorData
(
  int     dataID,
  int     size,
  int*    valueIndices,
  double* values )
{
  assertion(impl != NULL);
  impl->writeBlockVectorData(dataID, size, valueIndices, values);
}

void precice_writeVectorData
(
  int           dataID,
  int           valueIndex,
  const double* dataValue )
{
  assertion ( impl != NULL );
  impl->writeVectorData ( dataID, valueIndex, dataValue );
}

void precice_writeScalarData
(
  int    dataID,
  int    valueIndex,
  double dataValue )
{
  assertion ( impl != NULL );
  impl->writeScalarData ( dataID, valueIndex, dataValue );
}

void precice_readBlockVectorData
(
  int     dataID,
  int     size,
  int*    valueIndices,
  double* values )
{
  assertion(impl != NULL);
  impl->readBlockVectorData(dataID, size, valueIndices, values);
}

void precice_readVectorData
(
  int     dataID,
  int     valueIndex,
  double* dataValue )
{
  assertion ( impl != NULL );
  impl->readVectorData (dataID, valueIndex, dataValue);
}

void precice_readScalarData
(
  int     dataID,
  int     valueIndex,
  double* dataValue )
{
  assertion ( impl != NULL );
  impl->readScalarData (dataID, valueIndex, *dataValue);
}

void precice_mapWrittenData ( int meshID )
{
  assertion ( impl != NULL );
  impl->mapWrittenData(meshID);
}

void precice_mapReadData ( int meshID )
{
  assertion ( impl != NULL );
  impl->mapReadData(meshID);
}

void precice_exportMesh
(
  const char* filenameSuffix )
{
  assertion ( impl != NULL );
  std::string stringFilenameSuffix ( filenameSuffix );
  impl->exportMesh ( stringFilenameSuffix );
}
