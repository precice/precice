// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_MESH_MERGE_HPP_
#define PRECICE_MESH_MERGE_HPP_

#include "mesh/Group.hpp"
#include "mesh/Vertex.hpp"
#include "mesh/Edge.hpp"
#include "mesh/Triangle.hpp"
#include <set>

//namespace precice {
//  namespace mesh {
//    class PropertyCONTAINER_T;
//  }
//}
//
// ---------------------------------------------------------- CLASS DEFINITION

namespace precice {
namespace mesh {

/**
 * @brief Merges all visitable objects into one Group while avoiding duplicates.
 *
 * Works for Triangle, Edge, and Vertex objects at the moment.
 *
 * The uniqueness of the merge is ensured by creating and checking a
 * property for every merged visitable. If the same visitable is encountered
 * a second time, it already has the property and is not merged again, hence.
 * The created properties are deleted on destruction of the MergeUniquelyVisitor
 * object.
 */
class Merge
{
public:

  /**
   * @brief Constructor.
   */
  Merge();

  /**
   * @brief Destructor. Removes temporary property from merged objects.
   */
  ~Merge();

  /**
   * @brief Merges the content of a CONTAINER_T with already merged content.
   */
  template<typename CONTAINER_T>
  Group& operator() ( CONTAINER_T& container );

  /**
   * @brief Returns the merged visitables
   */
  Group& content();

  /**
   * @brief Returns the index of the property used to mark merged visitables.
   */
  //int getPropertyIndex();

private:

  // @brief Unique ID for merging flag, used to ensure unique merge
  //const int PROPERTY_ID;

  // @brief Merged visitables
  Group _merged;

  std::vector<bool> _vertices;

  std::vector<bool> _edges;

  std::vector<bool> _triangles;

  /**
   * @brief Returns, whether the visitable is already merged/contained
   */
  //bool isUnique ( PropertyCONTAINER_T & cont );
};

// --------------------------------------------------------- HEADER DEFINITIONS

template<typename CONTAINER_T>
Group& Merge:: operator() ( CONTAINER_T& container )
{
  std::set<Vertex*> vertices;
  foreach ( Vertex& vertex, container.vertices() ){
    if ( vertices.find(&vertex) == vertices.end() ){
      vertices.insert(&vertex);
      _merged.add(vertex);
    }
  }
  vertices.clear();
  std::set<Edge*> edges;
  foreach ( Edge& edge, container.edges() ){
    if ( edges.find(&edge) == edges.end() ){
      edges.insert(&edge);
      _merged.add(edge);
    }
  }
  edges.clear();
  std::set<Triangle*> triangles;
  foreach ( Triangle& triangle, container.triangles() ){
    if ( triangles.find(&triangle) == triangles.end() ){
      triangles.insert(&triangle);
      _merged.add(triangle);
    }
  }
  return _merged;
}

}} // namespace precice, mesh

#endif /* PRECICE_MESH_MERGE_HPP_ */
