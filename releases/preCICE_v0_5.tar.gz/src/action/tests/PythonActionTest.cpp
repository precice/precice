// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "PythonActionTest.hpp"
#include "action/PythonAction.hpp"
#include "utils/Globals.hpp"
#include "mesh/Mesh.hpp"
#include "mesh/Data.hpp"

#ifndef PRECICE_NO_PYTHON
#include "tarch/tests/TestCaseFactory.h"
registerTest(precice::action::tests::PythonActionTest)
#endif // not PRECICE_NO_PYTHON

namespace precice {
namespace action {
namespace tests {

tarch::logging::Log PythonActionTest::
  _log ( "precice::action::tests::PythonActionTest" );

PythonActionTest:: PythonActionTest ()
:
  TestCase ( "precice::action::tests::PythonActionTest" )
{}

void PythonActionTest:: run ()
{
  testMethod ( test );
}

void PythonActionTest:: test ()
{
  preciceTrace ( "test()" );
  mesh::PtrMesh mesh ( new mesh::Mesh("Mesh", 3, false) );
  mesh->createVertex ( utils::Vector3D(1.0) );
  mesh->createVertex ( utils::Vector3D(2.0) );
  mesh->createVertex ( utils::Vector3D(3.0) );
  int targetID = mesh->createData("TargetData",1)->getID();
  int sourceID = mesh->createData("SourceData",1)->getID();
  mesh->allocateDataValues ();
  std::string path = utils::Globals::getPathToSources() + "/action/";
  PythonAction action ( PythonAction::ALWAYS_PRIOR, path, "PythonAction", mesh,
                        targetID, sourceID );
  assignList(mesh->data(sourceID)->values()) = 0.1, 0.2, 0.3;
  assign(mesh->data(targetID)->values()) = 0.0;
  action.performAction ( 0.0, 0.0, 0.0 );
  tarch::la::Vector<3,double> result ( 1.1, 2.2, 3.3 );
}

}}} // namespace precice, action, tests
