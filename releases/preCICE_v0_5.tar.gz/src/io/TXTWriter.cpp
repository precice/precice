// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "TXTWriter.hpp"
#include "utils/Globals.hpp"
#include "tarch/la/DynamicMatrix.h"
#include "tarch/la/DynamicVector.h"
#include <fstream>

namespace precice {
namespace io {

tarch::logging::Log TXTWriter:: _log ( "precice::io::TXTWriter" );

void TXTWriter:: write
(
  const tarch::la::DynamicMatrix<double>& matrix,
  const std::string&                      filename )
{
  std::ofstream outputStream;
  outputStream.open ( filename.c_str() );
  if ( not outputStream ) {
    preciceError ( "TXTWriter()", "Could not open file \"" << filename
                   << "\" for writing matrix!" );
  }
  outputStream.setf ( std::ios::showpoint );
  outputStream.setf ( std::ios::fixed );
  outputStream << std::setprecision(16);
  for ( int i=0; i < matrix.rows(); i++ ){
    for ( int j=0; j < matrix.cols(); j++ ){
      outputStream << matrix(i,j) << " ";
    }
    outputStream << std::endl;
  }
  outputStream.close ();
}

void TXTWriter:: write
(
  const tarch::la::DynamicVector<double>& vector,
  const std::string&                      filename )
{
  std::ofstream outputStream;
  outputStream.open ( filename.c_str() );
  if ( not outputStream ) {
    preciceError ( "TXTWriter()", "Could not open file \"" << filename
                   << "\" for writing vector!" );
  }
  outputStream.setf ( std::ios::showpoint );
  outputStream.setf ( std::ios::fixed );
  outputStream << std::setprecision(16);
  for ( int i=0; i < vector.size(); i++ ){
    outputStream << vector[i] << " ";
  }
  outputStream.close ();
}

}} // namespace precice, io
