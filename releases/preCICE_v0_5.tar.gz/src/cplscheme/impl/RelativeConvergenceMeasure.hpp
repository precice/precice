// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef RELATIVECONVERGENCEMEASURE_HPP_
#define RELATIVECONVERGENCEMEASURE_HPP_

#include "IConvergenceMeasure.hpp"
#include "../CouplingData.hpp"
#include "utils/Helpers.hpp"
#include "utils/Dimensions.hpp"
//#include "utils/NumericalCompare.hpp"
#include "tarch/logging/Log.h"

namespace precice {
   namespace cplscheme {
      namespace tests {
         class RelativeConvergenceMeasureTest;
      }
   }
}

// ----------------------------------------------------------- CLASS DEFINITION

namespace precice {
namespace cplscheme {
namespace impl {

/**
 * @brief Measures the convergence from an old data set to a new one.
 *
 * The convergence is evaluated by looking at the two norm of the differences
 * between each data value from the new and old data set. If the two norm is
 * equal or below a given percentage of the norm of the old data set,
 * convergence is achieved.
 *
 * For a description of how to perform the measurement, see class
 * IConvergenceMeasure.
 */
class RelativeConvergenceMeasure : public IConvergenceMeasure
{
public:

   /**
    * @brief Constructor.
    *
    * @param convergenceLimitPercent [IN]
    *        Limit to define convergence relative to the norm of the current
    *        new dataset. Has to be in $] 0 ; 1 ]$.
    */
   RelativeConvergenceMeasure ( double convergenceLimitPercent );

   virtual ~RelativeConvergenceMeasure () {};

   virtual void newMeasurementSeries ()
   {
      _isConvergence = false;
   }

   virtual void measure (
      const utils::DynVector & oldValues,
      const utils::DynVector & newValues )
   {
      double normDiff = tarch::la::norm2(newValues - oldValues);
      double normNew = tarch::la::norm2(newValues);
      _isConvergence = tarch::la::greaterEquals (
            normNew * _convergenceLimitPercent, normDiff );
      preciceInfo ( "measure()", "Relative convergence measure: "
                    << "two-norm differences = " << normDiff
                    << ", convergence limit = "
                    << normNew * _convergenceLimitPercent
                    << ", convergence = " << _isConvergence );
   }

   virtual bool isConvergence () const
   {
      return _isConvergence;
   }

private:

   static tarch::logging::Log _log;

   double _convergenceLimitPercent;

   bool _isConvergence;
};

}}} // namespace precice, cplscheme, impl

#endif /* RELATIVECONVERGENCEMEASURE_HPP_ */
