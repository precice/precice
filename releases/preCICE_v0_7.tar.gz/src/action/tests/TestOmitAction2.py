
def performAction(time, targetData):
    pass
    
def vertexCallback(id, coords, normal):
    pass
    
#def postAction():
#    print "postAction ..."