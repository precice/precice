/*
 * ArgumentSetFabric.cpp
 *
 *  Created on: 21.07.2011
 *      Author: michael
 */

#include "tarch/argument/ArgumentSetFabric.h"
#include "tarch/Assertions.h"
#include <sstream>


tarch::logging::Log tarch::argument::ArgumentSetFabric::_log("ArgumentSetFabric()");
std::vector<tarch::argument::ArgumentSet> tarch::argument::ArgumentSetFabric::_argumentSets;
bool tarch::argument::ArgumentSetFabric::_isInitialized(false);

tarch::argument::ArgumentSetFabric::ArgumentSetFabric() {
}

tarch::argument::ArgumentSetFabric::~ArgumentSetFabric() {
	// TODO Auto-generated destructor stub
}

void tarch::argument::ArgumentSetFabric::print() {
	std::stringstream ss;
	print(ss);
	_log.info("print",ss.str());
}

void tarch::argument::ArgumentSetFabric::print(std::stringstream& ss) {
	for (std::vector<ArgumentSet>::const_iterator it = _argumentSets.begin(); it!=_argumentSets.end(); ++it) {
		(*it).print(ss);
		ss <<std::endl;
	}
}

void tarch::argument::ArgumentSetFabric::printDefaultArguments(std::stringstream& ss) {
	for (std::vector<ArgumentSet>::const_iterator it = _argumentSets.begin(); it!=_argumentSets.end(); ++it) {
		(*it).printDefaultArguments(ss);
		ss <<std::endl;
	}
}

void tarch::argument::ArgumentSetFabric::printDefaultArguments() {
	std::stringstream ss;
	printDefaultArguments(ss);
	_log.info("print",ss.str());
}

tarch::argument::ArgumentSet tarch::argument::ArgumentSetFabric::getSpecificSet(unsigned int argc, char* argv[]) {
	std::stringstream ss;
	for (std::vector<tarch::argument::ArgumentSet>::iterator it = _argumentSets.begin(); it!=_argumentSets.end(); ++it) {
		if((*it).isArgumentSetName(argv[1])) {
#ifdef Debug
	ss << "\nArgumentSet ";
	(*it).printDefaultArguments(ss);
	ss <<"was selected.";
	_log.debug("getArgumentSet", ss.str());
#endif
			(*it).initialize(argc, argv);
			return *it;
		}
	}
	ss << "ERROR! ArgumentSet not found!! Available configurations:\n";
	print(ss);
	assertionFail(ss.str());
	_log.error("getArgumentSet",ss.str());
	exit(ASSERTION_EXIT_CODE);
	return _argumentSets[0];
}

//tarch::argument::ArgumentSetFabric::ArgumentSetType tarch::argument::ArgumentSetFabric::getCurrentSetting(unsigned int argc, char* argv[]) {
//  if(strcmp(argv[1], "dp")==0&&argc==5){
//      return ArgumentSetFabric::DP;
//  }
//  else if(strcmp(argv[1],"ls-regular")==0&&argc==3) {
//      return ArgumentSetFabric::LS_REGULAR;
//  }
//  else if(strcmp(argv[1],"ls-variant")==0&&argc==4) {
//      return ArgumentSetFabric::LS_VARIANT;
//  }
//  else if(strcmp(argv[1],"run-tests")==0&&argc==2) {
//      return ArgumentSetFabric::RUN_TESTS;
//  }
//  else{
//      return ArgumentSetFabric::UNDEFINED;
//  }
//}

tarch::argument::ArgumentSet tarch::argument::ArgumentSetFabric::getArgumentSet(unsigned int argc, char* argv[]) {
  if(!_isInitialized) {
    _log.error("getArgumentSet","ArgumentSetFabric is not initialized. You have to add Argumentsets to initialize it before"
        "trying to receiving a configuration.");
  }
#ifdef Debug
	std::stringstream ss;
	ss << "The configured argument sets are: " <<std::endl;
	printDefaultArguments(ss);
	_log.debug("getArgumentSet", ss.str());
#endif

	/*
	 * Find user specified argument set
	 */
	ArgumentSet argumentSet = getSpecificSet(argc, argv);
	_log.debug("getArgumentSet()","Argument set successfully returned.");
	return argumentSet;
}

void tarch::argument::ArgumentSetFabric::addArgumentSet(ArgumentSet argumentSet){
  _isInitialized = true;
  _argumentSets.push_back(argumentSet);
}
