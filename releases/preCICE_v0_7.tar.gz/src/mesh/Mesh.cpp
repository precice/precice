// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "Mesh.hpp"
#include "Edge.hpp"
#include "Triangle.hpp"
#include "PropertyContainer.hpp"
#include "utils/Globals.hpp"

namespace precice {
namespace mesh {

tarch::logging::Log Mesh:: _log("precice::mesh::Mesh");

utils::ManageUniqueIDs* Mesh:: _managerPropertyIDs = NULL;

void Mesh:: resetGeometryIDsGlobally()
{
  if (_managerPropertyIDs != NULL){
    _managerPropertyIDs->resetIDs();
  }
}

Mesh:: Mesh
(
  const std::string& name,
  int                dimensions,
  bool               flipNormals )
:
  _name(name),
  _dimensions(dimensions),
  _flipNormals(flipNormals),
  _nameIDPairs(),
  _content(),
  _data(),
  _manageVertexIDs(),
  _manageEdgeIDs(),
  _manageTriangleIDs(),
  _listeners()
{
  if (_managerPropertyIDs == NULL){
    _managerPropertyIDs = new utils::ManageUniqueIDs;
  }
  assertion1((_dimensions == 2) || (_dimensions == 3), _dimensions);
  assertion(_name != std::string(""));
  _nameIDPairs[_name] = _managerPropertyIDs->getFreeID ();
  setProperty(INDEX_GEOMETRY_ID, _nameIDPairs[_name]);
}

Mesh:: ~Mesh()
{
  _content.triangles().deleteElements();
  _content.edges().deleteElements();
  _content.vertices().deleteElements();
}

const Group& Mesh:: content()
{
  return _content;
}

Mesh::VertexContainer& Mesh:: vertices()
{
   return _content.vertices();
}

const Mesh::VertexContainer& Mesh:: vertices() const
{
   return _content.vertices();
}

Mesh::EdgeContainer& Mesh:: edges()
{
   return _content.edges();
}

const Mesh::EdgeContainer& Mesh:: edges() const
{
   return _content.edges();
}

Mesh::TriangleContainer& Mesh:: triangles()
{
   return _content.triangles();
}

const Mesh::TriangleContainer& Mesh:: triangles() const
{
  return _content.triangles();
}

Mesh::PropertyContainerContainer& Mesh:: propertyContainers()
{
  return _propertyContainers;
}

const Mesh::PropertyContainerContainer& Mesh:: propertyContainers() const
{
  return _propertyContainers;
}

int Mesh:: getDimensions() const
{
  return _dimensions;
}

void Mesh:: addListener
(
  Mesh::MeshListener& listener )
{
  foreach (const MeshListener* addedListener, _listeners){
    if (& listener == addedListener){
      return;
    }
//    preciceCheck (&listener != addedListener, "addListener()",
//                   "A mesh listener can be added only once to the same mesh!" );
  }
  _listeners.push_back(& listener);
}

//void Mesh:: removeListener
//(
//  Mesh::MeshListener& listener )
//{
//  _listeners.remove (&listener );
//}

//Vertex& Mesh:: createVertex
//(
//  const utils::Vector3D& coords )
//{
//  assertion1 (_dimensions == 3, _dimensions);
//  Vertex* newVertex = new Vertex (coords, _manageVertexIDs.getFreeID(), *this);
//  newVertex->addParent(*this);
//  _content.add(newVertex);
//  return *newVertex;
//}
//
//Vertex& Mesh:: createVertex
//(
//  const utils::Vector2D& coords )
//{
//  assertion1(_dimensions == 2, _dimensions);
//  Vertex* newVertex = new Vertex(coords, _manageVertexIDs.getFreeID(), *this);
//  newVertex->addParent(*this);
//  _content.add(newVertex);
//  return *newVertex;
//}
//
//Vertex& Mesh:: createVertex
//(
//  const utils::DynVector& coords )
//{
//  assertion2(_dimensions == coords.size(), _dimensions, coords.size());
//  Vertex* newVertex = new Vertex(coords, _manageVertexIDs.getFreeID(), *this);
//  newVertex->addParent(*this);
//  _content.add(newVertex);
//  return *newVertex;
//}

Edge& Mesh:: createEdge
(
  Vertex& vertexOne,
  Vertex& vertexTwo )
{
  Edge* newEdge = new Edge(vertexOne, vertexTwo, _manageEdgeIDs.getFreeID());
  newEdge->addParent(*this);
  _content.add(newEdge);
  return *newEdge;
}

Triangle& Mesh:: createTriangle
(
  Edge& edgeOne,
  Edge& edgeTwo,
  Edge& edgeThree )
{
  Triangle* newTriangle = new Triangle (
      edgeOne, edgeTwo, edgeThree, _manageTriangleIDs.getFreeID());
  newTriangle->addParent(*this);
  _content.add(newTriangle);
  return *newTriangle;
}

PropertyContainer& Mesh:: createPropertyContainer()
{
  PropertyContainer* newPropertyContainer = new PropertyContainer();
  newPropertyContainer->addParent(*this);
  _propertyContainers.push_back(newPropertyContainer);
  return *newPropertyContainer;
}

PtrData& Mesh:: createData
(
  const std::string& name,
  int                dimension )
{
  preciceTrace2("createData()", name, dimension);
  foreach (PtrData data, _data){
    preciceCheck(data->getName() != name, "createData()",
                 "Data \"" << name << "\" cannot be created twice for "
                 << "mesh \"" << _name << "\"!");
  }
  int id = Data::getDataCount();
  PtrData data(new Data(name, id, dimension));
  _data.push_back(data);
  return _data.back();
}

const Mesh::DataContainer& Mesh:: data() const
{
  return _data;
}

const PtrData& Mesh:: data
(
  int dataID ) const
{
   foreach (const PtrData& data, _data){
      if (data->getID() == dataID){
         return data;
      }
   }
   preciceError("data()", "Data with ID = " << dataID << " not found in mesh \""
                << _name << "\"!" );
}

PropertyContainer& Mesh:: getPropertyContainer
(
  const std::string subIDName )
{
  preciceTrace1("getPropertyContainer()", subIDName);
  assertion(_nameIDPairs.count(subIDName) == 1);
  int id = _nameIDPairs[subIDName];
  foreach (PropertyContainer& cont, _propertyContainers){
    if (cont.getProperty<int>(cont.INDEX_GEOMETRY_ID) == id){
      return cont;
    }
  }
  preciceError("getPropertyContainer(string)", "Unknown sub ID name \""
               << subIDName << "\" in mesh \"" << _name << "\"!");
}

const std::string& Mesh:: getName() const
{
  return _name;
}

bool Mesh:: isFlipNormals() const
{
  return _flipNormals;
}

void Mesh:: setFlipNormals
(
  bool flipNormals )
{
  _flipNormals = flipNormals;
}

PropertyContainer& Mesh:: setSubID
(
  const std::string& subIDNamePostfix )
{
  preciceTrace1("setSubID()", subIDNamePostfix);
  preciceCheck(subIDNamePostfix != std::string(""), "setSubID",
      "Sub ID postfix of mesh \"" << _name
      << "\" is not allowed to be an empty string!");
  std::string idName(_name + "-" + subIDNamePostfix);
  preciceCheck(_nameIDPairs.count(idName) == 0, "setSubID",
      "Sub ID postfix of mesh \"" << _name << "\" is already in use!");
  _nameIDPairs[idName] = _managerPropertyIDs->getFreeID();
  PropertyContainer * newPropertyContainer = new PropertyContainer();
  newPropertyContainer->setProperty<int>(PropertyContainer::INDEX_GEOMETRY_ID,
    _nameIDPairs[idName]);
  _propertyContainers.push_back(newPropertyContainer);
  return *newPropertyContainer;
}

const std::map<std::string,int>& Mesh:: getNameIDPairs()
{
  return _nameIDPairs;
}

int Mesh:: getID
(
  const std::string& name ) const
{
  assertion(_nameIDPairs.count(name) > 0);
  return _nameIDPairs.find(name)->second;
}

int Mesh:: getID() const
{
  std::map<std::string,int>::const_iterator iter = _nameIDPairs.find(_name);
  assertion(iter != _nameIDPairs.end());
  return iter->second;
}

void Mesh:: allocateDataValues()
{
  preciceTrace1("allocateDataValues()", _content.vertices().size());
  foreach (PtrData data, _data){
    int total = _content.vertices().size() * data->getDimensions();
    int leftToAllocate = total - data->values().size();
    if (leftToAllocate > 0){
      data->values().append(utils::DynVector(leftToAllocate, 0.0));
    }
    preciceDebug("Data " << data->getName() << " no has "
                 << data->values().size() << " values");
  }
}

void Mesh:: computeState()
{
  preciceTrace("computeState()");
  using utils::DynVector;
  using utils::Vector2D;
  using utils::Vector3D;
  // Compute edge centers, enclosing radius, and (in 2D) edge normals
  DynVector center(_dimensions);
  DynVector distanceToCenter(_dimensions);
  foreach (Edge& edge, _content.edges()){
    center = edge.vertex(0).getCoords();
    center += edge.vertex(1).getCoords();
    center *= 0.5;
    edge.setCenter(center);
    distanceToCenter = edge.vertex(0).getCoords();
    distanceToCenter -= edge.getCenter();
    edge.setEnclosingRadius(tarch::la::norm2(distanceToCenter));
    if (_dimensions == 2){
      // Compute normal
      Vector2D vectorA = edge.vertex(1).getCoords();
      vectorA -= edge.vertex(0).getCoords();
      Vector2D normal(-1.0 *vectorA[1], vectorA[0]);
      if (not _flipNormals){
        normal *= -1.0; // Invert direction if counterclockwise
      }
      double length = tarch::la::norm2(normal);
      assertion(tarch::la::greater(length, 0.0));
      normal /= length;   // Scale normal vector to length 1
      edge.setNormal(normal);

      // Accumulate normal in associated vertices
      normal *= edge.getEnclosingRadius() * 2.0; // Weight by length
      for (int i=0; i < 2; i++){
        Vector2D vertexNormal = edge.vertex(i).getNormal();
        vertexNormal += normal;
        edge.vertex(i).setNormal(vertexNormal);
      }
    }
  }

  // Compute triangle centers, radius, and normals
  if (_dimensions == 3){
    foreach (Triangle& triangle, _content.triangles()){
      assertion2(not tarch::la::equals(triangle.vertex(0).getCoords(),
                 triangle.vertex(1).getCoords()), triangle.vertex(0).getCoords(),
                 triangle.getID());
      assertion2(not tarch::la::equals(triangle.vertex(1).getCoords(),
                 triangle.vertex(2).getCoords()), triangle.vertex(1).getCoords(),
                 triangle.getID());
      assertion2(not tarch::la::equals(triangle.vertex(2).getCoords(),
                 triangle.vertex(0).getCoords()), triangle.vertex(2).getCoords(),
                 triangle.getID());

      // Compute barycenter by using edge centers, since vertex order is not
      // guaranteed.
      Vector3D center;
      center = triangle.edge(0).getCenter();
      center += triangle.edge(1).getCenter();
      center += triangle.edge(2).getCenter();
      center /= 3.0;
      triangle.setCenter(center);

      // Compute enclosing radius centered at barycenter
      Vector3D toCenter;
      toCenter = triangle.getCenter();
      toCenter -= triangle.vertex(0).getCoords();
      double distance0 = tarch::la::norm2(toCenter);
      toCenter = triangle.getCenter();
      toCenter -= triangle.vertex(1).getCoords();
      double distance1 = tarch::la::norm2(toCenter);
      toCenter = triangle.getCenter();
      toCenter -= triangle.vertex(2).getCoords();
      double distance2 = tarch::la::norm2(toCenter);
      double maxDistance = distance0;
      maxDistance = distance1 > maxDistance ? distance1 : maxDistance;
      maxDistance = distance2 > maxDistance ? distance2 : maxDistance;
      triangle.setEnclosingRadius(maxDistance);

      // Compute normal
      Vector3D vectorA;
      Vector3D vectorB;
      vectorA = triangle.edge(1).getCenter();
      vectorA -= triangle.edge(0).getCenter();
      vectorB = triangle.edge(2).getCenter();
      vectorB -= triangle.edge(0).getCenter();
      // Compute cross-product of vector A and vector B
      Vector3D normal;
      normal = tarch::la::cross(vectorA, vectorB, normal);
      if ( _flipNormals ){
        normal *= -1.0; // Invert direction if counterclockwise
      }

      // Accumulate area-weighted normal in associated vertices and edges
      for (int i=0; i < 3; i++){
        triangle.edge(i).setNormal(triangle.edge(i).getNormal() + normal);
        triangle.vertex(i).setNormal(triangle.vertex(i).getNormal() + normal);
      }

      // Normalize triangle normal
      double length = tarch::la::norm2(normal);
      normal /= length;
      triangle.setNormal(normal);
    }

    // Normalize edge normals
    foreach (Edge& edge, _content.edges()){
      double length = tarch::la::norm2(edge.getNormal());
      edge.setNormal(edge.getNormal() / length);
    }
  }

  // Normalize vertex normals
  foreach (Vertex& vertex, _content.vertices()){
    double length = tarch::la::norm2(vertex.getNormal());
    vertex.setNormal(vertex.getNormal() / length);
  }
}

void Mesh:: clear()
{
  _content.triangles().deleteElements();
  _content.edges().deleteElements();
  _content.vertices().deleteElements();
  _propertyContainers.deleteElements();

  _content.clear();
  _propertyContainers.clear();

  _manageTriangleIDs.resetIDs();
  _manageEdgeIDs.resetIDs();
  _manageVertexIDs.resetIDs();

  foreach (mesh::PtrData data, _data){
    data->values().clear();
  }
}

void Mesh:: notifyListeners()
{
  preciceTrace("notifyListeners()");
  foreach (MeshListener* listener, _listeners){
    assertion(listener != NULL);
    listener->meshChanged(*this);
  }
}

}} // namespace precice, mesh
