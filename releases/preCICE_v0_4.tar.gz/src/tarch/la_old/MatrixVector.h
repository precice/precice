// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www5.in.tum.de/peano
#ifndef _TARCH_LA_MATRIXVECTOR_H_
#define _TARCH_LA_MATRIXVECTOR_H_

#include "tarch/la/DynamicMatrix.h"
#include "tarch/la/DynamicColumnMatrix.h"
#include "tarch/la/DynamicVector.h"
#include "tarch/la/Utilities.h"

namespace tarch {
  namespace la {

  /**
   * Computes the inner-product of the given vectors.
   */
  template<int N, typename Type>
  Type dot(
    const Vector<N,Type>& vectorLeft,
    const Vector<N,Type>& vectorRight
  );

  /**
   * Computes the dot-, or inner-product of two vectors.
   */
  template<typename Type>
  Type dot(
    const DynamicVector<Type>& vectorLeft,
    const DynamicVector<Type>& vectorRight
  );

    /**
     * Transposes a matrix. A temporary matrix holding the transposed is created.
     */
    template<typename Type>
    DynamicColumnMatrix<Type> transpose(
      const DynamicColumnMatrix<Type>& matrix
    );

    /**
     * Performs a matrix-vector multiplication. Creates and returns a temporary
     * vector for that purpose.
     */
    template<typename Type>
    DynamicVector<Type> matrixTimesVector(
      const DynamicColumnMatrix<Type>& matrix,
      const DynamicVector<Type>&       vector
    );

    /**
     * Performs a matrix-vector multiplication. The result has to be given as
     * zero-initialized parameter! This is necessary, since the multiplication is
     * performed additively.
     */
    template<typename Type>
    void matrixTimesVector(
      const DynamicColumnMatrix<Type>& matrix,
      const DynamicVector<Type>&       vector,
      DynamicVector<Type>&             result
    );

    /**
     * Performs a matrix-vector multiplication. Creates and returns a temporary
     * vector for that purpose.
     */
    template<typename Type>
    DynamicVector<Type> matrixTimesVector(
      const DynamicMatrix<Type>& matrix,
      const DynamicVector<Type>& vector
    );

    /**
     * Performs a matrix-matrix multiplication. Creates and returns a temporary
     * matrix for that purpose.
     */
    template<typename Type>
    DynamicColumnMatrix<Type> matrixTimesMatrix(
      const DynamicColumnMatrix<Type>& matrixLeft,
      const DynamicColumnMatrix<Type>& matrixRight
    );

    /**
     * Performs a matrix-matrix multiplication. The result has to be given as
     * zero-initialized parameter! This is necessary, since the multiplication is
     * performed additively.
     */
    template<typename Type>
    void matrixTimesMatrix(
      const DynamicColumnMatrix<Type>& matrixLeft,
      const DynamicColumnMatrix<Type>& matrixRight,
      DynamicColumnMatrix<Type>&       result
    );

    /**
     * Performs a matrix-matrix multiplication. Creates and returns a temporary
     * matrix for that purpose.
     */
    template<typename Type>
    DynamicMatrix<Type> matrixTimesMatrix(
      const DynamicMatrix<Type>& matrixLeft,
      const DynamicMatrix<Type>& matrixRight
    );

    /**
     * Performs a back-substitution of the system: matrix * x = rhs.
     *
     * @param matrix An upper trianguler matrix.
     * @param rhs    The righthandside of the equation system.
     * @param x      Unknown vector to be solved for.
     */
    template<typename Type>
    void backSubstitution(
      const DynamicColumnMatrix<Type>& matrix,
      const DynamicVector<Type>&       rhs,
      DynamicVector<Type>&             x
    );
  }
}

#include "tarch/la/MatrixVector.cpph"

#endif /* _TARCH_LA_MATRIXVECTOR_H_ */
