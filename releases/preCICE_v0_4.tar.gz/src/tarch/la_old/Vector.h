// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www5.in.tum.de/peano
#ifndef _TARCH_LA_VECTOR_H_
#define _TARCH_LA_VECTOR_H_

#include <string>
#include <iostream>


#include "tarch/la/iterators/AssignmentIterator.h"


namespace tarch {
  namespace la {
    template<int N, class Type>
    class Vector;

    template<class Type>
    class VectorView;
  }
}



/**
 * Vector class for vectors of any type.
 *
 * !!! FAQ
 *
 * - 3 * myVector does not work for my double vector. Use 3.0 instead.
 * - myVector = 1.3; does not set all the entries to 1.3. Use either
 *   myVector = la:Vector<...>(1.3) or myVector.reset(1.3) instead.
 *
 * @author Tobias Weinzierl, Tobias Neckel
 */
template <int N, class Type>
class tarch::la::Vector {
  private:
    Type _data[N];
  public:
    /**
     * Create vector. Entries hold garbage.
     */
    Vector();

    template<class Container, template<class,class> class Iterator>
    Vector(Iterator<Type*,Container> & iter);

    template<class Container, template<class,class> class Iterator>
    Vector(Iterator<const Type*,Container> & iter);

    /**
     * Create vector and initialise all entries with the given parameter.
     */
    Vector(const Type& initialValue);

    /**
     * Create vector and initialise all entries with the given parameter. This
     * is a constructor without a range check, i.e. you have to be very careful
     * and ensure that the passed array's length is at most N.
     */
    Vector(Type const * const initialValues);

    /**
     * Create 2D vector and initialize component individually.
     *
     * Throws an assertion if N != 2.
     */
    Vector (const Type& initialValue0, const Type& initialValue1);

    /**
     * Create 3D vector and initialize component individually.
     *
     * Throws an assertion if N != 3.
     */
    Vector (
      const Type& initialValue0,
      const Type& initialValue1,
      const Type& initialValue2
    );

    /**
     * Create 4D vector and initialize component individually.
     *
     * Throws an assertion if N != 4.
     */
    Vector (
      const Type& initialValue0,
      const Type& initialValue1,
      const Type& initialValue2,
      const Type& initialValue3
    );

    /**
     * Create 8D vector and initialize component individually.
     *
     * Throws an assertion if N != 8.
     */
    Vector (
      const Type& initialValue0,
      const Type& initialValue1,
      const Type& initialValue2,
      const Type& initialValue3,
      const Type& initialValue4,
      const Type& initialValue5,
      const Type& initialValue6,
      const Type& initialValue7
    );

    /**
     * Copy constructor.
     */
    Vector(const Vector<N,Type>& copy);

    /**
     * Destructor.
     */
    ~Vector();

    /**
     * Get pointer to actual data. Important for the MPI support.
     */
    Type const *  data() const;

    /**
     * This operation gives you access to a subset of the data. There's no
     * range check done here, so be in particular careful to use it. To
     */
    Type const * data(int i) const;

    /**
     * Set a subvector. There's no range check done here, so be particularly
     * careful to use it.
     *
     * Example:
\code
  Vector<8,double> source;
  Vector<4,double> target1(source.data(0));
  Vector<4,double> target2(source.data(4));

  // or the other way round:
  source.setData(target1,0);
  source.setData(target2,4);
\endcode
     */
    template<int M>
    void setData(const Vector<M,Type>& copy, int startIndex);

    /**
     * Copies vector data to iterator data.
     */
    template<class Container, template<class,class> class Iterator>
    void copyToIterable(Iterator<Type*,Container> & iter) const;

    /**
     * Resets all vector entries to type.
     */
    void reset(const Type& type);

    /**
     * Element access (read-only)
     */
    const Type& operator()(int i) const;

    /**
     * Element access (write)
     */
    Type& operator()(int i);

    /**
     * Element access (read-only). Please use operator() if possible to keep it
     * consistent with the matrices.
     */
    const Type& operator[](int i) const;

    /**
     * Element access (write). Please use operator() if possible to keep it
     * consistent with the matrices.
     */
    Type& operator[](int i);

    /**
     * Element-wise increment.
     */
    Vector<N,Type>& operator+=(const Type& argument);

    /**
     * Element-wise decrement.
     */
    Vector<N,Type>& operator-=(const Type& argument);

    /**
     * Element-wise scaling
     */
    Vector<N,Type>& operator*=(const Type& argument);

    /**
     * Element-wise scaling
     */
    Vector<N,Type>& operator/=(const Type& argument);

    /**
     * Scaling by different entries of another vector.
     */
    Vector<N,Type>& operator/=(const Vector<N,Type>& argument);

    /**
     * Assignment operator.
     */
    Vector<N,Type>& operator=(const Vector<N,Type>& argument);

    /**
     * Assigning operator.
     */
    Vector<N,Type>& operator=(const VectorView<Type>& view);

    /**
     * Add two vector.
     */
    Vector<N,Type>& operator+=(const Vector<N,Type>& argument);

    /**
     * Reduce vector by given vector.
     */
    Vector<N,Type>& operator-=(const Vector<N,Type>& argument);

    /**
     * Compares two vectors, i.e. it analyses the entries of the vector one by one
     * and compares them. As soon as one is smaller than the other, this is the
     * result of the comparison.
     */
    bool operator<(const tarch::la::Vector<N,Type>& right) const;

    /**
     * Enables to assign comma separated list, setting more than one component.
     *
     * Examples:
     * vector = 1.0;       // Assigns 1.0 to every component of vector
     * vector = 1.0, 2.0;  // If vector has dimension 2: assigns 1.0 to first
     *                     // component and 2.0 to second component. If the
     *                     // dimension is smaller than 2: compile time error.
     *                     // If the dimensions is larger than 2: runtime
     *                     // assertion.
     */
    tarch::la::iterators::FirstAssignmentIterator<N-1, Type> operator=(const Type& value);

    /**
     * Switching the sign of a vector.
     */
    void switchSign();

    /**
     * @return index Of biggest component. If two components are equal,
     *         operation returns the smaller one.
     */
    int getIndexOfBiggestComponent() const;

    /**
     * Switching the sign of a vector and add a scalar (i.e. compute scalar -
     * vector).
     *
     * @param scalar Scalar to be added.
     */
    void switchSignAndAddScalar(const Type& scalar);

    /**
     * Dot product.
     */
    Type dot(const Vector<N,Type>& argument) const;

    /**
     * Multiplies each component i of calling vector with component i of right.
     */
    Vector<N, Type> multiplyComponentsWith(const Vector<N,Type>& right) const;

    /**
     * Cross product. Works only for N=3 and doubles.
     */
    Vector<N,Type> cross(const Vector<N,Type>& parameter);

    /**
     * Volume computation.
     *
     * Interprets the vector as the spanning vector of a N-dimensional
     * hyperhexahedron. The operation then returns the volume of this
     * hexahedron.
     */
    Type getVolume() const;

    /**
     * Compare two vectors.
     *
     * This comparison operation ain't a bit-wise comparison. It instead
     * validates @f$ | a_i-b_i | < epsilon @f$ element-wise. If you don't know
     * which epsilon to use, I suggest to use NUMERICAL_ZERO_DIFFERENCE from
     * Globals.h.
     */
    bool equals(const Vector<N,Type>& cmp, const Type& epsilon) const;

    /**
     * Returns true if the object is smaller than than. The semantics equals the
     * < operator in combination with the equals() function, i.e. we again
     * compare the entries entry by entry taking into account
     * NUMERICAL_ZERO_DIFFERENCE.
     */
    bool smaller(const Vector<N,Type>& than, const Type& epsilon) const;

    /**
     * Compare two vectors. Inequality -> return index. Equality -> return -1.
     *
     * This comparison operation ain't a bit-wise comparison. It instead
     * validates @f$ | a_i-b_i | < epsilon @f$ element-wise.
     */
    int equalsReturnIndex(const Vector<N,Type>& cmp, const Type& epsilon) const;


    /**
     * Bit-wise comparison.
     */
    bool equals(const Vector<N,Type>& cmp) const;

    /**
     * Compares each component to cmp. If all components are equal to cmp, the
     * operation return true.
     */
    bool componentsAreEqualTo( const Type& cmp ) const;

    /**
     * Deliver string representation.
     */
    std::string toString() const;

    /**
     * @return L2 norm of the vector
     */
    double norm() const;

    /**
     * @return Length of vector, i.e. N
     */
    int size() const;

    Type max() const;
    Type min() const;

    Vector<N,Type> abs() const;

    Type sum() const;
};


/**
 * Bit-wise comparison operator. Delegates to equals() operation.
 */
template <int N, class Type>
bool operator==(const tarch::la::Vector<N,Type>& left, const tarch::la::Vector<N,Type>& right);


/**
 * Delegates
 */
template <int N, class Type>
bool operator<(const tarch::la::Vector<N,Type>& left, const tarch::la::Vector<N,Type>& right);


/**
 * Counterpart of == operator.
 */
template <int N, class Type>
bool operator!=(const tarch::la::Vector<N,Type>& left, const tarch::la::Vector<N,Type>& right);

/**
 * Proxy for toString()
 */
template <int N, class Type>
std::ostream& operator<<(std::ostream& out, const tarch::la::Vector<N,Type>& param);


/**
 * Add two vectors.
 */
template <int N, class Type>
tarch::la::Vector<N,Type> operator+(const tarch::la::Vector<N,Type>& left, const tarch::la::Vector<N,Type>& right);


/**
 * Substract two vectors.
 */
template <int N, class Type>
tarch::la::Vector<N,Type> operator-(const tarch::la::Vector<N,Type>& left, const tarch::la::Vector<N,Type>& right);


/**
 * Substract a scalar from a vector.
 */
template <int N, class Type>
tarch::la::Vector<N,Type> operator-(const tarch::la::Vector<N,Type>& left, const Type& right);


/**
 * Substract a vector from a scalar.
 */
template <int N, class Type>
tarch::la::Vector<N,Type> operator-(const Type& left, const tarch::la::Vector<N,Type>& right);



/**
 * Switching the sign of a vector.
 */
template <int N, class Type>
tarch::la::Vector<N,Type> operator-(const tarch::la::Vector<N,Type>& right);


/**
 * Dot product.
 */
template <int N, class Type>
Type operator*(const tarch::la::Vector<N,Type>& left, const tarch::la::Vector<N,Type>& right);


/**
 * Scale a vector from right.
 */
template <int N, class Type>
tarch::la::Vector<N,Type> operator*(const tarch::la::Vector<N,Type>& vector, const Type& scaling);

/**
 * Scale a vector from left.
 */
template <int N, class Type>
tarch::la::Vector<N,Type> operator*(const Type& scaling, const tarch::la::Vector<N,Type>& vector);

/**
 * Scale a vector.
 */
template <int N, class Type>
tarch::la::Vector<N,Type> operator/(const tarch::la::Vector<N,Type>& vector, const Type& scaling);


/**
 * Divide a vector by component-wise by entries of another Vector.
 */
template <int N, class Type>
tarch::la::Vector<N,Type> operator/(const tarch::la::Vector<N,Type>& left, const tarch::la::Vector<N,Type>& right);

#include "tarch/la/Vector.cpph"

#endif


