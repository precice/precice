#include "tarch/la/Utilities.h"

#include <cmath>
#include "tarch/la/Vector.h"
#include "tarch/la/DynamicVector.h"


bool tarch::la::equals ( double lhs, double rhs, double tolerance ) {
   return std::abs(rhs - lhs) <= tolerance;
}


bool tarch::la::greater (double lhs, double rhs, double tolerance ) {
   return lhs - rhs >  tolerance;
}


bool tarch::la::smaller (double lhs, double rhs, double tolerance ) {
  return lhs - rhs < -tolerance;
}


int tarch::la::aPowI(int i,int a) {
  int result = 1;
  for (int d=0; d<i; d++) {
    result *= a;
  }
  return result;
}


double tarch::la::pow (double value, int exponent){
  double result = value;
  for (int i=1; i<exponent; i++) {
    result *= value;
  }
  return result;
}


double tarch::la::sqrt (double value){
  return std::sqrt(value);
}


double tarch::la::sqrt (int value){
  return std::sqrt(static_cast<double>(value));
}


double tarch::la::mult (double left, double right){
  return left * right;
}


int tarch::la::mult (int left, int right){
  return left * right;
}


float tarch::la::mult (float left, float right){
  return left * right;
}


double tarch::la::dot(double value0, double value1) {
  return value0 * value1;
}


double tarch::la::dot(int value0, int value1) {
  return static_cast<double>(value0) * static_cast<double>(value1);
}
