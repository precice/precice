// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www5.in.tum.de/peano
#ifndef _LA_MATRIX_H_
#define _LA_MATRIX_H_


#include "tarch/la/Vector.h"
#include "tarch/la/iterators/AssignmentIterator.h"


namespace tarch {
  namespace la {
    template <int Rows, int Columns, class Type>
    class Matrix;
  }
}


/**
 * Simple matrix class.
 *
 * @author Tobias Weinzierl, Tobias Neckel
 */
template <int Rows, int Columns, class Type>
class tarch::la::Matrix {
  private:
    Type _data[Rows*Columns];

    static const int RowsTimesColumns = Rows * Columns;

    int getIndex(const int row, const int column) const;
  public:
    Matrix();
    Matrix(const double& initialValue);
    Matrix(const Matrix<Rows,Columns,Type>& copy);
    ~Matrix();
    Type* data();
    const Type& operator()(const int row, const int column) const;
    Type& operator()(const int row, const int column);

    /**
     * Element-wise scaling
     */
    Matrix<Rows,Columns,Type>& operator*=(const Type& argument);

    /**
     * Element-wise scaling
     */
    Matrix<Rows,Columns,Type>& operator/=(const Type& argument);

    /**
     * Assignment operator.
     */
    Matrix<Rows,Columns,Type>& operator=(const Matrix<Rows,Columns,Type>& argument);

    /**
     * Add two matrices.
     */
    Matrix<Rows,Columns,Type>& operator+=(const Matrix<Rows,Columns,Type>& argument);


    /**
     * Compare two matrices.
     *
     * This comparison operation ain't a bit-wise comparison. It instead
     * validates @f$ | a_{ij}-b_{ij} | < epsilon @f$ element-wise.
     */
    bool equals(
      const Matrix<Rows,Columns,Type > & cmp,
      const Type& epsilon
    ) const;


    /**
     * Compare two matrices. Inequality -> return index. Equality -> return -1.
     *
     * This comparison operation ain't a bit-wise comparison. It instead
     * validates @f$ | a_{ij}-b_{ij} | < epsilon @f$ element-wise.
     */
    int equalsReturnIndex(
      const Matrix<Rows,Columns,Type > & cmp,
      const Type& epsilon
    ) const;
    /**
     * Numerical equality with default eps (NUMERICAL_ZERO_DIFFERENCE).
     * Compares two matrices and returns the index of the row
     * with the first inequality or -1 if the matrices are numerically equal.
     */
    int defaultNumericalEqualsReturnIndex(
      const tarch::la::Matrix<Rows,Columns,Type > & cmp
    ) const;

    /**
     * Bit-wise comparison of two matrices.
     */
    bool equals(const Matrix<Rows,Columns,Type>& cmp) const;

    /**
     * Deliver string representation.
     */
    std::string toString() const;

    /**
     * Getter (read-only) for a single entry. Is used parallel to the
     * operator(,) since I was not able to use this one inside this class
     * directly :-)
     */
    const Type& getEntry(const int row, const int column) const;

    void setColumn( const int columnIndex, const Vector<Columns,Type>& vector );
    void setRow( const int rowIndex, const Vector<Rows,Type>& vector );

    Vector<Rows,Type> getColumn( const int columnIndex ) const;
    Vector<Columns,Type> getRow( const int rowIndex ) const;

    /**
     * Enables to assign comma separated list, setting more than one component.
     */
    iterators::FirstAssignmentIterator<Rows*Columns -1, Type> operator= (const Type & value);

    /**
     * Method to compute matrix-vector product A*b where A represents the matrix
     * and b the vector. The number of rows in b must correspond to the number
     * of columns in A.
     *
     * The result is a Vector with number of rows equal to the number of rows
     * of A.
     *
     * @param vector Vector to be multiplied from right to the matrix
     *
     * @return Resulting row times vector entries.
     */
    Vector<Rows,Type> times(const Vector<Columns,Type>& vector) const;
};


/**
 * Bit-wise comparison operator. Delegates to equals() operation.
 */
template <int Rows, int Columns, class Type>
bool operator==(const tarch::la::Matrix<Rows,Columns,Type>& left, const tarch::la::Matrix<Rows,Columns,Type>& right);


/**
 * Counterpart of == operator.
 */
template <int Rows, int Columns, class Type>
bool operator!=(const tarch::la::Matrix<Rows,Columns,Type>& left, const tarch::la::Matrix<Rows,Columns,Type>& right);

/**
 * Proxy for toString()
 */
template <int Rows, int Columns, class Type>
std::ostream& operator<<(std::ostream& out, const tarch::la::Matrix<Rows,Columns,Type>& param);


/**
 * Add two vector.
 */
template <int Rows, int Columns, class Type>
tarch::la::Matrix<Rows,Columns,Type> operator+(const tarch::la::Matrix<Rows,Columns,Type>& left, const tarch::la::Matrix<Rows,Columns,Type>& right);


/**
 * Substract two vector.
 */
template <int Rows, int Columns, class Type>
tarch::la::Matrix<Rows,Columns,Type> operator-(const tarch::la::Matrix<Rows,Columns,Type>& left, const tarch::la::Matrix<Rows,Columns,Type>& right);


/**
 * Matrix-scalar product.
 */
template <int Rows, int Columns, class Type>
tarch::la::Matrix<Rows,Columns,Type> operator*(const tarch::la::Matrix<Rows,Columns,Type>& matrix, const Type scalar);

/**
 * Matrix-matrix product.
 */
template <int RowsLeft, int ColumnsLeft, int ColumnsRight, class Type>
tarch::la::Matrix<RowsLeft,ColumnsRight,Type> operator*(const tarch::la::Matrix<RowsLeft,ColumnsLeft,Type>& left, const tarch::la::Matrix<ColumnsLeft,ColumnsRight,Type>& right);

/**
 * Matrix-vector product.
 */
template <int Rows, int Columns, class Type>
tarch::la::Vector<Rows,Type> operator*(const tarch::la::Matrix<Rows,Columns,Type>& matrix, const tarch::la::Vector<Columns,Type>& vector);

#include "tarch/la/Matrix.cpph"


#endif
