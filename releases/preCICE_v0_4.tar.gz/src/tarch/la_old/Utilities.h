// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www5.in.tum.de/peano
#ifndef _TARCH_LA_UTILITY_H_
#define _TARCH_LA_UTILITY_H_



namespace tarch {
  namespace la {
    const double PI=3.1415926535897932384626433832795028841972;
    const double E=2.7182818284590452353602874713526624977572;

    const double NUMERICAL_ZERO_DIFFERENCE=1.0e-14;

    bool equals(double lhs, double rhs, double tolerance = NUMERICAL_ZERO_DIFFERENCE);
    bool smaller (double lhs, double rhs, double tolerance = NUMERICAL_ZERO_DIFFERENCE);
    bool greater (double lhs, double rhs, double tolerance = NUMERICAL_ZERO_DIFFERENCE);

    int aPowI(int i,int a);

    /**
     * Pre-declaration.
     */
    template<int N, typename Type>
    class Vector;

    /**
     * Pre-declaration.
     */
    template<typename Type>
    class DynamicVector;

    /**
     * Computes the power of a given value with exponent.
     */
    double pow (
      double value,
      int exponent
    );

    // TW: I removed this function as it makes the unit tests ambiguous and they do not compile anymore
//    float pow (
//      float value,
//      int exponent
//    );

    /**
     * Computes the power of a given Vector component-wise, i.e., the power operator
     * is applied to every component of the Vector.
     */
    template<int N, typename Type>
    Vector<N,Type> pow(
      const Vector<N,Type>& value,
      int exponent
    );

    /**
     * Computes the square-root of a given value.
     */
    double sqrt (
      double value
    );

    double sqrt (
      int value
    );

    /**
     * Computes the square-root of the sum of squared components, i.e. two-norm.
     */
    template<int N, typename Type>
    double sqrt(
      const Vector<N,Type>& value
    );

    /**
     * Multiplies two values.
     */
    double mult (
      double left,
      double right
    );

    int mult (
      int left,
      int right
    );

    float mult (
      float left,
      float right
    );

    /**
     * Multiplies to vectors component-wise, result is a vector.
     */
    template <int N, typename Type>
    Vector<N,Type> mult(
      const Vector<N,Type>& left,
      const Vector<N,Type>& right
    );

    /**
     * Multiplies the two values with each other.
     */
    double dot(
      double value0,
      double value1
    );

    double dot(
      int value0,
      int value1
    );

    /**
     * Returns the corresponding zero value of the specified Type.
     *
     * The method has no default implementation, only its specializations
     * provide an implementation.
     */
    template<typename Type> Type zero();
    template<> double zero();
    template<> float zero();
    template<> int zero();
    template<> bool zero();
  }
}

#include "tarch/la/Utilities.cpph"

#endif /* _TARCH_LA_UTILITY_H_ */
