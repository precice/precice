// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#ifndef PRECICE_IMPL_MAPPINGCONTEXT_HPP_
#define PRECICE_IMPL_MAPPINGCONTEXT_HPP_

#include "mesh/SharedPointer.hpp"
#include "mapping/SharedPointer.hpp"

namespace precice {
namespace impl {

/**
 * @brief Holds a data mapping and related information.
 */
struct MappingContext
{
  // @brief Data mapping.
  mapping::PtrMapping mapping;

  // @brief Local solver mesh to map to/from.
  mesh::PtrMesh localMesh;

  // @brief True, if mapping should be computed only once.
  bool isStationary;

  // @brief True, if computation and mapping is done repeatedly for single values.
  bool isIncremental;

  /**
   * @brief Constructor.
   */
  MappingContext ()
  : mapping (),
    localMesh (),
    isStationary ( false ),
    isIncremental ( false )
  {}
};

}} // namespace precice, impl

#endif /* PRECICE_IMPL_MAPPINGCONTEXT_HPP_ */
