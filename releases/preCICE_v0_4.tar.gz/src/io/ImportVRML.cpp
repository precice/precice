// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "ImportVRML.hpp"
#include "mesh/Vertex.hpp"
#include "mesh/Edge.hpp"
#include "mesh/Triangle.hpp"
#include "mesh/Mesh.hpp"
#include "mesh/PropertyContainer.hpp"
#include "utils/Dimensions.hpp"
#ifndef PRECICE_NO_SPIRIT2
#include <boost/spirit/include/qi_parse.hpp>
#include <boost/spirit/include/support_multi_pass.hpp>
namespace spirit = boost::spirit;
#endif // not PRECICE_NO_SPIRIT2
#include <fstream>
#include <map>

namespace precice {
namespace io {

tarch::logging::Log ImportVRML:: _log ( "precice::io::ImportVRML" );

ImportVRML:: ImportVRML
(
  const std::string& location )
:
  Import ( location )
{
# ifdef PRECICE_NO_SPIRIT2
  preciceError ( "ImportVRML()",
                 "VRML import can only be used with Boost.Spirit V2.0!" );
# endif
}

void ImportVRML:: doImport
(
  const std::string& name,
  mesh::Mesh&        mesh )
{
  doImport(name, mesh, false);
}

void ImportVRML:: doImportCheckpoint
(
  const std::string& name,
  mesh::Mesh&        mesh )
{
  doImport(name, mesh, true);
}

void ImportVRML:: doImport
(
  const std::string& name,
  mesh::Mesh&        mesh,
  bool               isCheckpoint )
{
# ifndef PRECICE_NO_SPIRIT2
  int dimensions = mesh.getDimensions();
  assertion1 ( (dimensions == 2) || (dimensions == 3), dimensions );

  // Create input filestream to VRML file
  std::string filename ( getLocation() + name );
  std::ifstream in ( filename.c_str() );
  preciceCheck ( in.is_open(), "doImport()",
      "Could not open input file " << filename << "!" );

  // Wrap input file stream into a multi pass iterator (requirement)
  typedef std::istreambuf_iterator<char> FileIter;
  typedef spirit::multi_pass<FileIter> MultiPassFileIter;
  MultiPassFileIter first = spirit::make_default_multi_pass ( FileIter(in) );
  MultiPassFileIter last = spirit::make_default_multi_pass ( FileIter() );

  // Parse VRML file and check validity
  impl::VRML10Parser<MultiPassFileIter> vrmlParser(dimensions);
  bool success = spirit::qi::phrase_parse (
      first, last, vrmlParser, spirit::qi::space );
  preciceCheck ( success && (first == last), "doImport()",
      "Parsing of file " << filename << " failed! Left over: "
      << std::endl << std::string(first, last) );

  // Construct vertex coordinates from parsed information
  std::vector<mesh::Vertex*> vertices;
  if ( dimensions == 2){
    std::vector<utils::Vector2D> coordinates;
    for ( size_t i=0; i < vrmlParser.coordinates.size(); i += 2 ) {
      assertion ( i + 1 < vrmlParser.coordinates.size() );
      utils::Vector2D coord;
      for ( int component=0; component < 2; component++ ) {
        coord(component) = vrmlParser.coordinates[i+component];
      }
      coordinates += coord;
    }

    // Create vertices
    for ( size_t i=0; i < coordinates.size(); i++ ) {
      vertices += & mesh.createVertex ( coordinates[i] );
    }

     // Construct edge indices from parsed data.
     // The parsed data has the form: i0, ..., in, -1, i0, ..., im, -1, ...., -1
     assertion ( vrmlParser.indices.size() > 2 );
     std::vector<tarch::la::Vector<2,int> > indices;
     for ( size_t i=0; i < vrmlParser.indices.size(); i++ ) {
        if ( vrmlParser.indices[i+1] == -1 ) {
           i++;
        }
        else {
           indices.push_back ( tarch::la::Vector<2,int>(
                               vrmlParser.indices[i],vrmlParser.indices[i+1]) );
        }
     }

     // Create edges
     for ( size_t i=0; i < indices.size(); i++ ) {
        assertion ( vertices[indices[i][0]] != NULL );
        assertion ( vertices[indices[i][1]] != NULL );
        mesh.createEdge ( *vertices[indices[i][0]], *vertices[indices[i][1]] );
     }
  }
  else { // 3D
    std::vector<utils::Vector3D> coordinates;
    for ( size_t i=0; i < vrmlParser.coordinates.size(); i += 3 ) {
      assertion ( i + 2 < vrmlParser.coordinates.size() );
      utils::Vector3D coord;
      for ( int component=0; component < 3; component++ ) {
        coord(component) = vrmlParser.coordinates[i+component];
      }
      coordinates += coord;
    }

    // Create vertices
    for ( size_t i=0; i < coordinates.size(); i++ ) {
      vertices += & mesh.createVertex ( coordinates[i] );
    }

    // Construct triangle indices from parsed data.
    std::vector< tarch::la::Vector<3,int> > vertexIndices;
    for ( size_t i=0; i < vrmlParser.indices.size(); i += 3 ) {
      assertion ( i + 2 < vrmlParser.indices.size() );
      tarch::la::Vector<3,int> indices ( -1 );
      for ( int component=0; component < 3; component++ ) {
        indices(component) = vrmlParser.indices[i+component];
      }
      vertexIndices += indices;
    }

    // Create triangle edges and avoid the duplicated creation of edges
    std::vector<mesh::Edge*> edges;
    std::vector< tarch::la::Vector<3,int> > edgeIndices;
    for ( size_t i=0; i < vertexIndices.size(); i++ ) {
      //      precicePrint ( "Creating edges of triangle number " << i );
      assertion ( vertices[vertexIndices[i][0]] != NULL );
      assertion ( vertices[vertexIndices[i][1]] != NULL );
       assertion ( vertices[vertexIndices[i][2]] != NULL );

      tarch::la::Vector<3,int> indices ( -1 );
      indices[0] = getIndexExistingEdge (
          edges, vertices[vertexIndices[i][0]], vertices[vertexIndices[i][1]] );
      if ( indices[0] < 0 ) {
         edges += & mesh.createEdge (
             *vertices[vertexIndices[i][0]], *vertices[vertexIndices[i][1]] );
         indices[0] = (int)edges.size() - 1;
      }
      indices[1] = getIndexExistingEdge (
          edges, vertices[vertexIndices[i][1]], vertices[vertexIndices[i][2]] );
      if ( indices[1] < 0 ) {
         edges += & mesh.createEdge (
             *vertices[vertexIndices[i][1]], *vertices[vertexIndices[i][2]] );
          indices[1] = (int)edges.size() - 1;
      }
      indices[2] = getIndexExistingEdge (
          edges, vertices[vertexIndices[i][2]], vertices[vertexIndices[i][0]] );
      if ( indices[2] < 0 ) {
         edges += & mesh.createEdge (
            *vertices[vertexIndices[i][2]], *vertices[vertexIndices[i][0]] );
         indices[2] = (int)edges.size() - 1;
      }
      assertion ( indices[0] >= 0 );
      assertion ( indices[1] >= 0 );
      assertion ( indices[2] >= 0 );
      edgeIndices.push_back ( indices );
    }

    // Create triangles
    for ( size_t i=0; i < edgeIndices.size(); i++ ) {
      //      precicePrint ( "Creating triangle number " << i );
      mesh::Edge & edge0 = *edges[edgeIndices[i][0]];
      mesh::Edge & edge1 = *edges[edgeIndices[i][1]];
      mesh::Edge & edge2 = *edges[edgeIndices[i][2]];
      mesh.createTriangle ( edge0, edge1, edge2 );
    }
  }

   // Stop here, if no checkpoint data is to be read
   if ( not isCheckpoint ) {
      return;
   }

   // Set data values of vertices
   if ( mesh.data().size() != vrmlParser.data.size() ) {
      preciceError ( "doImport()",
                      "Number of vertex data sets configured does not match "
                      << "with that in VRML file!" );
   }
   mesh.allocateDataValues ();
   for ( size_t iData=0; iData < vrmlParser.data.size(); iData++ ) {
      mesh::PtrData meshData = mesh.data()[iData];
      const impl::VRML10Parser<MultiPassFileIter>::Data &
         vrmlData = vrmlParser.data[iData];
      if ( meshData->getName() != vrmlData.name ) {
         preciceError ( "doImport()", "Name of configured data set " << iData
                         << " \"" << meshData->getName()
                         << "\" does not match with that in VRML file "
                         << "\"" << vrmlData.name << "\"!" );
      }
      if ( meshData->getDimensions() != vrmlData.dimensions ) {
         preciceError ( "doImport()", "Dimension of configured data set " << iData
                         << " \"" << meshData->getDimensions()
                         << "\" does not match with that in VRML file "
                         << "\"" << vrmlData.dimensions << "\"!" );
      }
      utils::DynVector& values = meshData->values();
      preciceCheck ( values.size() == (int)vrmlData.values.size(),
                     "doImport()", "Number of data values from VRML file "
                     " does not fit to number of vertices for data \""
                     << meshData->getName() << "\"!" );
      for ( size_t i=0; i < vrmlData.values.size(); i++ ) {
         values[i] = vrmlData.values[i];
      }
   }

   // Add property containers
   preciceCheck ( vrmlParser.propertyContainers.size()
                  == mesh.propertyContainers().size(), "doImport()",
                  "Number of property containers in VRML file does not equals "
                  << "that of mesh from configuration!" );
   for ( size_t i=0; i < vrmlParser.propertyContainers.size(); i++ ) {
//      mesh::PropertyContainer & container = mesh.createPropertyContainer ();
      std::string subIDName ( vrmlParser.propertyContainers[i].subIDName );
      mesh::PropertyContainer & cont = mesh.getPropertyContainer ( subIDName );
      for ( size_t iVertex=0;
            iVertex < vrmlParser.propertyContainers[i].vertices.size();
            iVertex++ )
      {
        vertices[iVertex]->addParent ( cont );
      }
   }
#  endif // not PRECICE_NO_SPIRIT2
}

int ImportVRML:: getIndexExistingEdge
(
  const std::vector<mesh::Edge*>& edges,
  const mesh::Vertex*             vertex0,
  const mesh::Vertex*             vertex1 ) const
{
  for ( size_t i=0; i < edges.size(); i++ ) {
    if ( tarch::la::equals(edges[i]->vertex(0).getCoords(), vertex0->getCoords())
         && tarch::la::equals(edges[i]->vertex(1).getCoords(), vertex1->getCoords()) )
    {
      return i;
    }
    else if ( tarch::la::equals(edges[i]->vertex(0).getCoords(), vertex1->getCoords())
              && tarch::la::equals(edges[i]->vertex(1).getCoords(), vertex0->getCoords()) )
    {
      return i;
    }
  }
  return -1;
}

}} // namespace precice, io
