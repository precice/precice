// Copyright (C) 2011 Technische Universitaet Muenchen
// This file is part of the preCICE project. For conditions of distribution and
// use, please see the license notice at http://www5.in.tum.de/wiki/index.php/PreCICE_License
#include "TXTWriterTest.hpp"
#include "io/TXTWriter.hpp"
#include "tarch/la/DynamicMatrix.h"
#include "tarch/la/DynamicVector.h"
#include "utils/Globals.hpp"

#include "tarch/tests/TestCaseFactory.h"
registerTest(precice::io::tests::TXTWriterTest)

namespace precice {
namespace io {
namespace tests {

tarch::logging::Log TXTWriterTest:: _log ( "precice::io::tests::TXTWriterTest" );

TXTWriterTest:: TXTWriterTest ():
  TestCase ( "precice::io::tests::TXTWriterTest" )
{}

void TXTWriterTest:: run ()
{
  testMethod ( test );
}

void TXTWriterTest:: test ()
{
  preciceTrace ( "test()" );
  tarch::la::DynamicMatrix<double> matrix1 (1, 2);
  assignList(matrix1) = 1.0, 2.0;
  TXTWriter::write (matrix1, "TXTWriterTest-matrix-1by2.txt");

  tarch::la::DynamicMatrix<double> matrix2 (2, 1);
  assignList(matrix2) = 1.0, 2.0;
  TXTWriter::write (matrix2, "TXTWriterTest-matrix-2by1.txt");

  tarch::la::DynamicMatrix<double> matrix3 (3, 3);
  assignList(matrix3) = 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0;
  TXTWriter::write (matrix3, "TXTWriterTest-matrix-3by3.txt");

  tarch::la::DynamicVector<double> vector1 (1);
  assignList(vector1) = 1.0;
  TXTWriter::write (vector1, "TXTWriterTest-vector-1.txt");

  tarch::la::DynamicVector<double> vector2 (3);
  assignList(vector2) = 1.0, 2.0, 3.0;
  TXTWriter::write (vector2, "TXTWriterTest-vector-3.txt");

}

}}} // namespace precice, io, tests
